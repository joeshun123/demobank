public class DyDestObj2 {
    private String d2Str1;
    private String d2Str2;

    public DyDestObj2(String d2Str1, String d2Str2) {
        this.d2Str1 = d2Str1;
        this.d2Str2 = d2Str2;
    }

    public String getD2Str1() {
        return d2Str1;
    }

    public void setD2Str1(String d2Str1) {
        this.d2Str1 = d2Str1;
    }

    public String getD2Str2() {
        return d2Str2;
    }

    public void setD2Str2(String d2Str2) {
        this.d2Str2 = d2Str2;
    }
}
