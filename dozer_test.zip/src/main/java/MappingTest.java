import org.dozer.DozerBeanMapperSingletonWrapper;
import org.dozer.Mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 11/12/2014.
 */
public class MappingTest {
    private void map() {
        List myMappingFiles = new ArrayList();
        myMappingFiles.add("dozerBeanMapping.xml");

        SourceObject sourceObject = new SourceObject();
        //sourceObject.setSourceField1("1");

        List<SourceAddress> sa = new ArrayList<SourceAddress>();
        SourceAddress sourceAddress1 = new SourceAddress();
        sourceAddress1.setSourceField1("A");
        SourceAddress sourceAddress2 = new SourceAddress();
        sourceAddress2.setSourceField1("B");
        sa.add(sourceAddress1);
        sa.add(sourceAddress2);
        sourceObject.setAddresses(sa);

        Mapper mapper = DozerBeanMapperSingletonWrapper.getInstance();
        //DozerBeanMapper mapper = new DozerBeanMapper();
        //mapper.setMappingFiles(myMappingFiles);

        DestinationObject destObject =
                mapper.map(sourceObject, DestinationObject.class);
        System.out.println(destObject.getDestField1());
        //System.out.println(destObject.getSameField());

        destObject.setDestField1(2L);
        mapper.map(destObject, sourceObject);
        //System.out.println(sourceObject.getSourceField1());

    }
    public static void main(String[] args) {
        MappingTest t = new MappingTest();
        t.map();
    }
}
