package flex;

public class FlexDto1 implements FlexDto {
    private String f1;
    private String f2;
    private String f3;
    private String f4;

    @Override
    public void setF1(String value) {
        this.f1 = value;
    }

    @Override
    public String getF1() {
        return this.f1;
    }

    @Override
    public void setF2(String value) {
        this.f2 = value;
    }

    @Override
    public String getF2() {
        return this.f2;
    }

    @Override
    public void setF3(String value) {
        this.f3 = value;
    }

    @Override
    public String getF3() {
        return this.f3;
    }

    @Override
    public void setF4(String value) {
        this.f4 = value;
    }

    @Override
    public String getF4() {
        return this.f4;
    }

    @Override
    public String toString() {
        return "flex.FlexDto1{" +
                "f1='" + f1 + '\'' +
                ", f2='" + f2 + '\'' +
                ", f3='" + f3 + '\'' +
                ", f4='" + f4 + '\'' +
                '}';
    }
}
