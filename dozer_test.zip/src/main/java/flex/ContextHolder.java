package flex;

import org.springframework.stereotype.Component;

@Component
public class ContextHolder {
    static ThreadLocal<String> local = new ThreadLocal<>();
    public void setSite(String site) {
        local.set(site);
    }
    public String getSite() {
        return local.get();
    }
}
