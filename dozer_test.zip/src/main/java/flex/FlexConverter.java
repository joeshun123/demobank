package flex;

import org.dozer.DozerConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class FlexConverter extends DozerConverter<FlexEntity, FlexDto> {
    @Autowired
    private ContextHolder holder;

    public void setHolder(ContextHolder holder) {
        this.holder = holder;
    }

    /**
     * Defines two types, which will take part transformation.
     * As Dozer supports bi-directional mapping it is not known which of the classes is source and
     * which is destination. It will be decided in runtime.
     *
     * @param prototypeA type one
     * @param prototypeB type two
     */
    public FlexConverter(Class<FlexEntity> prototypeA, Class<FlexDto> prototypeB) {
        super(prototypeA, prototypeB);
    }

    @Override
    public FlexDto convertTo(FlexEntity source, FlexDto destination) {
        if ("Site1".equals(holder.getSite())) {
            destination.setF1(source.getF1());
        } else if ("Site2".equals(holder.getSite())) {
            destination.setF3(source.getF1());
        }
        return destination;
    }

    @Override
    public FlexEntity convertFrom(FlexDto source, FlexEntity destination) {
        return null;
    }
}
