package flex;

import org.dozer.DozerBeanMapper;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FlexTest {
    public void testSite3(DozerBeanMapper mapper) {
        applicationContext.getBean(ContextHolder.class).setSite("Site1");

        FlexDto1 d1 = new FlexDto1();
        d1.setF1("A");d1.setF2("B");d1.setF3("C");d1.setF4("D");

        FlexEntity1 e1 = new FlexEntity1();
        mapper.map(d1, e1);

        System.out.println(e1);
    }
    public void testSite1(DozerBeanMapper mapper) {
        applicationContext.getBean(ContextHolder.class).setSite("Site1");

        FlexEntity1 e1 = new FlexEntity1();
        e1.setF1("A");e1.setF2("B");e1.setF3("C");e1.setF4("D");

        FlexDto1 d1 = new FlexDto1();
        mapper.map(e1, d1);

        System.out.println(d1);
    }
    public void testSite2(DozerBeanMapper mapper) {
        applicationContext.getBean(ContextHolder.class).setSite("Site2");

        FlexEntity1 e1 = new FlexEntity1();
        e1.setF1("A");e1.setF2("B");e1.setF3("C");e1.setF4("D");

        FlexDto1 d1 = new FlexDto1();
        mapper.map(e1, d1);

        System.out.println(d1);
    }
    static ApplicationContext applicationContext = null;
    public static void main(String args[]) {
        applicationContext = new ClassPathXmlApplicationContext("bean.xml");
        DozerBeanMapper mapper = (DozerBeanMapper) applicationContext.getBean("objectMapper");
        FlexTest test = new FlexTest();
        //test.testSite1(mapper);
        //test.testSite2(mapper);
        test.testSite3(mapper);
    }
}
