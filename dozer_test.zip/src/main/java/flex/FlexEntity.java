package flex;

public interface FlexEntity {
    void setF1(String value);
    String getF1();
    void setF2(String value);
    String getF2();
    void setF3(String value);
    String getF3();
    void setF4(String value);
    String getF4();
}
