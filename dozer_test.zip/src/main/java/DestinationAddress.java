/**
 * Created by user on 11/12/2014.
 */
public class DestinationAddress {
    private String destinationField1;

    public String getDestinationField1() {
        return destinationField1;
    }

    public void setDestinationField1(String destinationField1) {
        this.destinationField1 = destinationField1;
    }
}
