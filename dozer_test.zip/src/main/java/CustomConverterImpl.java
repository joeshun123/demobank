import org.dozer.*;

public class CustomConverterImpl implements ConfigurableCustomConverter, MapperAware {
  private MappingProcessor mapper;
  private String sourceFieldName;

  @Override
  public Object convert(final Object existingDestinationFieldValue, final Object sourceFieldValue,
      final Class<?> destinationClass, final Class<?> sourceClass) {
    if (sourceFieldValue == null) {
      return null;
    }
    //mapper.map(sourceFieldValue, existingDestinationFieldValue);
    mapper.map(sourceFieldValue, "d1Str1");
    return existingDestinationFieldValue;
  }

  @Override
  public void setMapper(Mapper mapper) {
    this.mapper = (MappingProcessor) mapper;
  }

  @Override
  public void setParameter(String s) {
    this.sourceFieldName = s;
  }
}
