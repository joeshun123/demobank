public class DySourceObj {
    private String dyStr1;
    private String dyStr2;

    public DySourceObj() {
    }

    public DySourceObj(String dyStr1, String dyStr2) {
        this.dyStr1 = dyStr1;
        this.dyStr2 = dyStr2;
    }

    public String getDyStr1() {
        return dyStr1;
    }

    public void setDyStr1(String dyStr1) {
        this.dyStr1 = dyStr1;
    }

    public String getDyStr2() {
        return dyStr2;
    }

    public void setDyStr2(String dyStr2) {
        this.dyStr2 = dyStr2;
    }
}
