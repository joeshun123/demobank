/**
 * Created by user on 11/12/2014.
 */
public class SourceAddress {
    private String sourceField1;

    public String getSourceField1() {
        return sourceField1;
    }

    public void setSourceField1(String sourceField1) {
        this.sourceField1 = sourceField1;
    }
}
