import org.dozer.DozerBeanMapper;
import org.dozer.DozerBeanMapperSingletonWrapper;
import org.dozer.Mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MappingTest2 {
    public static void main(String args[]) {
        List myMappingFiles = new ArrayList();
        myMappingFiles.add("custom2.xml");

        Map<String, String> map1 = new HashMap<>();
        map1.put("A", "1");
        map1.put("B", "2");

        Map<String, String> map2 = new HashMap<>();
        map2.put("C", "3");
        map2.put("D", "4");

        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);
        //Mapper mapper = DozerBeanMapperSingletonWrapper.getInstance();

        //ValueObject destObject = mapper.map(map1, ValueObject.class);
        //System.out.println(destObject.getField11() + " " + destObject.getField22());
        ValueObject destObject = mapper.map(map2, ValueObject.class, "AAA");
        System.out.println(destObject.getField1() + " " + destObject.getField2());
    }
}
