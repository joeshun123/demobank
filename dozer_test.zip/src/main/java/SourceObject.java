import java.util.List;

/**
 * Created by user on 11/12/2014.
 */
public class SourceObject {
    //@Mapping("destField1")
    private String sameField = "456";
    private FingerprintId fingerprintId = null;

    private String sourceField1 = "123";
    private List<SourceAddress> addresses;

    public SourceObject() {
        fingerprintId = new FingerprintId("A");
    }

    public List<SourceAddress> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<SourceAddress> addresses) {
        this.addresses = addresses;
    }

}
