import java.util.ArrayList;
import java.util.List;
import org.dozer.DozerBeanMapper;
import org.dozer.DozerBeanMapperSingletonWrapper;
import org.dozer.Mapper;

public class MappingTest4 {
    private void map() {
        List myMappingFiles = new ArrayList();
        myMappingFiles.add("EnumMapping.xml");

        //Mapper mapper = DozerBeanMapperSingletonWrapper.getInstance();
        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);

        SubClass1 s1 = new SubClass1(); s1.setField("Sub1");
        SubClass2 s2 = new SubClass2(); s2.setField("Sub2");
        DestClass d1 = new DestClass();
        mapper.map(s1, d1);
        DestClass d2 = new DestClass();
        mapper.map(s1, d2);
        System.out.println(d1);
    }

    public static void main(String[] args) {
        MappingTest4 t = new MappingTest4();
        t.map();
    }
}
