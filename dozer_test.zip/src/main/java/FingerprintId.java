/**
 * Created by user on 14/12/2014.
 */
public class FingerprintId {
    private String field1;
    public FingerprintId() {
    }
    public FingerprintId(String field1) {
        this.field1 = field1;
    }
}
