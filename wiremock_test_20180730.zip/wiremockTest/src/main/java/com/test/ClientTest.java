package com.test;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.xml.ws.Response;

public class ClientTest {
    private void query() throws  Exception {
        Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
        ReturnObject returnObject1 = client.target("http://localhost:8089/test1")
                .request(MediaType.APPLICATION_JSON)
                .get(ReturnObject.class);
        System.out.println(returnObject1.getField1());
        ReturnObject returnObject2 = client.target("http://localhost:8089/test2")
                .request(MediaType.APPLICATION_JSON)
                .get(ReturnObject.class);
        System.out.println(returnObject2.getField1());
    }
    public static void main (String args[]) {
        ClientTest client = new ClientTest();
        try {
            client.query();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
