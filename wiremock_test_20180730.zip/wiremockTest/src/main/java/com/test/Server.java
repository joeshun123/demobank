package com.test;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

public class Server {
    public static void main(String args[]) {
        WireMockServer wireMockServer = new WireMockServer(options().port(8089).extensions(ExampleTransformer.class)
                .withRootDirectory("E:\\tech\\WiremockUI-master\\src\\WiremockUI\\.app\\5500\\scenario1"));
        wireMockServer.start();
    }
}
