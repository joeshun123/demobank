import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BolListing from './components/BolListing';
import BizTaskConfig from './components/BizTaskConfig';
import TaskMasterMaintenance from './components/TaskMasterMaintenance';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Bill of Lading (BOL) POC - BizTask Framework</h1>
        </header>
        <main className="container">
          <Routes>
            <Route path="/" element={<BolListing />} />
            <Route path="/bol-listing" element={<BolListing />} />
            <Route path="/biztask-config" element={<BizTaskConfig />} />
            <Route path="/task-master-maintenance" element={<TaskMasterMaintenance />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
