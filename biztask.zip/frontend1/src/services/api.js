import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const bolApi = {
  // Get all BOL documents
  getAllBolDocuments: () => api.get('/bol'),
  
  // Get BOL document by ID
  getBolDocumentById: (id) => api.get(`/bol/${id}`),
  
  // Create new BOL document
  createBolDocument: (data) => api.post('/bol', data),
  
  // Update BOL document
  updateBolDocument: (id, data) => api.put(`/bol/${id}`, data),
  
  // Delete BOL document
  deleteBolDocument: (id) => api.delete(`/bol/${id}`),
  
  // Get valid ports
  getValidPorts: () => api.get('/bol/ports'),
};

export default api;
