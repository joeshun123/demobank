import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api/biztask';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const bizTaskApi = {
  // Task Group operations
  getAllTaskGroups: () => api.get('/groups'),
  getTaskGroupById: (id) => api.get(`/groups/${id}`),
  createTaskGroup: (data) => api.post('/groups', data),
  updateTaskGroup: (id, data) => api.put(`/groups/${id}`, data),
  deleteTaskGroup: (id) => api.delete(`/groups/${id}`),
  
  // Metadata operations
  getAllAdvmDocs: () => api.get('/metadata/docs'),
  getAdvmItemsByDocSkey: (docSkey) => api.get(`/metadata/items/${docSkey}`),
  getAdvmStepsByItemSkey: (itemSkey) => api.get(`/metadata/steps/${itemSkey}`),
  getActiveTasksByEntityCode: (entityCode) => api.get(`/master-tasks/${entityCode}`),
  
  // Task Master operations
  getAllTaskMasters: () => api.get('/task-masters'),
  getTaskMasterById: (id) => api.get(`/task-masters/${id}`),
  createTaskMaster: (data) => api.post('/task-masters', data),
  updateTaskMaster: (id, data) => api.put(`/task-masters/${id}`, data),
  deleteTaskMaster: (id) => api.delete(`/task-masters/${id}`),
  
  // Configuration options
  getTaskExecModes: () => api.get('/config/exec-modes'),
  getTaskErrorHandleModes: () => api.get('/config/error-handle-modes'),
  getTimingOptions: () => api.get('/config/timing-options'),
  getExecutionEngineStatus: () => api.get('/bol/execution-engines/status'),
};

export default api;
