import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import TaskParamModal from './TaskParamModal';
import './TaskConfigModal.css';

const TaskConfigModal = ({ task, onSave, onClose, isEdit = false }) => {
  const [formData, setFormData] = useState({
    taskCode: '',
    isActive: false,
    isMandatory: false,
    timing: ''
  });
  const [timingOptions, setTimingOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showParamModal, setShowParamModal] = useState(false);
  const [editingParamIndex, setEditingParamIndex] = useState(null);
  const [params, setParams] = useState([]);

  useEffect(() => {
    fetchTimingOptions();
    if (isEdit && task) {
      setFormData({
        taskCode: task.code || '',
        isActive: task.isActive || false,
        isMandatory: task.isMandatory || false,
        timing: task.timing || ''
      });
      setParams(task.params || []);
    } else if (task) {
      setFormData(prev => ({
        ...prev,
        taskCode: '' // Always empty by default to force user input
      }));
    } else {
      // Reset form data when no task is provided (new task configuration)
      setFormData({
        taskCode: '', // Always empty by default to force user input
        isActive: false,
        isMandatory: false,
        timing: ''
      });
      setParams([]);
    }
  }, [task, isEdit]);

  const fetchTimingOptions = async () => {
    try {
      const response = await bizTaskApi.getTimingOptions();
      setTimingOptions(response.data);
    } catch (err) {
      console.error('Error fetching timing options:', err);
    }
  };


  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleAddParam = () => {
    setEditingParamIndex(null);
    setShowParamModal(true);
  };

  const handleEditParam = (index) => {
    setEditingParamIndex(index);
    setShowParamModal(true);
  };

  const handleDeleteParam = (index) => {
    const newParams = params.filter((_, i) => i !== index);
    setParams(newParams);
  };

  const handleParamSave = (paramData) => {
    if (editingParamIndex !== null) {
      // Edit existing param
      const newParams = [...params];
      newParams[editingParamIndex] = paramData;
      setParams(newParams);
    } else {
      // Add new param
      setParams([...params, paramData]);
    }
    setShowParamModal(false);
    setEditingParamIndex(null);
  };

  // Helper function to get required parameters for the selected task
  const getRequiredParameters = () => {
    if (task && task.parameters) {
      try {
        const requiredParams = JSON.parse(task.parameters);
        return Object.keys(requiredParams);
      } catch (e) {
        console.warn('Could not parse task parameters:', e);
        return [];
      }
    }
    return [];
  };

  const handleSave = () => {
    if (!formData.taskCode || !formData.timing) {
      setError('Please fill in all required fields');
      return;
    }

    // Check if the selected task requires parameters
    console.log('Task data for validation:', task);
    console.log('Task parameters field:', task?.parameters);
    console.log('Current params:', params);
    
    if (task && task.parameters) {
      try {
        const requiredParams = JSON.parse(task.parameters);
        const requiredParamKeys = Object.keys(requiredParams);
        console.log('Required parameter keys:', requiredParamKeys);
        
        // Check if user has added any parameters at all
        if (params.length === 0) {
          setError(`This task requires parameters: ${requiredParamKeys.join(', ')}. Please add them in the "Task Parameters" section before saving.`);
          return;
        }
        
        // Check if user has added all required parameters
        const addedParamKeys = params.map(param => param.key);
        console.log('Added parameter keys:', addedParamKeys);
        const missingParams = requiredParamKeys.filter(key => !addedParamKeys.includes(key));
        console.log('Missing parameters:', missingParams);
        
        if (missingParams.length > 0) {
          setError(`This task requires the following parameters: ${missingParams.join(', ')}. Please add them in the "Task Parameters" section before saving.`);
          return;
        }
      } catch (e) {
        // If parameters is not valid JSON, skip validation
        console.warn('Could not parse task parameters:', e);
      }
    }

    const taskData = {
      ...formData,
      task: task ? {
        // If editing existing task, preserve skey
        ...task
      } : {
        // If new task, don't set skey - let backend create new BizpTask
        entityCode: '',
        code: formData.taskCode
      },
      params: params
    };

    console.log('TaskConfigModal sending taskData:', taskData);
    
    onSave(taskData);
  };

  return (
    <div className="modal">
      <div className="modal-content task-config-modal">
        <div className="modal-header">
          <h3 className="modal-title">
            {isEdit ? 'Edit Task Configuration' : 'Configure Task'}
          </h3>
          <button className="close" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="task-config-form">
            {/* Task Information */}
            <div className="form-section">
              <h4>Task Information</h4>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Code *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="taskCode"
                      value={formData.taskCode}
                      onChange={handleInputChange}
                      placeholder="Enter task code"
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Timing *</label>
                    <select
                      className="form-control"
                      name="timing"
                      value={formData.timing}
                      onChange={handleInputChange}
                    >
                      <option value="">Select</option>
                      {timingOptions.map(option => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Options</label>
                    <div className="checkbox-group-panel">
                      <div className="checkbox-group">
                        <label className="checkbox-label">
                          <input
                            type="checkbox"
                            name="isActive"
                            checked={formData.isActive}
                            onChange={handleInputChange}
                          />
                          Active
                        </label>
                        <label className="checkbox-label">
                          <input
                            type="checkbox"
                            name="isMandatory"
                            checked={formData.isMandatory}
                            onChange={handleInputChange}
                          />
                          Mandatory
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Task Details */}
            {task && (
              <div className="form-section">
                <h4>Selected Task Details</h4>
                <div className="task-details">
                  <div className="row">
                    <div className="col-md-4">
                      <div className="detail-item">
                        <strong>Code:</strong> {task.code}
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="detail-item">
                        <strong>Entity Code:</strong> {task.entityCode}
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="detail-item">
                        <strong>Implementation Class:</strong> {task.implementationClass}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Task Parameters */}
            <div className="form-section">
              <div className="section-header">
                <h4>Task Parameters</h4>
                <button 
                  className="btn btn-sm btn-primary"
                  onClick={handleAddParam}
                >
                  Add Parameter
                </button>
              </div>
              
              {/* Show required parameters info */}
              {(() => {
                const requiredParams = getRequiredParameters();
                if (requiredParams.length > 0) {
                  return (
                    <div className="required-params-info">
                      <div className="alert alert-info">
                        <strong>Required Parameters:</strong> {requiredParams.join(', ')}
                      </div>
                    </div>
                  );
                }
                return null;
              })()}
              
              {params.length === 0 ? (
                <div className="empty-state">
                  No parameters configured. Click "Add Parameter" to add one.
                </div>
              ) : (
                <div className="params-table">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Key</th>
                        <th>Value</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {params.map((param, index) => {
                        const requiredParams = getRequiredParameters();
                        const isRequired = requiredParams.includes(param.key);
                        return (
                          <tr key={index} className={isRequired ? 'required-param' : ''}>
                            <td>
                              {param.key}
                              {isRequired && <span className="required-indicator"> *</span>}
                            </td>
                            <td>{param.value || 'N/A'}</td>
                            <td>
                              <button 
                                className="btn btn-sm btn-warning"
                                onClick={() => handleEditParam(index)}
                              >
                                Edit
                              </button>
                              <button 
                                className="btn btn-sm btn-danger"
                                onClick={() => handleDeleteParam(index)}
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Task'}
          </button>
        </div>
      </div>

      {/* Task Parameter Modal */}
      {showParamModal && (
        <TaskParamModal
          param={editingParamIndex !== null ? params[editingParamIndex] : null}
          onSave={handleParamSave}
          onClose={() => {
            setShowParamModal(false);
            setEditingParamIndex(null);
          }}
        />
      )}
    </div>
  );
};

export default TaskConfigModal;
