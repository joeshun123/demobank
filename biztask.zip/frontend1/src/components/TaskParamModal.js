import React, { useState, useEffect } from 'react';
import './TaskParamModal.css';

const TaskParamModal = ({ param, onSave, onClose }) => {
  const [formData, setFormData] = useState({
    key: '',
    value: ''
  });

  useEffect(() => {
    if (param) {
      setFormData({
        key: param.key || '',
        value: param.value || ''
      });
    }
  }, [param]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = () => {
    if (!formData.key.trim()) {
      alert('Parameter key is required');
      return;
    }

    onSave(formData);
  };

  return (
    <div className="modal">
      <div className="modal-content task-param-modal">
        <div className="modal-header">
          <h3 className="modal-title">
            {param ? 'Edit Parameter' : 'Add Parameter'}
          </h3>
          <button className="close" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          <div className="param-form">
            <div className="form-group">
              <label className="form-label">Parameter Key *</label>
              <input
                type="text"
                className="form-control"
                name="key"
                value={formData.key}
                onChange={handleInputChange}
                placeholder="Enter parameter key"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Parameter Value</label>
              <textarea
                className="form-control"
                name="value"
                value={formData.value}
                onChange={handleInputChange}
                placeholder="Enter parameter value (optional)"
                rows="3"
              />
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={handleSave}>
            {param ? 'Update Parameter' : 'Add Parameter'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskParamModal;
