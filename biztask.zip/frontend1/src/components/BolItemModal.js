import React, { useState, useEffect } from 'react';
import './BolItemModal.css';

const BolItemModal = ({ item, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    cargoDescription: '',
    qty: '',
    weight: '',
    volume: '',
    marks: ''
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (item) {
      setFormData({
        cargoDescription: item.cargoDescription || '',
        qty: item.qty || '',
        weight: item.weight || '',
        volume: item.volume || '',
        marks: item.marks || ''
      });
    } else {
      setFormData({
        cargoDescription: '',
        qty: '',
        weight: '',
        volume: '',
        marks: ''
      });
    }
    setErrors({});
  }, [item]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.cargoDescription.trim()) {
      newErrors.cargoDescription = 'Cargo description is required';
    }

    if (!formData.qty || isNaN(formData.qty) || parseFloat(formData.qty) <= 0) {
      newErrors.qty = 'Valid quantity is required';
    }

    if (!formData.weight || isNaN(formData.weight) || parseFloat(formData.weight) <= 0) {
      newErrors.weight = 'Valid weight is required';
    }

    if (formData.volume && (isNaN(formData.volume) || parseFloat(formData.volume) < 0)) {
      newErrors.volume = 'Volume must be a valid positive number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      const itemData = {
        cargoDescription: formData.cargoDescription.trim(),
        qty: parseFloat(formData.qty),
        weight: parseFloat(formData.weight),
        volume: formData.volume ? parseFloat(formData.volume) : null,
        marks: formData.marks.trim() || null
      };
      onSave(itemData);
    }
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h3 className="modal-title">
            {item ? 'Edit BOL Item' : 'Add BOL Item'}
          </h3>
          <button className="close" onClick={onCancel}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          <div className="form-group">
            <label className="form-label">Cargo Description *</label>
            <input
              type="text"
              className={`form-control ${errors.cargoDescription ? 'is-invalid' : ''}`}
              name="cargoDescription"
              value={formData.cargoDescription}
              onChange={handleInputChange}
              placeholder="Enter cargo description"
            />
            {errors.cargoDescription && (
              <div className="invalid-feedback">{errors.cargoDescription}</div>
            )}
          </div>

          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Quantity *</label>
                <input
                  type="number"
                  step="0.01"
                  className={`form-control ${errors.qty ? 'is-invalid' : ''}`}
                  name="qty"
                  value={formData.qty}
                  onChange={handleInputChange}
                  placeholder="Enter quantity"
                />
                {errors.qty && (
                  <div className="invalid-feedback">{errors.qty}</div>
                )}
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Weight *</label>
                <input
                  type="number"
                  step="0.01"
                  className={`form-control ${errors.weight ? 'is-invalid' : ''}`}
                  name="weight"
                  value={formData.weight}
                  onChange={handleInputChange}
                  placeholder="Enter weight"
                />
                {errors.weight && (
                  <div className="invalid-feedback">{errors.weight}</div>
                )}
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Volume</label>
                <input
                  type="number"
                  step="0.01"
                  className={`form-control ${errors.volume ? 'is-invalid' : ''}`}
                  name="volume"
                  value={formData.volume}
                  onChange={handleInputChange}
                  placeholder="Enter volume (optional)"
                />
                {errors.volume && (
                  <div className="invalid-feedback">{errors.volume}</div>
                )}
              </div>
            </div>
            <div className="col-md-6">
              <div className="form-group">
                <label className="form-label">Marks</label>
                <input
                  type="text"
                  className="form-control"
                  name="marks"
                  value={formData.marks}
                  onChange={handleInputChange}
                  placeholder="Enter marks and numbers (optional)"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={handleSave}>
            {item ? 'Update' : 'Add'} Item
          </button>
        </div>
      </div>
    </div>
  );
};

export default BolItemModal;
