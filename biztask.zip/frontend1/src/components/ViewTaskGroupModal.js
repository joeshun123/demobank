import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import './ViewTaskGroupModal.css';

const ViewTaskGroupModal = ({ groupId, onClose }) => {
  const [taskGroup, setTaskGroup] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTaskGroup();
  }, [groupId]);

  const fetchTaskGroup = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getTaskGroupById(groupId);
      setTaskGroup(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch task group');
      console.error('Error fetching task group:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-header">
            <h3 className="modal-title">Error</h3>
            <button className="close-button" onClick={onClose}>&times;</button>
          </div>
          <div className="modal-body text-center text-danger">
            Error: {error}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!taskGroup) {
    return (
      <div className="modal-overlay">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Task group not found</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content view-task-group-modal">
        <div className="modal-header">
          <h3 className="modal-title">View Task Group</h3>
          <button className="close-button" onClick={onClose}>&times;</button>
        </div>
        
        <div className="modal-body">
          {/* Basic Information */}
          <div className="form-section">
            <h4>Basic Information</h4>
            <div className="row">
              <div className="col-md-3">
                <div className="form-group">
                  <label className="form-label">Group Code</label>
                  <div className="readonly-field">{taskGroup.code}</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <label className="form-label">Entity Code</label>
                  <div className="readonly-field">{taskGroup.entityCode}</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <label className="form-label">Execution Mode</label>
                  <div className="readonly-field">{taskGroup.taskExecMode}</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <label className="form-label">Error Handle Mode</label>
                  <div className="readonly-field">{taskGroup.taskErrorHandleMode}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Task Configuration */}
          <div className="form-section">
            <h4>Task Configuration</h4>
            {taskGroup.details && taskGroup.details.length > 0 ? (
              <div className="tasks-table">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Order</th>
                      <th>Task Code</th>
                      <th>Implementation Class</th>
                      <th>Timing</th>
                      <th>Active</th>
                      <th>Mandatory</th>
                      <th>Parameters</th>
                    </tr>
                  </thead>
                  <tbody>
                    {taskGroup.details.map((detail, index) => (
                      <tr key={detail.skey || index}>
                        <td className="order-cell">
                          <span className="order-number">{detail.taskOrder || index + 1}</span>
                        </td>
                        <td>{detail.taskCode}</td>
                        <td className="code-cell">
                          {detail.bizpTask?.implementationClass || 'N/A'}
                        </td>
                        <td>{detail.timing}</td>
                        <td>
                          <span className={`badge ${detail.bizpTask?.isActive ? 'badge-success' : 'badge-secondary'}`}>
                            {detail.bizpTask?.isActive ? 'Yes' : 'No'}
                          </span>
                        </td>
                        <td>
                          <span className={`badge ${detail.isMandatory ? 'badge-warning' : 'badge-secondary'}`}>
                            {detail.isMandatory ? 'Yes' : 'No'}
                          </span>
                        </td>
                        <td>
                          {detail.bizpTask?.params && detail.bizpTask.params.length > 0 ? (
                            <div className="params-list">
                              {detail.bizpTask.params.map((param, paramIndex) => (
                                <div key={paramIndex} className="param-item">
                                  <strong>{param.key}:</strong> {param.value}
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-muted">No parameters</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty-state">
                No tasks configured for this group.
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewTaskGroupModal;
