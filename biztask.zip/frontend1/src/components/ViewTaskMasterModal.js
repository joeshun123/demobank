import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import './ViewTaskMasterModal.css';

const ViewTaskMasterModal = ({ taskMasterId, onClose }) => {
  const [taskMaster, setTaskMaster] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTaskMaster();
  }, [taskMasterId]);

  const fetchTaskMaster = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getTaskMasterById(taskMasterId);
      setTaskMaster(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch task master');
      console.error('Error fetching task master:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-header">
            <h3 className="modal-title">Error</h3>
            <button className="close" onClick={onClose}>×</button>
          </div>
          <div className="modal-body text-center text-danger">
            Error: {error}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal">
      <div className="modal-content view-task-master-modal">
        <div className="modal-header">
          <h3 className="modal-title">Task Master Details</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          <div className="task-master-details-compact">
            <div className="detail-grid">
              <div className="detail-item">
                <span className="detail-label">Code:</span>
                <span className="detail-value">{taskMaster.code}</span>
              </div>
              
              <div className="detail-item">
                <span className="detail-label">Entity Code:</span>
                <span className="detail-value">{taskMaster.entityCode}</span>
              </div>
              
              <div className="detail-item active-item">
                <span className="detail-label">Active:</span>
                <span className={`badge ${taskMaster.isActive ? 'badge-success' : 'badge-secondary'}`}>
                  {taskMaster.isActive ? 'Yes' : 'No'}
                </span>
              </div>
            </div>
            
            <div className="detail-item-full">
              <span className="detail-label">Implementation Class:</span>
              <span className="detail-value code-value">{taskMaster.implementationClass}</span>
            </div>
            
            <div className="detail-item-full">
              <span className="detail-label">Parameters:</span>
              <div className="parameters-display">
                {taskMaster.parameters ? (
                  <div className="parameters-table-container">
                    <table className="parameters-table">
                      <thead>
                        <tr>
                          <th>Parameter</th>
                          <th>Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(JSON.parse(taskMaster.parameters)).map(([key, value]) => (
                          <tr key={key}>
                            <td className="parameter-key-cell">
                              <code className="parameter-key">{key}</code>
                            </td>
                            <td className="parameter-value-cell">
                              <span className="parameter-description">{value}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <span className="text-muted">No parameters defined</span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewTaskMasterModal;
