import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import TaskSelectionModal from './TaskSelectionModal';
import TaskConfigModal from './TaskConfigModal';
import './EditTaskGroupModal.css';

const EditTaskGroupModal = ({ groupId, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    code: '',
    entityCode: '',
    taskExecMode: 'EVALUATE_ALL',
    taskErrorHandleMode: 'THROW',
    taskExecEngine: 'com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [showTaskSelection, setShowTaskSelection] = useState(false);
  const [showTaskConfig, setShowTaskConfig] = useState(false);
  const [editingTaskIndex, setEditingTaskIndex] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(null);

  useEffect(() => {
    fetchTaskGroup();
  }, [groupId]);

  const fetchTaskGroup = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getTaskGroupById(groupId);
      const group = response.data;
      
      setFormData({
        code: group.code,
        entityCode: group.entityCode,
        taskExecMode: group.taskExecMode || 'EVALUATE_ALL',
        taskErrorHandleMode: group.taskErrorHandleMode || 'THROW',
        taskExecEngine: group.taskExecEngine || 'com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine'
      });
      
      // Load tasks from the response
      console.log('Group details from backend:', group.details);
      if (group.details && group.details.length > 0) {
        const taskData = group.details
          .map(detail => {
            console.log('Processing detail:', detail);
            console.log('taskCode:', detail.taskCode, 'type:', typeof detail.taskCode);
            
            // Handle case where taskCode might be empty but we have bizpTask data
            let effectiveTaskCode = detail.taskCode;
            if (!effectiveTaskCode || effectiveTaskCode.trim() === '') {
              // Try to use implementation class as fallback taskCode
              effectiveTaskCode = detail.bizpTask?.implementationClass || 'UNKNOWN_TASK';
              console.log('Using fallback taskCode:', effectiveTaskCode);
            }
            
            return {
              skey: detail.skey, // Preserve the detail skey
              taskCode: effectiveTaskCode,
              taskOrder: detail.taskOrder,
              timing: detail.timing,
              isMandatory: detail.isMandatory,
              isActive: detail.bizpTask?.isActive || false,
              task: detail.bizpTask ? {
                ...detail.bizpTask,
                skey: detail.bizpTask.skey, // Preserve the task skey
                code: effectiveTaskCode // Add the effective taskCode as 'code' field for compatibility
              } : null
            };
          })
          .filter(task => task.taskCode && task.taskCode.trim() !== ''); // Now filter after processing
        
        console.log('Processed task data:', taskData);
        setTasks(taskData);
      } else {
        console.log('No details found in group');
        setTasks([]);
      }
      
      setError(null);
    } catch (err) {
      setError('Failed to fetch task group');
      console.error('Error fetching task group:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    if (!formData.code || !formData.entityCode || !formData.taskExecMode || !formData.taskErrorHandleMode) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      
      // Convert tasks to the format expected by the API
      // Only include tasks that have valid task data
      console.log('All tasks before validation:', tasks);
      const validTasks = tasks.filter(task => {
        const isValid = task.task && 
          task.taskCode && 
          task.taskCode.trim() !== '' && // Ensure taskCode is not empty
          task.timing && 
          task.timing.trim() !== '' && // Ensure timing is not empty
          task.task.implementationClass &&
          task.task.implementationClass.trim() !== ''; // Ensure implementationClass is not empty
        
        console.log('Task validation:', {
          taskCode: task.taskCode,
          timing: task.timing,
          implementationClass: task.task?.implementationClass,
          isValid: isValid
        });
        
        return isValid;
      });
      const taskDetails = validTasks.map((task, index) => ({
        skey: task.skey, // Include the detail skey for updates
        taskCode: task.taskCode,
        taskOrder: index + 1,
        timing: task.timing,
        isMandatory: task.isMandatory,
        bizpTask: {
          skey: task.task.skey, // Include the task skey for updates
          entityCode: task.task.entityCode || formData.entityCode,
          implementationClass: task.task.implementationClass,
          isActive: task.isActive,
          params: task.task.params || []
        }
      }));
      
      const taskGroupData = {
        code: formData.code,
        entityCode: formData.entityCode,
        taskExecMode: formData.taskExecMode,
        taskErrorHandleMode: formData.taskErrorHandleMode,
        taskExecEngine: formData.taskExecEngine,
        details: taskDetails
      };

      console.log('Valid tasks found:', validTasks.length);
      console.log('Task details to send:', taskDetails);
      console.log('Sending task group data:', JSON.stringify(taskGroupData, null, 2));
      
      // Validate that we have valid data
      if (taskDetails.length === 0) {
        setError('No valid tasks to save. Please ensure all tasks have valid data (taskCode, timing, and implementationClass are required).');
        return;
      }
      
      await bizTaskApi.updateTaskGroup(groupId, taskGroupData);
      onSuccess();
    } catch (err) {
      let errorMessage = 'Failed to update task group';
      
      if (err.response?.data) {
        if (err.response.data.error) {
          errorMessage = err.response.data.error;
        } else if (err.response.data.message) {
          errorMessage = err.response.data.message;
        } else if (typeof err.response.data === 'string') {
          errorMessage = err.response.data;
        }
      } else if (err.message) {
        errorMessage = err.message;
      }
      
      setError(errorMessage);
      console.error('Error updating task group:', err);
      if (err.response?.data) {
        console.error('Error response data:', err.response.data);
      }
    } finally {
      setSaving(false);
    }
  };

  // Task management functions
  const handleAddTask = () => {
    setShowTaskSelection(true);
  };

  const handleTaskSelect = (task) => {
    setSelectedTask(task);
    setShowTaskSelection(false);
    setShowTaskConfig(true);
  };

  const handleTaskConfigSave = (taskData) => {
    console.log('handleTaskConfigSave called with taskData:', taskData);
    console.log('editingTaskIndex:', editingTaskIndex);
    
    if (editingTaskIndex !== null) {
      // Edit existing task - convert back to EditTaskGroupModal format
      const updatedTasks = [...tasks];
      const existingTask = tasks[editingTaskIndex];
      
      console.log('Existing task before update:', existingTask);
      console.log('taskData.code:', taskData.code);
      
      updatedTasks[editingTaskIndex] = {
        skey: existingTask.skey, // Preserve the detail skey
        taskCode: taskData.code || taskData.taskCode || existingTask.taskCode,
        taskOrder: existingTask.taskOrder, // Keep existing order
        timing: taskData.timing,
        isMandatory: taskData.isMandatory,
        isActive: taskData.isActive,
        task: {
          ...existingTask.task, // Keep existing task data including skey
          entityCode: taskData.entityCode || formData.entityCode,
          implementationClass: taskData.task?.implementationClass || existingTask.task?.implementationClass || '',
          isActive: taskData.isActive,
          params: taskData.params || []
        }
      };
      
      console.log('Updated task after save:', updatedTasks[editingTaskIndex]);
      console.log('Task implementationClass:', updatedTasks[editingTaskIndex].task?.implementationClass);
      setTasks(updatedTasks);
    } else {
      // Add new task - create new BizpTask based on selected BizmTaskMaster
      const newTask = {
        taskCode: taskData.code || taskData.taskCode,
        taskOrder: tasks.length + 1,
        timing: taskData.timing,
        isMandatory: taskData.isMandatory,
        isActive: taskData.isActive,
        task: {
          // Don't set skey - let backend create new BizpTask
          entityCode: taskData.entityCode || formData.entityCode,
          implementationClass: taskData.task?.implementationClass || '',
          isActive: taskData.isActive,
          params: taskData.params || []
        }
      };
      setTasks([...tasks, newTask]);
    }
    setShowTaskConfig(false);
    setEditingTaskIndex(null);
    setSelectedTask(null);
  };

  const handleEditTask = (index) => {
    setEditingTaskIndex(index);
    const taskData = tasks[index];
    
    // Transform the task data to match what TaskConfigModal expects
    const transformedTask = {
      code: taskData.taskCode || taskData.task?.code || taskData.task?.implementationClass || 'UNKNOWN_TASK',
      isActive: taskData.isActive,
      isMandatory: taskData.isMandatory,
      timing: taskData.timing,
      params: taskData.task?.params || [],
      implementationClass: taskData.task?.implementationClass || '',
      entityCode: taskData.task?.entityCode || formData.entityCode,
      parameters: taskData.task?.parameters || null // Master task parameters from BIZM_TASK_MASTER
    };
    
    setSelectedTask(transformedTask);
    setShowTaskConfig(true);
  };

  const handleDeleteTask = (index) => {
    const updatedTasks = tasks.filter((_, i) => i !== index);
    setTasks(updatedTasks);
    if (selectedTaskIndex === index) {
      setSelectedTaskIndex(null);
    } else if (selectedTaskIndex > index) {
      setSelectedTaskIndex(selectedTaskIndex - 1);
    }
  };

  const handleSelectTask = (index) => {
    setSelectedTaskIndex(index);
  };

  const handleMoveTaskUp = () => {
    if (selectedTaskIndex === null || selectedTaskIndex === 0) return;
    
    const updatedTasks = [...tasks];
    const temp = updatedTasks[selectedTaskIndex];
    updatedTasks[selectedTaskIndex] = updatedTasks[selectedTaskIndex - 1];
    updatedTasks[selectedTaskIndex - 1] = temp;
    
    setTasks(updatedTasks);
    setSelectedTaskIndex(selectedTaskIndex - 1);
  };

  const handleMoveTaskDown = () => {
    if (selectedTaskIndex === null || selectedTaskIndex === tasks.length - 1) return;
    
    const updatedTasks = [...tasks];
    const temp = updatedTasks[selectedTaskIndex];
    updatedTasks[selectedTaskIndex] = updatedTasks[selectedTaskIndex + 1];
    updatedTasks[selectedTaskIndex + 1] = temp;
    
    setTasks(updatedTasks);
    setSelectedTaskIndex(selectedTaskIndex + 1);
  };

  if (loading) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !formData.code) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-header">
            <h3 className="modal-title">Error</h3>
            <button className="close" onClick={onClose}>×</button>
          </div>
          <div className="modal-body text-center text-danger">
            Error: {error}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal">
      <div className="modal-content edit-task-group-modal">
        <div className="modal-header">
          <h3 className="modal-title">Edit Task Group</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="task-group-form">
            {/* Basic Information */}
            <div className="form-section">
              <h4>Basic Information</h4>
              <div className="row">
                <div className="col-md-3">
                  <div className="form-group">
                    <label className="form-label">Group Code *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="code"
                      value={formData.code}
                      onChange={handleInputChange}
                      placeholder="Enter group code"
                    />
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="form-group">
                    <label className="form-label">Entity Code</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.entityCode}
                      readOnly
                      placeholder="Entity code"
                      style={{ 
                        backgroundColor: '#f8f9fa',
                        fontWeight: 'bold'
                      }}
                    />
                    <small className="text-muted">
                      Current: {formData.entityCode}
                    </small>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="form-group">
                    <label className="form-label">Execution Mode *</label>
                    <select
                      className="form-control"
                      name="taskExecMode"
                      value={formData.taskExecMode}
                      onChange={handleInputChange}
                    >
                      <option value="">Select execution mode</option>
                      <option value="EVALUATE_ALL">EVALUATE_ALL</option>
                      <option value="STOP_ON_FAILURE">STOP_ON_FAILURE</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="form-group">
                    <label className="form-label">Error Handle Mode *</label>
                    <select
                      className="form-control"
                      name="taskErrorHandleMode"
                      value={formData.taskErrorHandleMode}
                      onChange={handleInputChange}
                    >
                      <option value="">Select error handle mode</option>
                      <option value="GO_TO_TROUBLE">GO_TO_TROUBLE</option>
                      <option value="THROW">THROW</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label className="form-label">Task Execution Engine *</label>
                    <select
                      className="form-control"
                      name="taskExecEngine"
                      value={formData.taskExecEngine}
                      onChange={handleInputChange}
                    >
                      <option value="">Select execution engine</option>
                      <option value="com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine">Easy Rules Engine</option>
                      <option value="com.biztask.bolpoc.execution.drools.DroolsTaskExecutionEngine">Drools Engine</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Task Configuration */}
            <div className="form-section">
              <div className="section-header">
                <h4>Task Configuration</h4>
                <div className="task-controls">
                  <button 
                    className="btn btn-primary"
                    onClick={handleAddTask}
                    disabled={!formData.entityCode}
                  >
                    Add Task
                  </button>
                  {tasks.length > 0 && (
                    <div className="order-controls-panel">
                      <button 
                        className="btn btn-outline-secondary order-btn"
                        onClick={handleMoveTaskUp}
                        disabled={selectedTaskIndex === null || selectedTaskIndex === 0}
                        title="Move Selected Task Up"
                      >
                        ↑ Move Up
                      </button>
                      <button 
                        className="btn btn-outline-secondary order-btn"
                        onClick={handleMoveTaskDown}
                        disabled={selectedTaskIndex === null || selectedTaskIndex === tasks.length - 1}
                        title="Move Selected Task Down"
                      >
                        ↓ Move Down
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              {tasks.length === 0 ? (
                <div className="empty-state">
                  No tasks configured. Click "Add Task" to get started.
                </div>
              ) : (
                <div className="tasks-table">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Order</th>
                        <th>Task Code</th>
                        <th>Implementation Class</th>
                        <th>Timing</th>
                        <th>Active</th>
                        <th>Mandatory</th>
                        <th>Params</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasks.map((task, index) => (
                        <tr 
                          key={index}
                          className={`task-row ${selectedTaskIndex === index ? 'selected' : ''}`}
                          onClick={() => handleSelectTask(index)}
                        >
                          <td className="order-cell">
                            <span className="order-number">{index + 1}</span>
                          </td>
                          <td>{task.taskCode}</td>
                          <td className="code-cell">{task.task?.implementationClass || 'N/A'}</td>
                          <td>{task.timing}</td>
                          <td>
                            <span className={`badge ${task.isActive ? 'badge-success' : 'badge-secondary'}`}>
                              {task.isActive ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${task.isMandatory ? 'badge-warning' : 'badge-secondary'}`}>
                              {task.isMandatory ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td>
                            {task.task?.params && task.task.params.length > 0 ? (
                              <div className="params-list">
                                {task.task.params.map((param, paramIndex) => (
                                  <div key={paramIndex} className="param-item">
                                    <strong>{param.key}:</strong> {param.value}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <span className="text-muted">No parameters</span>
                            )}
                          </td>
                          <td>
                            <div className="action-buttons">
                              <button
                                className="btn btn-sm btn-outline-primary"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditTask(index);
                                }}
                                title="Edit Task"
                              >
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteTask(index);
                                }}
                                title="Delete Task"
                              >
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Task Selection Modal */}
      {showTaskSelection && (
        <TaskSelectionModal
          entityCode={formData.entityCode}
          onSelect={handleTaskSelect}
          onClose={() => setShowTaskSelection(false)}
        />
      )}

      {/* Task Configuration Modal */}
      {showTaskConfig && (
        <TaskConfigModal
          task={selectedTask}
          isEdit={editingTaskIndex !== null}
          onSave={handleTaskConfigSave}
          onClose={() => {
            setShowTaskConfig(false);
            setEditingTaskIndex(null);
            setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
};

export default EditTaskGroupModal;
