import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { bizTaskApi } from '../services/bizTaskApi';
import AddTaskMasterModal from './AddTaskMasterModal';
import EditTaskMasterModal from './EditTaskMasterModal';
import ViewTaskMasterModal from './ViewTaskMasterModal';
import './TaskMasterMaintenance.css';

const TaskMasterMaintenance = () => {
  const navigate = useNavigate();
  const [taskMasters, setTaskMasters] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [editingTaskMasterId, setEditingTaskMasterId] = useState(null);
  const [viewingTaskMasterId, setViewingTaskMasterId] = useState(null);
  const [sortField, setSortField] = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');

  useEffect(() => {
    fetchTaskMasters();
  }, []);

  const fetchTaskMasters = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getAllTaskMasters();
      setTaskMasters(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch task masters');
      console.error('Error fetching task masters:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (id) => {
    const newSelectedIds = new Set(selectedIds);
    if (newSelectedIds.has(id)) {
      newSelectedIds.delete(id);
    } else {
      newSelectedIds.add(id);
    }
    setSelectedIds(newSelectedIds);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === taskMasters.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(taskMasters.map(taskMaster => taskMaster.skey)));
    }
  };

  const handleAddTaskMaster = () => {
    setShowAddModal(true);
  };

  const handleEditTaskMaster = () => {
    if (selectedIds.size === 1) {
      const id = Array.from(selectedIds)[0];
      setEditingTaskMasterId(id);
      setShowEditModal(true);
    }
  };

  const handleViewTaskMaster = (id) => {
    setViewingTaskMasterId(id);
    setShowViewModal(true);
  };

  const handleDeleteTaskMaster = async () => {
    if (selectedIds.size === 0) return;
    
    const confirmed = window.confirm(
      `Are you sure you want to delete ${selectedIds.size} task master(s)? This action cannot be undone.`
    );
    
    if (!confirmed) return;

    try {
      const deletePromises = Array.from(selectedIds).map(id => 
        bizTaskApi.deleteTaskMaster(id)
      );
      await Promise.all(deletePromises);
      
      setSelectedIds(new Set());
      fetchTaskMasters();
    } catch (err) {
      setError('Failed to delete task masters');
      console.error('Error deleting task masters:', err);
    }
  };

  const handleModalClose = () => {
    setShowAddModal(false);
    setShowEditModal(false);
    setShowViewModal(false);
    setEditingTaskMasterId(null);
    setViewingTaskMasterId(null);
  };

  const handleModalSuccess = () => {
    fetchTaskMasters();
    handleModalClose();
  };

  const handleBackToBol = () => {
    navigate('/bol-listing');
  };

  const handleSort = (field) => {
    if (sortField === field) {
      // If clicking the same field, toggle direction
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // If clicking a new field, set it as sort field with ascending direction
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortedTaskMasters = () => {
    if (!sortField) {
      return taskMasters;
    }

    return [...taskMasters].sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];

      // Handle null/undefined values
      if (aValue == null && bValue == null) return 0;
      if (aValue == null) return sortDirection === 'asc' ? -1 : 1;
      if (bValue == null) return sortDirection === 'asc' ? 1 : -1;

      // Convert to strings for comparison
      aValue = String(aValue).toLowerCase();
      bValue = String(bValue).toLowerCase();

      if (aValue < bValue) {
        return sortDirection === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  const getSortIcon = (field) => {
    if (sortField !== field) {
      return '↕️'; // Neutral sort icon
    }
    return sortDirection === 'asc' ? '↑' : '↓';
  };

  const isAddEnabled = selectedIds.size === 0;
  const isEditEnabled = selectedIds.size === 1;
  const isDeleteEnabled = selectedIds.size > 0;

  if (loading) {
    return (
      <div className="task-master-maintenance">
        <div className="text-center">
          <div>Loading task masters...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="task-master-maintenance">
        <div className="alert alert-danger">{error}</div>
      </div>
    );
  }

  return (
    <div className="task-master-maintenance">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Task Master Maintenance</h2>
        <div className="d-flex gap-2">
          <span className="text-muted">
            {taskMasters.length} task master(s) found
          </span>
        </div>
      </div>

      <div className="action-buttons">
        <button 
          className="btn btn-primary" 
          onClick={handleAddTaskMaster}
          disabled={!isAddEnabled}
        >
          Add Task Master
        </button>
        <button 
          className="btn btn-warning" 
          onClick={handleEditTaskMaster}
          disabled={!isEditEnabled}
        >
          Edit Task Master
        </button>
        <button 
          className="btn btn-danger" 
          onClick={handleDeleteTaskMaster}
          disabled={!isDeleteEnabled}
        >
          Delete Task Master
        </button>
        <button 
          className="btn btn-secondary" 
          onClick={handleBackToBol}
        >
          Back to BOL Listing
        </button>
      </div>

      <div className="card">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th className="checkbox-cell">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === taskMasters.length && taskMasters.length > 0}
                    onChange={handleSelectAll}
                  />
                </th>
                <th 
                  className="sortable-header" 
                  onClick={() => handleSort('code')}
                  style={{ cursor: 'pointer' }}
                >
                  Code {getSortIcon('code')}
                </th>
                <th 
                  className="sortable-header" 
                  onClick={() => handleSort('entityCode')}
                  style={{ cursor: 'pointer' }}
                >
                  Entity Code {getSortIcon('entityCode')}
                </th>
                <th 
                  className="sortable-header" 
                  onClick={() => handleSort('implementationClass')}
                  style={{ cursor: 'pointer' }}
                >
                  Implementation Class {getSortIcon('implementationClass')}
                </th>
                <th 
                  className="sortable-header" 
                  onClick={() => handleSort('isActive')}
                  style={{ cursor: 'pointer' }}
                >
                  Active {getSortIcon('isActive')}
                </th>
                <th>Parameters</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {taskMasters.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center text-muted">
                    No task masters found. Click "Add Task Master" to create your first task master.
                  </td>
                </tr>
              ) : (
                getSortedTaskMasters().map((taskMaster) => (
                  <tr key={taskMaster.skey}>
                    <td className="checkbox-cell">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(taskMaster.skey)}
                        onChange={() => handleCheckboxChange(taskMaster.skey)}
                      />
                    </td>
                    <td>{taskMaster.code}</td>
                    <td>{taskMaster.entityCode}</td>
                    <td className="code-cell">{taskMaster.implementationClass}</td>
                    <td>
                      <span className={`badge ${taskMaster.isActive ? 'badge-success' : 'badge-secondary'}`}>
                        {taskMaster.isActive ? 'Yes' : 'No'}
                      </span>
                    </td>
                    <td className="parameters-cell">
                      {taskMaster.parameters ? (
                        <span className="parameters-preview" title={taskMaster.parameters}>
                          {Object.keys(JSON.parse(taskMaster.parameters)).length} parameter(s)
                        </span>
                      ) : (
                        <span className="text-muted">No parameters</span>
                      )}
                    </td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleViewTaskMaster(taskMaster.skey)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Task Master Modal */}
      {showAddModal && (
        <AddTaskMasterModal
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}

      {/* Edit Task Master Modal */}
      {showEditModal && editingTaskMasterId && (
        <EditTaskMasterModal
          taskMasterId={editingTaskMasterId}
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}

      {/* View Task Master Modal */}
      {showViewModal && viewingTaskMasterId && (
        <ViewTaskMasterModal
          taskMasterId={viewingTaskMasterId}
          onClose={handleModalClose}
        />
      )}
    </div>
  );
};

export default TaskMasterMaintenance;
