import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { bizTaskApi } from '../services/bizTaskApi';
import AddTaskGroupModal from './AddTaskGroupModal';
import EditTaskGroupModal from './EditTaskGroupModal';
import ViewTaskGroupModal from './ViewTaskGroupModal';
import './BizTaskConfig.css';

const BizTaskConfig = () => {
  const navigate = useNavigate();
  const [taskGroups, setTaskGroups] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [editingGroupId, setEditingGroupId] = useState(null);
  const [viewingGroupId, setViewingGroupId] = useState(null);

  useEffect(() => {
    fetchTaskGroups();
  }, []);

  const fetchTaskGroups = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getAllTaskGroups();
      setTaskGroups(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch task groups');
      console.error('Error fetching task groups:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (id) => {
    const newSelectedIds = new Set(selectedIds);
    if (newSelectedIds.has(id)) {
      newSelectedIds.delete(id);
    } else {
      newSelectedIds.add(id);
    }
    setSelectedIds(newSelectedIds);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === taskGroups.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(taskGroups.map(group => group.skey)));
    }
  };

  const handleAddTaskGroup = () => {
    setShowAddModal(true);
  };

  const handleEditTaskGroup = () => {
    if (selectedIds.size === 1) {
      const id = Array.from(selectedIds)[0];
      setEditingGroupId(id);
      setShowEditModal(true);
    }
  };

  const handleViewTaskGroup = (id) => {
    setViewingGroupId(id);
    setShowViewModal(true);
  };

  const handleDeleteTaskGroup = async () => {
    if (selectedIds.size === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedIds.size} task group(s)?`)) {
      try {
        const deletePromises = Array.from(selectedIds).map(id => 
          bizTaskApi.deleteTaskGroup(id)
        );
        await Promise.all(deletePromises);
        setSelectedIds(new Set());
        fetchTaskGroups();
      } catch (err) {
        setError('Failed to delete task groups');
        console.error('Error deleting task groups:', err);
      }
    }
  };

  const handleBack = () => {
    navigate('/');
  };

  const handleModalClose = () => {
    setShowAddModal(false);
    setShowEditModal(false);
    setShowViewModal(false);
    setEditingGroupId(null);
    setViewingGroupId(null);
  };

  const handleModalSuccess = () => {
    fetchTaskGroups();
    handleModalClose();
  };

  const isAddEnabled = selectedIds.size === 0;
  const isEditEnabled = selectedIds.size === 1;
  const isDeleteEnabled = selectedIds.size > 0;

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-danger">Error: {error}</div>;
  }

  return (
    <div className="biztask-config">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>BizTask Configuration</h2>
        <button className="btn btn-secondary" onClick={handleBack}>
          Back to BOL List
        </button>
      </div>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <div className="d-flex gap-2">
          <span className="text-muted">
            {taskGroups.length} task group(s) found
          </span>
        </div>
      </div>

      <div className="action-buttons">
        <button 
          className="btn btn-primary" 
          onClick={handleAddTaskGroup}
          disabled={!isAddEnabled}
        >
          Add Task Group
        </button>
        <button 
          className="btn btn-warning" 
          onClick={handleEditTaskGroup}
          disabled={!isEditEnabled}
        >
          Edit Task Group
        </button>
        <button 
          className="btn btn-danger" 
          onClick={handleDeleteTaskGroup}
          disabled={!isDeleteEnabled}
        >
          Delete Task Group
        </button>
      </div>

      <div className="card">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th className="checkbox-cell">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === taskGroups.length && taskGroups.length > 0}
                    onChange={handleSelectAll}
                  />
                </th>
                <th>Group Code</th>
                <th>Entity Code</th>
                <th>Execution Mode</th>
                <th>Error Handle Mode</th>
                <th>Tasks Count</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {taskGroups.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center text-muted">
                    No task groups found. Click "Add Task Group" to create your first group.
                  </td>
                </tr>
              ) : (
                taskGroups.map((group) => (
                  <tr key={group.skey}>
                    <td className="checkbox-cell">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(group.skey)}
                        onChange={() => handleCheckboxChange(group.skey)}
                      />
                    </td>
                    <td>{group.code}</td>
                    <td>{group.entityCode}</td>
                    <td>{group.taskExecMode}</td>
                    <td>{group.taskErrorHandleMode}</td>
                    <td>{group.taskCount || 0}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleViewTaskGroup(group.skey)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Task Group Modal */}
      {showAddModal && (
        <AddTaskGroupModal
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}

      {/* Edit Task Group Modal */}
      {showEditModal && editingGroupId && (
        <EditTaskGroupModal
          groupId={editingGroupId}
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}

      {/* View Task Group Modal */}
      {showViewModal && viewingGroupId && (
        <ViewTaskGroupModal
          groupId={viewingGroupId}
          onClose={handleModalClose}
        />
      )}
    </div>
  );
};

export default BizTaskConfig;