import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { bolApi } from '../services/api';
import AddBolModal from './AddBolModal';
import EditBolModal from './EditBolModal';
import './BolListing.css';

const BolListing = () => {
  const [bolDocuments, setBolDocuments] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingBolId, setEditingBolId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchBolDocuments();
  }, []);

  const fetchBolDocuments = async () => {
    try {
      setLoading(true);
      const response = await bolApi.getAllBolDocuments();
      setBolDocuments(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch BOL documents');
      console.error('Error fetching BOL documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (id) => {
    const newSelectedIds = new Set(selectedIds);
    if (newSelectedIds.has(id)) {
      newSelectedIds.delete(id);
    } else {
      newSelectedIds.add(id);
    }
    setSelectedIds(newSelectedIds);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === bolDocuments.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(bolDocuments.map(doc => doc.skey)));
    }
  };

  const handleAddBol = () => {
    setShowAddModal(true);
  };

  const handleEditBol = () => {
    if (selectedIds.size === 1) {
      const id = Array.from(selectedIds)[0];
      setEditingBolId(id);
      setShowEditModal(true);
    }
  };

  const handleViewBol = (id) => {
    setEditingBolId(id);
    setShowEditModal(true);
  };

  const handleDeleteBol = async () => {
    if (selectedIds.size === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedIds.size} BOL document(s)?`)) {
      try {
        const deletePromises = Array.from(selectedIds).map(id => 
          bolApi.deleteBolDocument(id)
        );
        await Promise.all(deletePromises);
        setSelectedIds(new Set());
        fetchBolDocuments();
      } catch (err) {
        setError('Failed to delete BOL documents');
        console.error('Error deleting BOL documents:', err);
      }
    }
  };


  const handleModalClose = () => {
    setShowAddModal(false);
    setShowEditModal(false);
    setEditingBolId(null);
  };

  const handleModalSuccess = () => {
    fetchBolDocuments();
    handleModalClose();
  };

  const handleBizTaskConfig = () => {
    navigate('/biztask-config');
  };

  const handleTaskMasterMaintenance = () => {
    navigate('/task-master-maintenance');
  };

  const isAddEnabled = selectedIds.size === 0;
  const isEditEnabled = selectedIds.size === 1;
  const isDeleteEnabled = selectedIds.size > 0;
  const isBizTaskConfigEnabled = selectedIds.size === 0;

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-danger">Error: {error}</div>;
  }

  return (
    <div className="bol-listing">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Bill of Lading Documents</h2>
        <div className="d-flex gap-2">
          <span className="text-muted">
            {bolDocuments.length} document(s) found
          </span>
        </div>
      </div>

      <div className="action-buttons">
        <button 
          className="btn btn-primary" 
          onClick={handleAddBol}
          disabled={!isAddEnabled}
        >
          Add BOL
        </button>
        <button 
          className="btn btn-warning" 
          onClick={handleEditBol}
          disabled={!isEditEnabled}
        >
          Edit BOL
        </button>
        <button 
          className="btn btn-danger" 
          onClick={handleDeleteBol}
          disabled={!isDeleteEnabled}
        >
          Delete BOL
        </button>
        <button 
          className="btn btn-secondary" 
          onClick={handleBizTaskConfig}
          disabled={!isBizTaskConfigEnabled}
        >
          BizTask Config
        </button>
        <button 
          className="btn btn-info" 
          onClick={handleTaskMasterMaintenance}
          disabled={!isBizTaskConfigEnabled}
        >
          Task Master Maintenance
        </button>
      </div>

      <div className="card">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th className="checkbox-cell">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === bolDocuments.length && bolDocuments.length > 0}
                    onChange={handleSelectAll}
                  />
                </th>
                <th>Document Number</th>
                <th>Consignee Name</th>
                <th>Port of Destination</th>
                <th>Items Count</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bolDocuments.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center text-muted">
                    No BOL documents found. Click "Add BOL" to create your first document.
                  </td>
                </tr>
              ) : (
                bolDocuments.map((doc) => (
                  <tr key={doc.skey}>
                    <td className="checkbox-cell">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(doc.skey)}
                        onChange={() => handleCheckboxChange(doc.skey)}
                      />
                    </td>
                    <td>{doc.docNbr}</td>
                    <td>{doc.consigneeName}</td>
                    <td>{doc.portOfDestination}</td>
                    <td>{doc.items ? doc.items.length : 0}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleViewBol(doc.skey)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add BOL Modal */}
      {showAddModal && (
        <AddBolModal
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}

      {/* Edit BOL Modal */}
      {showEditModal && editingBolId && (
        <EditBolModal
          bolId={editingBolId}
          onClose={handleModalClose}
          onSuccess={handleModalSuccess}
        />
      )}
    </div>
  );
};

export default BolListing;
