import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import './AddTaskMasterModal.css';

const AddTaskMasterModal = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    code: '',
    entityCode: '',
    implementationClass: '',
    isActive: false,
    parameters: ''
  });
  const [parameters, setParameters] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const addParameter = () => {
    setParameters(prev => [...prev, { key: '', value: '' }]);
  };

  const removeParameter = (index) => {
    setParameters(prev => prev.filter((_, i) => i !== index));
  };

  const updateParameter = (index, field, value) => {
    setParameters(prev => prev.map((param, i) => 
      i === index ? { ...param, [field]: value } : param
    ));
  };

  const convertParametersToJson = () => {
    if (parameters.length === 0) return '';
    const paramObj = {};
    parameters.forEach(param => {
      if (param.key && param.value) {
        paramObj[param.key] = param.value;
      }
    });
    return Object.keys(paramObj).length > 0 ? JSON.stringify(paramObj) : '';
  };

  const handleSave = async () => {
    if (!formData.code || !formData.entityCode || !formData.implementationClass) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const parametersJson = convertParametersToJson();
      const taskMasterData = {
        ...formData,
        parameters: parametersJson
      };
      
      await bizTaskApi.createTaskMaster(taskMasterData);
      onSuccess();
    } catch (err) {
      const errorMessage = err.response?.data?.error || err.response?.data?.message || err.message || 'Failed to create task master';
      setError(errorMessage);
      console.error('Error creating task master:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal">
      <div className="modal-content add-task-master-modal">
        <div className="modal-header">
          <h3 className="modal-title">Add Task Master</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="task-master-form">
            <div className="form-group">
              <label className="form-label">Code *</label>
              <input
                type="text"
                className="form-control"
                name="code"
                value={formData.code}
                onChange={handleInputChange}
                placeholder="Enter task code"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Entity Code *</label>
              <input
                type="text"
                className="form-control"
                name="entityCode"
                value={formData.entityCode}
                onChange={handleInputChange}
                placeholder="Enter entity code"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Implementation Class *</label>
              <input
                type="text"
                className="form-control"
                name="implementationClass"
                value={formData.implementationClass}
                onChange={handleInputChange}
                placeholder="Enter implementation class"
                required
              />
            </div>

            <div className="form-group">
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  name="isActive"
                  checked={formData.isActive}
                  onChange={handleInputChange}
                  id="isActive"
                />
                <label className="form-check-label" htmlFor="isActive">
                  Active
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Parameters</label>
              <div className="parameters-section">
                {parameters.map((param, index) => (
                  <div key={index} className="parameter-row">
                    <input
                      type="text"
                      className="form-control parameter-key"
                      placeholder="Key"
                      value={param.key}
                      onChange={(e) => updateParameter(index, 'key', e.target.value)}
                    />
                    <input
                      type="text"
                      className="form-control parameter-value"
                      placeholder="Value"
                      value={param.value}
                      onChange={(e) => updateParameter(index, 'value', e.target.value)}
                    />
                    <button
                      type="button"
                      className="btn btn-sm btn-danger"
                      onClick={() => removeParameter(index)}
                    >
                      Remove
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-sm btn-outline-primary"
                  onClick={addParameter}
                >
                  Add Parameter
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? 'Creating...' : 'Create Task Master'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddTaskMasterModal;
