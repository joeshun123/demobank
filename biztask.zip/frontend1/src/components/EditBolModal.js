import React, { useState, useEffect } from 'react';
import { bolApi } from '../services/api';
import BolItemModal from './BolItemModal';
import './EditBolModal.css';

const EditBolModal = ({ bolId, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    docNbr: '',
    consigneeName: '',
    portOfDestination: ''
  });
  const [items, setItems] = useState([]);
  const [validPorts, setValidPorts] = useState([]);
  const [showItemModal, setShowItemModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchBolDocument();
    fetchValidPorts();
  }, [bolId]);

  const fetchBolDocument = async () => {
    try {
      setLoading(true);
      const response = await bolApi.getBolDocumentById(bolId);
      const doc = response.data;
      
      setFormData({
        docNbr: doc.docNbr,
        consigneeName: doc.consigneeName,
        portOfDestination: doc.portOfDestination
      });
      
      setItems(doc.items || []);
      setError(null);
    } catch (err) {
      setError('Failed to fetch BOL document');
      console.error('Error fetching BOL document:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchValidPorts = async () => {
    try {
      const response = await bolApi.getValidPorts();
      setValidPorts(response.data);
    } catch (err) {
      console.error('Error fetching valid ports:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddItem = () => {
    setEditingItem(null);
    setShowItemModal(true);
  };

  const handleEditItem = (itemIndex) => {
    setEditingItem(itemIndex);
    setShowItemModal(true);
  };

  const handleDeleteItem = (itemIndex) => {
    setItems(prev => prev.filter((_, index) => index !== itemIndex));
  };

  const handleSaveItem = (itemData) => {
    if (editingItem !== null) {
      // Edit existing item
      setItems(prev => prev.map((item, index) => 
        index === editingItem ? { ...itemData, skey: item.skey } : item
      ));
    } else {
      // Add new item
      setItems(prev => [...prev, { ...itemData, skey: Date.now() }]);
    }
    setShowItemModal(false);
    setEditingItem(null);
  };

  const handleSave = async () => {
    if (!formData.docNbr || !formData.consigneeName || !formData.portOfDestination) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      
      const bolData = {
        docType: 'BOL',
        docNbr: formData.docNbr,
        consigneeName: formData.consigneeName,
        portOfDestination: formData.portOfDestination,
        items: items
      };

      await bolApi.updateBolDocument(bolId, bolData);
      onSuccess();
    } catch (err) {
      // Extract error message from axios response
      let errorMessage = 'Failed to update BOL document';
      if (err.response && err.response.data && err.response.data.error) {
        errorMessage = err.response.data.error;
      } else if (err.message) {
        errorMessage = err.message;
      }
      setError(errorMessage);
      console.error('Error updating BOL document:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !formData.docNbr) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-header">
            <h3 className="modal-title">Error</h3>
            <button className="close" onClick={onClose}>×</button>
          </div>
          <div className="modal-body text-center text-danger">
            Error: {error}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal">
      <div className="modal-content edit-bol-modal">
        <div className="modal-header">
          <h3 className="modal-title">Edit Bill of Lading</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="bol-form">
            {/* Header Section */}
            <div className="form-section">
              <h4>BOL Header</h4>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Document Number *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="docNbr"
                      value={formData.docNbr}
                      onChange={handleInputChange}
                      placeholder="Enter document number"
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Consignee Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="consigneeName"
                      value={formData.consigneeName}
                      onChange={handleInputChange}
                      placeholder="Enter consignee name"
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Port of Destination *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="portOfDestination"
                      value={formData.portOfDestination}
                      onChange={handleInputChange}
                      placeholder="Enter port code (e.g., USLAX, SGSIN, CNHKG)"
                    />
                    <small className="form-text text-muted">
                      Valid ports: {validPorts.join(', ')}
                    </small>
                  </div>
                </div>
              </div>
            </div>

            {/* Items Section */}
            <div className="form-section">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h4>BOL Items</h4>
                <button className="btn btn-success btn-sm" onClick={handleAddItem}>
                  Add Item
                </button>
              </div>
              
              <div className="items-panel">
                {items.length === 0 ? (
                  <div className="empty-state">
                    No items added yet. Click "Add Item" to add BOL items.
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="table">
                      <thead>
                        <tr>
                          <th>Cargo Description</th>
                          <th>Quantity</th>
                          <th>Weight</th>
                          <th>Volume</th>
                          <th>Marks</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((item, index) => (
                          <tr key={item.skey || index}>
                            <td>{item.cargoDescription}</td>
                            <td>{item.qty}</td>
                            <td>{item.weight}</td>
                            <td>{item.volume || 'N/A'}</td>
                            <td>{item.marks || 'N/A'}</td>
                            <td>
                              <button
                                className="btn btn-sm btn-warning"
                                onClick={() => handleEditItem(index)}
                              >
                                Edit
                              </button>
                              <button
                                className="btn btn-sm btn-danger"
                                onClick={() => handleDeleteItem(index)}
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {showItemModal && (
        <BolItemModal
          item={editingItem !== null ? items[editingItem] : null}
          onSave={handleSaveItem}
          onCancel={() => {
            setShowItemModal(false);
            setEditingItem(null);
          }}
        />
      )}
    </div>
  );
};

export default EditBolModal;
