import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import TaskSelectionModal from './TaskSelectionModal';
import TaskConfigModal from './TaskConfigModal';
import './AddTaskGroupModal.css';

const AddTaskGroupModal = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    code: '',
    entityCode: '',
    taskExecMode: '',
    taskErrorHandleMode: ''
  });
  const [advmDocs, setAdvmDocs] = useState([]);
  const [advmItems, setAdvmItems] = useState([]);
  const [advmSteps, setAdvmSteps] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);
  const [taskExecModes, setTaskExecModes] = useState([]);
  const [taskErrorHandleModes, setTaskErrorHandleModes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [showTaskSelection, setShowTaskSelection] = useState(false);
  const [showTaskConfig, setShowTaskConfig] = useState(false);
  const [editingTaskIndex, setEditingTaskIndex] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  // Watch for changes in selections and update entity code
  useEffect(() => {
    // Only update if we have the necessary data loaded
    if (advmDocs && advmDocs.length > 0) {
      updateEntityCode();
    }
  }, [selectedDoc, selectedItem, selectedStep, advmDocs, advmItems, advmSteps]);

  const fetchInitialData = async () => {
    try {
      const [docsRes, execModesRes, errorModesRes] = await Promise.all([
        bizTaskApi.getAllAdvmDocs(),
        bizTaskApi.getTaskExecModes(),
        bizTaskApi.getTaskErrorHandleModes()
      ]);
      
      setAdvmDocs(docsRes.data);
      setTaskExecModes(execModesRes.data);
      setTaskErrorHandleModes(errorModesRes.data);
    } catch (err) {
      console.error('Error fetching initial data:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDocChange = async (docSkey) => {
    setSelectedDoc(docSkey);
    setSelectedItem(null);
    setSelectedStep(null);
    setAdvmItems([]);
    setAdvmSteps([]);
    
    if (docSkey) {
      try {
        const response = await bizTaskApi.getAdvmItemsByDocSkey(docSkey);
        setAdvmItems(response.data);
      } catch (err) {
        console.error('Error fetching items:', err);
      }
    }
  };

  const handleItemChange = async (itemSkey) => {
    setSelectedItem(itemSkey);
    setSelectedStep(null);
    setAdvmSteps([]);
    
    if (itemSkey) {
      try {
        const response = await bizTaskApi.getAdvmStepsByItemSkey(itemSkey);
        setAdvmSteps(response.data);
      } catch (err) {
        console.error('Error fetching steps:', err);
      }
    }
  };

  const handleStepChange = (stepSkey) => {
    setSelectedStep(stepSkey);
  };

  const updateEntityCode = () => {
    let entityCode = '';
    
    console.log('updateEntityCode called with:', {
      selectedDoc,
      selectedItem,
      selectedStep,
      advmDocsLength: advmDocs?.length,
      advmItemsLength: advmItems?.length,
      advmStepsLength: advmSteps?.length
    });
    
    // Priority: Step > Item > Document (last selected determines entity code)
    if (selectedStep && advmSteps && advmSteps.length > 0) {
      const step = advmSteps.find(s => s.skey === selectedStep);
      entityCode = step ? step.entityCode : '';
      console.log('Entity code set from Step:', entityCode, 'Step found:', step);
    } else if (selectedItem && advmItems && advmItems.length > 0) {
      const item = advmItems.find(i => i.skey === selectedItem);
      entityCode = item ? item.entityCode : '';
      console.log('Entity code set from Item:', entityCode, 'Item found:', item);
    } else if (selectedDoc && advmDocs && advmDocs.length > 0) {
      const doc = advmDocs.find(d => d.skey === selectedDoc);
      entityCode = doc ? doc.entityCode : '';
      console.log('Entity code set from Document:', entityCode, 'Doc found:', doc);
    }
    
    console.log('Final entity code:', entityCode);
    
    setFormData(prev => ({
      ...prev,
      entityCode: entityCode
    }));
  };

  const handleAddTask = () => {
    if (!formData.entityCode) {
      setError('Please select an entity code first');
      return;
    }
    setShowTaskSelection(true);
  };

  const handleTaskSelect = (task) => {
    setSelectedTask(task);
    setShowTaskSelection(false);
    setShowTaskConfig(true);
    setEditingTaskIndex(null);
  };

  const handleTaskConfigSave = (taskData) => {
    // Ensure the task object is properly structured
    const structuredTaskData = {
      ...taskData,
      task: taskData.task || {
        entityCode: formData.entityCode,
        implementationClass: taskData.taskCode || '',
        code: taskData.taskCode || ''
      }
    };

    if (editingTaskIndex !== null) {
      // Edit existing task
      const newTasks = [...tasks];
      newTasks[editingTaskIndex] = structuredTaskData;
      setTasks(newTasks);
    } else {
      // Add new task
      setTasks([...tasks, structuredTaskData]);
    }
    setShowTaskConfig(false);
    setEditingTaskIndex(null);
  };

  const handleEditTask = (index) => {
    setSelectedTask(tasks[index].task);
    setEditingTaskIndex(index);
    setShowTaskConfig(true);
  };

  const handleDeleteTask = (index) => {
    const newTasks = tasks.filter((_, i) => i !== index);
    setTasks(newTasks);
  };

  const handleSelectTask = (index) => {
    setSelectedTaskIndex(index);
  };

  const handleMoveTaskUp = () => {
    if (selectedTaskIndex !== null && selectedTaskIndex > 0) {
      const newTasks = [...tasks];
      [newTasks[selectedTaskIndex - 1], newTasks[selectedTaskIndex]] = [newTasks[selectedTaskIndex], newTasks[selectedTaskIndex - 1]];
      setTasks(newTasks);
      setSelectedTaskIndex(selectedTaskIndex - 1);
    }
  };

  const handleMoveTaskDown = () => {
    if (selectedTaskIndex !== null && selectedTaskIndex < tasks.length - 1) {
      const newTasks = [...tasks];
      [newTasks[selectedTaskIndex], newTasks[selectedTaskIndex + 1]] = [newTasks[selectedTaskIndex + 1], newTasks[selectedTaskIndex]];
      setTasks(newTasks);
      setSelectedTaskIndex(selectedTaskIndex + 1);
    }
  };

  const handleSave = async () => {
    if (!formData.code || !formData.entityCode || !formData.taskExecMode || !formData.taskErrorHandleMode) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const taskGroupData = {
        code: formData.code,
        entityCode: formData.entityCode,
        taskExecMode: formData.taskExecMode,
        taskErrorHandleMode: formData.taskErrorHandleMode,
        details: tasks.map((task, index) => ({
          taskCode: task.taskCode,
          taskOrder: index + 1,
          timing: task.timing,
          isMandatory: task.isMandatory,
          bizpTask: {
            entityCode: task.task?.entityCode || formData.entityCode,
            implementationClass: task.task?.implementationClass || task.taskCode,
            isActive: task.isActive,
            params: task.params || []
          }
        }))
      };

      await bizTaskApi.createTaskGroup(taskGroupData);
      onSuccess();
    } catch (err) {
      setError('Failed to save task group');
      console.error('Error saving task group:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal">
      <div className="modal-content add-task-group-modal">
        <div className="modal-header">
          <h3 className="modal-title">Add Task Group</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="task-group-form">
            {/* Basic Information */}
            <div className="form-section">
              <h4>Basic Information</h4>
              <div className="row">
                <div className="col-md-6">
                  <div className="form-group">
                    <label className="form-label">Group Code *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="code"
                      value={formData.code}
                      onChange={handleInputChange}
                      placeholder="Enter group code"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label className="form-label">Entity Code</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.entityCode}
                      readOnly
                      placeholder="Will be set based on selection below"
                      style={{ 
                        backgroundColor: formData.entityCode ? '#e8f5e8' : '#f8f9fa',
                        fontWeight: formData.entityCode ? 'bold' : 'normal'
                      }}
                    />
                    {formData.entityCode && (
                      <small className="text-muted">
                        Selected: {formData.entityCode}
                      </small>
                    )}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-6">
                  <div className="form-group">
                    <label className="form-label">Execution Mode *</label>
                    <select
                      className="form-control"
                      name="taskExecMode"
                      value={formData.taskExecMode}
                      onChange={handleInputChange}
                    >
                      <option value="">Select execution mode</option>
                      {taskExecModes.map(mode => (
                        <option key={mode} value={mode}>
                          {mode}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group">
                    <label className="form-label">Error Handle Mode *</label>
                    <select
                      className="form-control"
                      name="taskErrorHandleMode"
                      value={formData.taskErrorHandleMode}
                      onChange={handleInputChange}
                    >
                      <option value="">Select error handle mode</option>
                      {taskErrorHandleModes.map(mode => (
                        <option key={mode} value={mode}>
                          {mode}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Entity Selection */}
            <div className="form-section">
              <h4>Entity Selection</h4>
              <p className="text-muted" style={{ fontSize: '14px', marginBottom: '15px' }}>
                Select the hierarchy level to determine the entity code. The entity code will be set to the <strong>last selected item</strong> in the hierarchy.
              </p>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Document</label>
                    <select
                      className="form-control"
                      value={selectedDoc || ''}
                      onChange={(e) => handleDocChange(e.target.value ? parseInt(e.target.value) : null)}
                    >
                      <option value="">Select document</option>
                      {advmDocs.map(doc => (
                        <option key={doc.skey} value={doc.skey}>
                          {doc.entityCode}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Item</label>
                    <select
                      className="form-control"
                      value={selectedItem || ''}
                      onChange={(e) => handleItemChange(e.target.value ? parseInt(e.target.value) : null)}
                      disabled={!selectedDoc}
                    >
                      <option value="">Select item</option>
                      {advmItems.map(item => (
                        <option key={item.skey} value={item.skey}>
                          {item.entityCode}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label className="form-label">Step</label>
                    <select
                      className="form-control"
                      value={selectedStep || ''}
                      onChange={(e) => handleStepChange(e.target.value ? parseInt(e.target.value) : null)}
                      disabled={!selectedItem}
                    >
                      <option value="">Select step</option>
                      {advmSteps.map(step => (
                        <option key={step.skey} value={step.skey}>
                          {step.entityCode}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Task Configuration */}
            <div className="form-section">
              <div className="section-header">
                <h4>Task Configuration</h4>
                <div className="task-controls">
                  <button 
                    className="btn btn-primary"
                    onClick={handleAddTask}
                    disabled={!formData.entityCode}
                  >
                    Add Task
                  </button>
                  {tasks.length > 0 && (
                    <div className="order-controls-panel">
                      <button 
                        className="btn btn-outline-secondary order-btn"
                        onClick={handleMoveTaskUp}
                        disabled={selectedTaskIndex === null || selectedTaskIndex === 0}
                        title="Move Selected Task Up"
                      >
                        ↑ Move Up
                      </button>
                      <button 
                        className="btn btn-outline-secondary order-btn"
                        onClick={handleMoveTaskDown}
                        disabled={selectedTaskIndex === null || selectedTaskIndex === tasks.length - 1}
                        title="Move Selected Task Down"
                      >
                        ↓ Move Down
                      </button>
                      {selectedTaskIndex !== null && (
                        <span className="selected-info">
                          Selected: Task {selectedTaskIndex + 1}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
              
              {tasks.length === 0 ? (
                <div className="empty-state">
                  No tasks configured. Click "Add Task" to add tasks to this group.
                </div>
              ) : (
                <div className="tasks-table">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Order</th>
                        <th>Task Code</th>
                        <th>Implementation Class</th>
                        <th>Timing</th>
                        <th>Active</th>
                        <th>Mandatory</th>
                        <th>Params</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasks.map((task, index) => (
                        <tr 
                          key={index}
                          className={`task-row ${selectedTaskIndex === index ? 'selected' : ''}`}
                          onClick={() => handleSelectTask(index)}
                        >
                          <td className="order-cell">
                            <span className="order-number">{index + 1}</span>
                          </td>
                          <td>{task.taskCode}</td>
                          <td className="code-cell">{task.task?.implementationClass || 'N/A'}</td>
                          <td>{task.timing}</td>
                          <td>
                            <span className={`badge ${task.isActive ? 'badge-success' : 'badge-secondary'}`}>
                              {task.isActive ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${task.isMandatory ? 'badge-warning' : 'badge-secondary'}`}>
                              {task.isMandatory ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td>{task.params ? task.params.length : 0}</td>
                          <td>
                            <button 
                              className="btn btn-sm btn-warning"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditTask(index);
                              }}
                            >
                              Edit
                            </button>
                            <button 
                              className="btn btn-sm btn-danger"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteTask(index);
                              }}
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>

      {/* Task Selection Modal */}
      {showTaskSelection && (
        <TaskSelectionModal
          entityCode={formData.entityCode}
          onSelect={handleTaskSelect}
          onClose={() => setShowTaskSelection(false)}
        />
      )}

      {/* Task Configuration Modal */}
      {showTaskConfig && (
        <TaskConfigModal
          task={selectedTask}
          onSave={handleTaskConfigSave}
          onClose={() => {
            setShowTaskConfig(false);
            setEditingTaskIndex(null);
            setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
};

export default AddTaskGroupModal;
