import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import './TaskSelectionModal.css';

const TaskSelectionModal = ({ entityCode, onSelect, onClose }) => {
  const [availableTasks, setAvailableTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchAvailableTasks();
  }, [entityCode]);

  const fetchAvailableTasks = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await bizTaskApi.getActiveTasksByEntityCode(entityCode);
      setAvailableTasks(response.data);
    } catch (err) {
      setError('Failed to fetch available tasks');
      console.error('Error fetching tasks:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleTaskSelect = (task) => {
    onSelect(task);
    onClose();
  };

  const filteredTasks = availableTasks.filter(task =>
    task.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    task.implementationClass.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="modal">
        <div className="modal-content task-selection-modal">
          <div className="modal-header">
            <h3 className="modal-title">Select Task</h3>
            <button className="close" onClick={onClose}>×</button>
          </div>
          <div className="modal-body text-center">
            <div>Loading available tasks...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal">
      <div className="modal-content task-selection-modal">
        <div className="modal-header">
          <h3 className="modal-title">Select Task for {entityCode}</h3>
          <button className="close" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="search-section">
            <input
              type="text"
              className="form-control"
              placeholder="Search tasks by code or implementation class..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="tasks-list">
            {filteredTasks.length === 0 ? (
              <div className="empty-state">
                {searchTerm ? 'No tasks found matching your search.' : 'No available tasks for this entity.'}
              </div>
            ) : (
              filteredTasks.map((task) => (
                <div key={task.skey} className="task-item" onClick={() => handleTaskSelect(task)}>
                  <div className="task-info">
                    <div className="task-code">{task.code}</div>
                    <div className="task-class">{task.implementationClass}</div>
                    <div className="task-entity">{task.entityCode}</div>
                  </div>
                  <div className="task-actions">
                    <button className="btn btn-sm btn-primary">Select</button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskSelectionModal;
