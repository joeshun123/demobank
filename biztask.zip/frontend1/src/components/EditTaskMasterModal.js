import React, { useState, useEffect } from 'react';
import { bizTaskApi } from '../services/bizTaskApi';
import './EditTaskMasterModal.css';

const EditTaskMasterModal = ({ taskMasterId, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    code: '',
    entityCode: '',
    implementationClass: '',
    isActive: false,
    parameters: ''
  });
  const [parameters, setParameters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTaskMaster();
  }, [taskMasterId]);

  const fetchTaskMaster = async () => {
    try {
      setLoading(true);
      const response = await bizTaskApi.getTaskMasterById(taskMasterId);
      const taskMaster = response.data;
      
      setFormData({
        code: taskMaster.code,
        entityCode: taskMaster.entityCode,
        implementationClass: taskMaster.implementationClass,
        isActive: taskMaster.isActive,
        parameters: taskMaster.parameters || ''
      });
      
      // Parse parameters JSON if it exists
      if (taskMaster.parameters) {
        try {
          const parsedParams = JSON.parse(taskMaster.parameters);
          const paramArray = Object.entries(parsedParams).map(([key, value]) => ({ key, value }));
          setParameters(paramArray);
        } catch (e) {
          console.error('Error parsing parameters:', e);
          setParameters([]);
        }
      } else {
        setParameters([]);
      }
      
      setError(null);
    } catch (err) {
      setError('Failed to fetch task master');
      console.error('Error fetching task master:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const addParameter = () => {
    setParameters(prev => [...prev, { key: '', value: '' }]);
  };

  const removeParameter = (index) => {
    setParameters(prev => prev.filter((_, i) => i !== index));
  };

  const updateParameter = (index, field, value) => {
    setParameters(prev => prev.map((param, i) => 
      i === index ? { ...param, [field]: value } : param
    ));
  };

  const convertParametersToJson = () => {
    if (parameters.length === 0) return '';
    const paramObj = {};
    parameters.forEach(param => {
      if (param.key && param.value) {
        paramObj[param.key] = param.value;
      }
    });
    return Object.keys(paramObj).length > 0 ? JSON.stringify(paramObj) : '';
  };

  const handleSave = async () => {
    if (!formData.code || !formData.entityCode || !formData.implementationClass) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      
      const parametersJson = convertParametersToJson();
      const taskMasterData = {
        ...formData,
        parameters: parametersJson
      };
      
      await bizTaskApi.updateTaskMaster(taskMasterId, taskMasterData);
      onSuccess();
    } catch (err) {
      const errorMessage = err.response?.data?.error || err.response?.data?.message || err.message || 'Failed to update task master';
      setError(errorMessage);
      console.error('Error updating task master:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-body text-center">
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }

  if (error && !formData.code) {
    return (
      <div className="modal">
        <div className="modal-content">
          <div className="modal-header">
            <h3 className="modal-title">Error</h3>
            <button className="close" onClick={onClose}>×</button>
          </div>
          <div className="modal-body text-center text-danger">
            Error: {error}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal">
      <div className="modal-content edit-task-master-modal">
        <div className="modal-header">
          <h3 className="modal-title">Edit Task Master</h3>
          <button className="close" onClick={onClose}>
            ×
          </button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="alert alert-danger">
              {error}
            </div>
          )}

          <div className="task-master-form">
            <div className="form-group">
              <label className="form-label">Code *</label>
              <input
                type="text"
                className="form-control"
                name="code"
                value={formData.code}
                onChange={handleInputChange}
                placeholder="Enter task code"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Entity Code *</label>
              <input
                type="text"
                className="form-control"
                name="entityCode"
                value={formData.entityCode}
                onChange={handleInputChange}
                placeholder="Enter entity code"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Implementation Class *</label>
              <input
                type="text"
                className="form-control"
                name="implementationClass"
                value={formData.implementationClass}
                onChange={handleInputChange}
                placeholder="Enter implementation class"
                required
              />
            </div>

            <div className="form-group">
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  name="isActive"
                  checked={formData.isActive}
                  onChange={handleInputChange}
                  id="isActive"
                />
                <label className="form-check-label" htmlFor="isActive">
                  Active
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Parameters</label>
              <div className="parameters-section">
                {parameters.map((param, index) => (
                  <div key={index} className="parameter-row">
                    <input
                      type="text"
                      className="form-control parameter-key"
                      placeholder="Key"
                      value={param.key}
                      onChange={(e) => updateParameter(index, 'key', e.target.value)}
                    />
                    <input
                      type="text"
                      className="form-control parameter-value"
                      placeholder="Value"
                      value={param.value}
                      onChange={(e) => updateParameter(index, 'value', e.target.value)}
                    />
                    <button
                      type="button"
                      className="btn btn-sm btn-danger"
                      onClick={() => removeParameter(index)}
                    >
                      Remove
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-sm btn-outline-primary"
                  onClick={addParameter}
                >
                  Add Parameter
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button 
            className="btn btn-primary" 
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditTaskMasterModal;
