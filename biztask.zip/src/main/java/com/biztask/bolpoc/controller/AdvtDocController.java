package com.biztask.bolpoc.controller;

import com.biztask.bolpoc.dto.AdvtDocDto;
import com.biztask.bolpoc.service.AdvtDocService;
import com.biztask.bolpoc.execution.TaskExecutionService;
import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.exception.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/bol")
@CrossOrigin(origins = "http://localhost:3000")
public class AdvtDocController {
    
    @Autowired
    private AdvtDocService advtDocService;
    
    @Autowired
    private TaskExecutionService taskExecutionService;
    
    @GetMapping
    public ResponseEntity<List<AdvtDocDto>> getAllBolDocuments() {
        List<AdvtDocDto> documents = advtDocService.getAllBolDocuments();
        return ResponseEntity.ok(documents);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<AdvtDocDto> getBolDocumentById(@PathVariable Long id) {
        return advtDocService.getBolDocumentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<?> createBolDocument(@Valid @RequestBody AdvtDocDto dto) {
        try {
            // Create the BOL document (includes validation tasks)
            AdvtDocDto created = advtDocService.createBolDocument(dto);
            
            // Return the created document
            Map<String, Object> response = new HashMap<>();
            response.put("document", created);
            response.put("message", "BOL document created successfully");
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (ValidationException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("error", "Failed to create BOL document: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBolDocument(@PathVariable Long id, @Valid @RequestBody AdvtDocDto dto) {
        try {
            // Update the BOL document (includes validation tasks)
            AdvtDocDto updated = advtDocService.updateBolDocument(id, dto);
            
            // Return the updated document
            Map<String, Object> response = new HashMap<>();
            response.put("document", updated);
            response.put("message", "BOL document updated successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBolDocument(@PathVariable Long id) {
        try {
            // Delete the BOL document (includes validation tasks)
            advtDocService.deleteBolDocument(id);
            
            // Return success message
            Map<String, Object> response = new HashMap<>();
            response.put("message", "BOL document deleted successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @GetMapping("/ports")
    public ResponseEntity<List<String>> getValidPorts() {
        List<String> ports = advtDocService.getValidPorts();
        return ResponseEntity.ok(ports);
    }
    
    @GetMapping("/execution-engines/status")
    public ResponseEntity<Map<String, Boolean>> getExecutionEngineStatus() {
        Map<String, Boolean> status = taskExecutionService.getEngineStatus();
        return ResponseEntity.ok(status);
    }
}
