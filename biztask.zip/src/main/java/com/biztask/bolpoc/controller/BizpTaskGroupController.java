package com.biztask.bolpoc.controller;

import com.biztask.bolpoc.dto.*;
import com.biztask.bolpoc.service.BizpTaskGroupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/biztask")
@CrossOrigin(origins = "http://localhost:3000")
public class BizpTaskGroupController {
    
    @Autowired
    private BizpTaskGroupService bizpTaskGroupService;
    
    // Task Group operations
    @GetMapping("/groups")
    public ResponseEntity<List<BizpTaskGroupDto>> getAllTaskGroups() {
        List<BizpTaskGroupDto> groups = bizpTaskGroupService.getAllTaskGroups();
        return ResponseEntity.ok(groups);
    }
    
    @GetMapping("/groups/{id}")
    public ResponseEntity<BizpTaskGroupDto> getTaskGroupById(@PathVariable Long id) {
        log.info("Getting task group with id: {}", id);
        try {
            return bizpTaskGroupService.getTaskGroupById(id)
                    .map(taskGroup -> {
                        log.info("Successfully retrieved task group with id: {}", id);
                        return ResponseEntity.ok(taskGroup);
                    })
                    .orElseGet(() -> {
                        log.warn("Task group not found with id: {}", id);
                        return ResponseEntity.notFound().build();
                    });
        } catch (Exception e) {
            log.error("Error getting task group with id: {}, error: {}", id, e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PostMapping("/groups")
    public ResponseEntity<BizpTaskGroupDto> createTaskGroup(@Valid @RequestBody BizpTaskGroupDto dto) {
        log.info("Creating task group with data: {}", dto);
        try {
            BizpTaskGroupDto created = bizpTaskGroupService.createTaskGroup(dto);
            log.info("Successfully created task group with id: {}", created.getSkey());
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            log.error("Error creating task group, error: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/groups/{id}")
    public ResponseEntity<?> updateTaskGroup(@PathVariable Long id, @Valid @RequestBody BizpTaskGroupDto dto) {
        log.info("Updating task group with id: {}, data: {}", id, dto);
        try {
            BizpTaskGroupDto updated = bizpTaskGroupService.updateTaskGroup(id, dto);
            log.info("Successfully updated task group with id: {}, result: {}", id, updated);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            log.error("Error updating task group with id: {}, error: {}", id, e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @DeleteMapping("/groups/{id}")
    public ResponseEntity<Void> deleteTaskGroup(@PathVariable Long id) {
        try {
            bizpTaskGroupService.deleteTaskGroup(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Metadata operations
    @GetMapping("/metadata/docs")
    public ResponseEntity<List<AdvmDocDto>> getAllAdvmDocs() {
        List<AdvmDocDto> docs = bizpTaskGroupService.getAllAdvmDocs();
        return ResponseEntity.ok(docs);
    }
    
    @GetMapping("/metadata/items/{docSkey}")
    public ResponseEntity<List<AdvmItemDto>> getAdvmItemsByDocSkey(@PathVariable Long docSkey) {
        List<AdvmItemDto> items = bizpTaskGroupService.getAdvmItemsByDocSkey(docSkey);
        return ResponseEntity.ok(items);
    }
    
    @GetMapping("/metadata/steps/{itemSkey}")
    public ResponseEntity<List<AdvmStepDto>> getAdvmStepsByItemSkey(@PathVariable Long itemSkey) {
        List<AdvmStepDto> steps = bizpTaskGroupService.getAdvmStepsByItemSkey(itemSkey);
        return ResponseEntity.ok(steps);
    }
    
    @GetMapping("/master-tasks/{entityCode}")
    public ResponseEntity<List<BizmTaskMasterDto>> getActiveTasksByEntityCode(@PathVariable String entityCode) {
        List<BizmTaskMasterDto> tasks = bizpTaskGroupService.getActiveTasksByEntityCode(entityCode);
        return ResponseEntity.ok(tasks);
    }
    
    // Configuration options
    @GetMapping("/config/exec-modes")
    public ResponseEntity<List<String>> getTaskExecModes() {
        List<String> modes = bizpTaskGroupService.getTaskExecModes();
        return ResponseEntity.ok(modes);
    }
    
    @GetMapping("/config/error-handle-modes")
    public ResponseEntity<List<String>> getTaskErrorHandleModes() {
        List<String> modes = bizpTaskGroupService.getTaskErrorHandleModes();
        return ResponseEntity.ok(modes);
    }
    
    @GetMapping("/config/timing-options")
    public ResponseEntity<List<String>> getTimingOptions() {
        List<String> options = bizpTaskGroupService.getTimingOptions();
        return ResponseEntity.ok(options);
    }
    
    // Task Master operations
    @GetMapping("/task-masters")
    public ResponseEntity<List<BizmTaskMasterDto>> getAllTaskMasters() {
        List<BizmTaskMasterDto> taskMasters = bizpTaskGroupService.getAllTaskMasters();
        return ResponseEntity.ok(taskMasters);
    }
    
    @GetMapping("/task-masters/{id}")
    public ResponseEntity<BizmTaskMasterDto> getTaskMasterById(@PathVariable Long id) {
        log.info("Getting task master with id: {}", id);
        try {
            return bizpTaskGroupService.getTaskMasterById(id)
                    .map(taskMaster -> {
                        log.info("Successfully retrieved task master with id: {}", id);
                        return ResponseEntity.ok(taskMaster);
                    })
                    .orElseGet(() -> {
                        log.warn("Task master not found with id: {}", id);
                        return ResponseEntity.notFound().build();
                    });
        } catch (Exception e) {
            log.error("Error getting task master with id: {}, error: {}", id, e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PostMapping("/task-masters")
    public ResponseEntity<BizmTaskMasterDto> createTaskMaster(@Valid @RequestBody BizmTaskMasterDto dto) {
        log.info("Creating task master with data: {}", dto);
        try {
            BizmTaskMasterDto created = bizpTaskGroupService.createTaskMaster(dto);
            log.info("Successfully created task master with id: {}", created.getSkey());
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            log.error("Error creating task master, error: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/task-masters/{id}")
    public ResponseEntity<?> updateTaskMaster(@PathVariable Long id, @Valid @RequestBody BizmTaskMasterDto dto) {
        log.info("Updating task master with id: {}, data: {}", id, dto);
        try {
            BizmTaskMasterDto updated = bizpTaskGroupService.updateTaskMaster(id, dto);
            log.info("Successfully updated task master with id: {}, result: {}", id, updated);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            log.error("Error updating task master with id: {}, error: {}", id, e.getMessage(), e);
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    
    @DeleteMapping("/task-masters/{id}")
    public ResponseEntity<Void> deleteTaskMaster(@PathVariable Long id) {
        try {
            bizpTaskGroupService.deleteTaskMaster(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            log.error("Error deleting task master with id: {}, error: {}", id, e.getMessage(), e);
            return ResponseEntity.notFound().build();
        }
    }
}
