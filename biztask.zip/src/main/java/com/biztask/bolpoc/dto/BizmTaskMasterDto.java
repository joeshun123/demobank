package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class BizmTaskMasterDto {
    
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    @NotBlank(message = "Task code is required")
    private String code;
    
    @NotBlank(message = "Implementation class is required")
    private String implementationClass;
    
    @NotNull(message = "Is active is required")
    private Boolean isActive = false;
    
    private String parameters; // JSON string for key/value parameters
    
    // Constructors
    public BizmTaskMasterDto() {}
    
    public BizmTaskMasterDto(Long skey, String entityCode, String code, String implementationClass, Boolean isActive) {
        this.skey = skey;
        this.entityCode = entityCode;
        this.code = code;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
    }
    
    public BizmTaskMasterDto(Long skey, String entityCode, String code, String implementationClass, Boolean isActive, String parameters) {
        this.skey = skey;
        this.entityCode = entityCode;
        this.code = code;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
        this.parameters = parameters;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getImplementationClass() {
        return implementationClass;
    }
    
    public void setImplementationClass(String implementationClass) {
        this.implementationClass = implementationClass;
    }
    
    public Boolean getIsActive() {
        return isActive;
    }
    
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    
    public String getParameters() {
        return parameters;
    }
    
    public void setParameters(String parameters) {
        this.parameters = parameters;
    }
}
