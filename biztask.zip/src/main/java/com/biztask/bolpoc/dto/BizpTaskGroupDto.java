package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public class BizpTaskGroupDto {
    
    private Long skey;
    
    @NotBlank(message = "Group code is required")
    private String code;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    @NotBlank(message = "Task execution mode is required")
    private String taskExecMode;
    
    @NotBlank(message = "Task error handle mode is required")
    private String taskErrorHandleMode;
    
    @NotBlank(message = "Task execution engine is required")
    private String taskExecEngine;
    
    private List<BizpTaskGroupDetailDto> details;
    
    private int taskCount;
    
    // Constructors
    public BizpTaskGroupDto() {}
    
    public BizpTaskGroupDto(Long skey, String code, String entityCode, String taskExecMode, String taskErrorHandleMode) {
        this.skey = skey;
        this.code = code;
        this.entityCode = entityCode;
        this.taskExecMode = taskExecMode;
        this.taskErrorHandleMode = taskErrorHandleMode;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public String getTaskExecMode() {
        return taskExecMode;
    }
    
    public void setTaskExecMode(String taskExecMode) {
        this.taskExecMode = taskExecMode;
    }
    
    public String getTaskErrorHandleMode() {
        return taskErrorHandleMode;
    }
    
    public void setTaskErrorHandleMode(String taskErrorHandleMode) {
        this.taskErrorHandleMode = taskErrorHandleMode;
    }
    
    public String getTaskExecEngine() {
        return taskExecEngine;
    }
    
    public void setTaskExecEngine(String taskExecEngine) {
        this.taskExecEngine = taskExecEngine;
    }
    
    public List<BizpTaskGroupDetailDto> getDetails() {
        return details;
    }
    
    public void setDetails(List<BizpTaskGroupDetailDto> details) {
        this.details = details;
    }
    
    public int getTaskCount() {
        return taskCount;
    }
    
    public void setTaskCount(int taskCount) {
        this.taskCount = taskCount;
    }
}
