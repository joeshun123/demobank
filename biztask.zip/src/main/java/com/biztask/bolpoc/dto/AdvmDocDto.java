package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public class AdvmDocDto {
    
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    private List<AdvmItemDto> items;
    
    // Constructors
    public AdvmDocDto() {}
    
    public AdvmDocDto(Long skey, String entityCode) {
        this.skey = skey;
        this.entityCode = entityCode;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public List<AdvmItemDto> getItems() {
        return items;
    }
    
    public void setItems(List<AdvmItemDto> items) {
        this.items = items;
    }
}
