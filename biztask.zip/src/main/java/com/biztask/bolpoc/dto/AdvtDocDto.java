package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class AdvtDocDto {
    
    private Long skey;
    
    @NotBlank(message = "Document type is required")
    private String docType;
    
    @NotBlank(message = "Document number is required")
    private String docNbr;
    
    @NotBlank(message = "Consignee name is required")
    private String consigneeName;
    
    @NotBlank(message = "Port of destination is required")
    private String portOfDestination;
    
    private List<AdvtDocItemDto> items;
    
    // Constructors
    public AdvtDocDto() {}
    
    public AdvtDocDto(Long skey, String docType, String docNbr, String consigneeName, String portOfDestination) {
        this.skey = skey;
        this.docType = docType;
        this.docNbr = docNbr;
        this.consigneeName = consigneeName;
        this.portOfDestination = portOfDestination;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getDocType() {
        return docType;
    }
    
    public void setDocType(String docType) {
        this.docType = docType;
    }
    
    public String getDocNbr() {
        return docNbr;
    }
    
    public void setDocNbr(String docNbr) {
        this.docNbr = docNbr;
    }
    
    public String getConsigneeName() {
        return consigneeName;
    }
    
    public void setConsigneeName(String consigneeName) {
        this.consigneeName = consigneeName;
    }
    
    public String getPortOfDestination() {
        return portOfDestination;
    }
    
    public void setPortOfDestination(String portOfDestination) {
        this.portOfDestination = portOfDestination;
    }
    
    public List<AdvtDocItemDto> getItems() {
        return items;
    }
    
    public void setItems(List<AdvtDocItemDto> items) {
        this.items = items;
    }
}
