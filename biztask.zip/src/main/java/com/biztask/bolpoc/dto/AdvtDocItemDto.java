package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class AdvtDocItemDto {
    
    private Long skey;
    
    private Long docKey;
    
    @NotBlank(message = "Cargo description is required")
    private String cargoDescription;
    
    @NotNull(message = "Quantity is required")
    @Positive(message = "Quantity must be positive")
    private Double qty;
    
    @NotNull(message = "Weight is required")
    @Positive(message = "Weight must be positive")
    private Double weight;
    
    private Double volume;
    
    private String marks;
    
    // Constructors
    public AdvtDocItemDto() {}
    
    public AdvtDocItemDto(Long skey, Long docKey, String cargoDescription, Double qty, Double weight, Double volume, String marks) {
        this.skey = skey;
        this.docKey = docKey;
        this.cargoDescription = cargoDescription;
        this.qty = qty;
        this.weight = weight;
        this.volume = volume;
        this.marks = marks;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public Long getDocKey() {
        return docKey;
    }
    
    public void setDocKey(Long docKey) {
        this.docKey = docKey;
    }
    
    public String getCargoDescription() {
        return cargoDescription;
    }
    
    public void setCargoDescription(String cargoDescription) {
        this.cargoDescription = cargoDescription;
    }
    
    public Double getQty() {
        return qty;
    }
    
    public void setQty(Double qty) {
        this.qty = qty;
    }
    
    public Double getWeight() {
        return weight;
    }
    
    public void setWeight(Double weight) {
        this.weight = weight;
    }
    
    public Double getVolume() {
        return volume;
    }
    
    public void setVolume(Double volume) {
        this.volume = volume;
    }
    
    public String getMarks() {
        return marks;
    }
    
    public void setMarks(String marks) {
        this.marks = marks;
    }
}
