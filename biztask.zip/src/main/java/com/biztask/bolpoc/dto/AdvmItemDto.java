package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public class AdvmItemDto {
    
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    private Long docKey;
    
    private List<AdvmStepDto> steps;
    
    // Constructors
    public AdvmItemDto() {}
    
    public AdvmItemDto(Long skey, String entityCode, Long docKey) {
        this.skey = skey;
        this.entityCode = entityCode;
        this.docKey = docKey;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public Long getDocKey() {
        return docKey;
    }
    
    public void setDocKey(Long docKey) {
        this.docKey = docKey;
    }
    
    public List<AdvmStepDto> getSteps() {
        return steps;
    }
    
    public void setSteps(List<AdvmStepDto> steps) {
        this.steps = steps;
    }
}
