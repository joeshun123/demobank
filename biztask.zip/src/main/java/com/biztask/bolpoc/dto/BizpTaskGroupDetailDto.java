package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class BizpTaskGroupDetailDto {
    
    private Long skey;
    
    @NotBlank(message = "Task code is required")
    private String taskCode;
    
    @NotNull(message = "Task is required")
    private BizpTaskDto bizpTask;
    
    @NotNull(message = "Task order is required")
    private Long taskOrder;
    
    @NotBlank(message = "Timing is required")
    private String timing;
    
    @NotNull(message = "Is mandatory is required")
    private Boolean isMandatory = false;
    
    // Constructors
    public BizpTaskGroupDetailDto() {}
    
    public BizpTaskGroupDetailDto(Long skey, String taskCode, BizpTaskDto bizpTask, Long taskOrder, String timing, Boolean isMandatory) {
        this.skey = skey;
        this.taskCode = taskCode;
        this.bizpTask = bizpTask;
        this.taskOrder = taskOrder;
        this.timing = timing;
        this.isMandatory = isMandatory;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getTaskCode() {
        return taskCode;
    }
    
    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }
    
    public BizpTaskDto getBizpTask() {
        return bizpTask;
    }
    
    public void setBizpTask(BizpTaskDto bizpTask) {
        this.bizpTask = bizpTask;
    }
    
    public Long getTaskOrder() {
        return taskOrder;
    }
    
    public void setTaskOrder(Long taskOrder) {
        this.taskOrder = taskOrder;
    }
    
    public String getTiming() {
        return timing;
    }
    
    public void setTiming(String timing) {
        this.timing = timing;
    }
    
    public Boolean getIsMandatory() {
        return isMandatory;
    }
    
    public void setIsMandatory(Boolean isMandatory) {
        this.isMandatory = isMandatory;
    }
}
