package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class BizpTaskDto {
    
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    @NotBlank(message = "Implementation class is required")
    private String implementationClass;
    
    @NotNull(message = "Is active is required")
    private Boolean isActive = false;
    
    private List<BizpTaskParamDto> params;
    
    private String parameters; // JSON string for master task parameters from BIZM_TASK_MASTER
    
    // Constructors
    public BizpTaskDto() {}
    
    public BizpTaskDto(Long skey, String entityCode, String implementationClass, Boolean isActive) {
        this.skey = skey;
        this.entityCode = entityCode;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public String getImplementationClass() {
        return implementationClass;
    }
    
    public void setImplementationClass(String implementationClass) {
        this.implementationClass = implementationClass;
    }
    
    public Boolean getIsActive() {
        return isActive;
    }
    
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    
    public List<BizpTaskParamDto> getParams() {
        return params;
    }
    
    public void setParams(List<BizpTaskParamDto> params) {
        this.params = params;
    }
    
    public String getParameters() {
        return parameters;
    }
    
    public void setParameters(String parameters) {
        this.parameters = parameters;
    }
}
