package com.biztask.bolpoc.dto;

import jakarta.validation.constraints.NotBlank;

public class AdvmStepDto {
    
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    private String entityCode;
    
    private Long itemKey;
    
    // Constructors
    public AdvmStepDto() {}
    
    public AdvmStepDto(Long skey, String entityCode, Long itemKey) {
        this.skey = skey;
        this.entityCode = entityCode;
        this.itemKey = itemKey;
    }
    
    // Getters and Setters
    public Long getSkey() {
        return skey;
    }
    
    public void setSkey(Long skey) {
        this.skey = skey;
    }
    
    public String getEntityCode() {
        return entityCode;
    }
    
    public void setEntityCode(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public Long getItemKey() {
        return itemKey;
    }
    
    public void setItemKey(Long itemKey) {
        this.itemKey = itemKey;
    }
}
