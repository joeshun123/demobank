package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ADVT_DOC")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdvtDoc {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Document type is required")
    @Column(name = "DOC_TYPE", nullable = false)
    private String docType;
    
    @NotBlank(message = "Document number is required")
    @Column(name = "DOC_NBR", nullable = false)
    private String docNbr;
    
    @NotBlank(message = "Consignee name is required")
    @Column(name = "CONSIGNEE_NAME", nullable = false)
    private String consigneeName;
    
    @NotBlank(message = "Port of destination is required")
    @Column(name = "PORT_OF_DESTINATION", nullable = false)
    private String portOfDestination;
    
    @OneToMany(mappedBy = "advtDoc", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<AdvtDocItem> items = new ArrayList<>();
    
    // Custom constructor for convenience
    public AdvtDoc(String docType, String docNbr, String consigneeName, String portOfDestination) {
        this.docType = docType;
        this.docNbr = docNbr;
        this.consigneeName = consigneeName;
        this.portOfDestination = portOfDestination;
    }
    
    public void addItem(AdvtDocItem item) {
        items.add(item);
        item.setAdvtDoc(this);
    }
    
    public void removeItem(AdvtDocItem item) {
        items.remove(item);
        item.setAdvtDoc(null);
    }
}
