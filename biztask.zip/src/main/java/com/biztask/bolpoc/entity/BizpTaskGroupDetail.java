package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "BIZP_TASK_GROUP_DETAIL")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BizpTaskGroupDetail {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GROUP_KEY", nullable = false)
    private BizpTaskGroup bizpTaskGroup;
    
    @NotBlank(message = "Task code is required")
    @Column(name = "TASK_CODE", nullable = false)
    private String taskCode;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TASK_KEY", nullable = false)
    private BizpTask bizpTask;
    
    @NotNull
    @Column(name = "TASK_ORDER", nullable = false)
    private Long taskOrder;
    
    @NotBlank(message = "Timing is required")
    @Column(name = "TIMING", nullable = false)
    private String timing;
    
    @NotNull
    @Column(name = "IS_MANDATORY", nullable = false)
    private Boolean isMandatory = false;
    
    // Custom constructor for convenience
    public BizpTaskGroupDetail(String taskCode, BizpTask bizpTask, Long taskOrder, String timing, Boolean isMandatory) {
        this.taskCode = taskCode;
        this.bizpTask = bizpTask;
        this.taskOrder = taskOrder;
        this.timing = timing;
        this.isMandatory = isMandatory;
    }
}
