package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "BIZP_TASK_PARAM")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BizpTaskParam {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TASK_KEY", nullable = false)
    private BizpTask bizpTask;
    
    @NotBlank(message = "Parameter key is required")
    @Column(name = "PARAM_KEY", nullable = false)
    private String key;
    
    @Column(name = "PARAM_VALUE")
    private String value;
    
    // Custom constructor for convenience
    public BizpTaskParam(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
