package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ADVM_ITEM")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdvmItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    @Column(name = "ENTITY_CODE", nullable = false)
    private String entityCode;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOC_KEY", nullable = false)
    private AdvmDoc advmDoc;
    
    @OneToMany(mappedBy = "advmItem", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<AdvmStep> steps = new ArrayList<>();
    
    // Custom constructor for convenience
    public AdvmItem(String entityCode, AdvmDoc advmDoc) {
        this.entityCode = entityCode;
        this.advmDoc = advmDoc;
    }
    
    public void addStep(AdvmStep step) {
        steps.add(step);
        step.setAdvmItem(this);
    }
    
    public void removeStep(AdvmStep step) {
        steps.remove(step);
        step.setAdvmItem(null);
    }
}
