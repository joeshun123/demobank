package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "BIZP_TASK_GROUP")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BizpTaskGroup {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Group code is required")
    @Column(name = "CODE", nullable = false)
    private String code;
    
    @NotBlank(message = "Entity code is required")
    @Column(name = "ENTITY_CODE", nullable = false)
    private String entityCode;
    
    @NotBlank(message = "Task execution mode is required")
    @Column(name = "TASK_EXEC_MODE", nullable = false)
    private String taskExecMode;
    
    @NotBlank(message = "Task error handle mode is required")
    @Column(name = "TASK_ERROR_HANDLE_MODE", nullable = false)
    private String taskErrorHandleMode;
    
    @NotBlank(message = "Task execution engine is required")
    @Column(name = "TASK_EXEC_ENGINE", nullable = false)
    private String taskExecEngine;
    
    @OneToMany(mappedBy = "bizpTaskGroup", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<BizpTaskGroupDetail> details = new ArrayList<>();
    
    // Custom constructor for convenience
    public BizpTaskGroup(String code, String entityCode, String taskExecMode, String taskErrorHandleMode, String taskExecEngine) {
        this.code = code;
        this.entityCode = entityCode;
        this.taskExecMode = taskExecMode;
        this.taskErrorHandleMode = taskErrorHandleMode;
        this.taskExecEngine = taskExecEngine;
    }
    
    public void addDetail(BizpTaskGroupDetail detail) {
        details.add(detail);
        detail.setBizpTaskGroup(this);
    }
    
    public void removeDetail(BizpTaskGroupDetail detail) {
        details.remove(detail);
        detail.setBizpTaskGroup(null);
    }
}
