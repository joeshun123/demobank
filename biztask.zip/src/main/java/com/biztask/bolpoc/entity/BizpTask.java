package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "BIZP_TASK")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BizpTask {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    @Column(name = "ENTITY_CODE", nullable = false)
    private String entityCode;
    
    @NotBlank(message = "Implementation class is required")
    @Column(name = "IMPLEMENTATION_CLASS", nullable = false)
    private String implementationClass;
    
    @NotNull
    @Column(name = "IS_ACTIVE", nullable = false)
    private Boolean isActive = false;
    
    @OneToMany(mappedBy = "bizpTask", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<BizpTaskParam> params = new ArrayList<>();
    
    // Custom constructor for convenience
    public BizpTask(String entityCode, String implementationClass, Boolean isActive) {
        this.entityCode = entityCode;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
    }
    
    public void addParam(BizpTaskParam param) {
        params.add(param);
        param.setBizpTask(this);
    }
    
    public void removeParam(BizpTaskParam param) {
        params.remove(param);
        param.setBizpTask(null);
    }
}
