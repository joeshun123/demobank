package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "ADVT_DOC_ITEM")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdvtDocItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOC_KEY", nullable = false)
    private AdvtDoc advtDoc;
    
    @NotBlank(message = "Cargo description is required")
    @Column(name = "CARGO_DESCRIPTION", nullable = false)
    private String cargoDescription;
    
    @NotNull(message = "Quantity is required")
    @Positive(message = "Quantity must be positive")
    @Column(name = "QTY", nullable = false)
    private Double qty;
    
    @NotNull(message = "Weight is required")
    @Positive(message = "Weight must be positive")
    @Column(name = "WEIGHT", nullable = false)
    private Double weight;
    
    @Column(name = "VOLUME")
    private Double volume;
    
    @Column(name = "MARKS")
    private String marks;
    
    // Custom constructor for convenience
    public AdvtDocItem(String cargoDescription, Double qty, Double weight, Double volume, String marks) {
        this.cargoDescription = cargoDescription;
        this.qty = qty;
        this.weight = weight;
        this.volume = volume;
        this.marks = marks;
    }
}
