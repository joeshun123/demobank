package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ADVM_DOC")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdvmDoc {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    @Column(name = "ENTITY_CODE", nullable = false)
    private String entityCode;
    
    @OneToMany(mappedBy = "advmDoc", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<AdvmItem> items = new ArrayList<>();
    
    // Custom constructor for convenience
    public AdvmDoc(String entityCode) {
        this.entityCode = entityCode;
    }
    
    public void addItem(AdvmItem item) {
        items.add(item);
        item.setAdvmDoc(this);
    }
    
    public void removeItem(AdvmItem item) {
        items.remove(item);
        item.setAdvmDoc(null);
    }
}
