package com.biztask.bolpoc.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "BIZM_TASK_MASTER")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BizmTaskMaster {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKEY")
    private Long skey;
    
    @NotBlank(message = "Entity code is required")
    @Column(name = "ENTITY_CODE", nullable = false)
    private String entityCode;
    
    @NotBlank(message = "Task code is required")
    @Column(name = "CODE", nullable = false)
    private String code;
    
    @NotBlank(message = "Implementation class is required")
    @Column(name = "IMPLEMENTATION_CLASS", nullable = false)
    private String implementationClass;
    
    @NotNull
    @Column(name = "IS_ACTIVE", nullable = false)
    private Boolean isActive = false;
    
    @Column(name = "PARAMETERS", columnDefinition = "TEXT")
    private String parameters; // JSON string for key/value parameters
    
    // Custom constructor for convenience
    public BizmTaskMaster(String entityCode, String code, String implementationClass, Boolean isActive) {
        this.entityCode = entityCode;
        this.code = code;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
    }
    
    // Custom constructor with parameters
    public BizmTaskMaster(String entityCode, String code, String implementationClass, Boolean isActive, String parameters) {
        this.entityCode = entityCode;
        this.code = code;
        this.implementationClass = implementationClass;
        this.isActive = isActive;
        this.parameters = parameters;
    }
}
