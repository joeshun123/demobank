package com.biztask.bolpoc.execution.rules;

import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Generic rule for checking if a field has the expected type
 * Uses SpEL (Spring Expression Language) to evaluate field paths
 * 
 * Required parameters:
 * - PATH: SpEL path to the field (e.g., "./qty", "./price")
 * - EXPECTED_TYPE: Expected type (e.g., "number", "string", "boolean", "integer")
 */
@Slf4j
@Component
public class FieldTypeCheckRule implements TaskRule {

    private static final String PATH_PARAM = "PATH";
    private static final String EXPECTED_TYPE_PARAM = "EXPECTED_TYPE";
    private static final String FIELD_NAME_PARAM = "FIELD_NAME";
    
    private final ExpressionParser parser = new SpelExpressionParser();

    @Override
    public boolean isApply(Map<String, Object> context) {
        // This rule is always matched, validation logic is in execute
        return true;
    }

    @Override
    public TaskExecutionResult execute(Map<String, Object> context) {
        log.info("Executing field type check rule");
        
        try {
            Object data = context.get("data");
            if (data == null) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "Data object not found in context",
                        "MISSING_DATA"
                );
            }

            // Get the PATH parameter from task parameters
            String path = getPathParameter(context);
            if (path == null || path.trim().isEmpty()) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "PATH parameter is required for field type check",
                        "MISSING_PATH_PARAM"
                );
            }

            // Get the EXPECTED_TYPE parameter from task parameters
            String expectedType = getExpectedTypeParameter(context);
            if (expectedType == null || expectedType.trim().isEmpty()) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "EXPECTED_TYPE parameter is required for field type check",
                        "MISSING_TYPE_PARAM"
                );
            }

            // Get field name for error message (optional parameter)
            String fieldName = getFieldNameParameter(context);
            if (fieldName == null || fieldName.trim().isEmpty()) {
                // Extract field name from path if not provided
                fieldName = extractFieldNameFromPath(path);
            }

            // Evaluate the field value using SpEL
            Object fieldValue = evaluateFieldValue(data, path);
            
            // Check if field is null (optional field)
            if (fieldValue == null) {
                log.info("Field '{}' is null, skipping type check", fieldName);
                return TaskExecutionResult.success(
                        getTaskCode(),
                        getTaskName(),
                        String.format("Field '%s' is null, type check skipped", fieldName)
                );
            }
            
            // Check if field has the expected type
            if (!isExpectedType(fieldValue, expectedType)) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        String.format("Field '%s' has incorrect type. Expected: %s, Actual: %s (path: %s)", 
                                fieldName, expectedType, getActualType(fieldValue), path),
                        "INVALID_FIELD_TYPE"
                );
            }

            log.info("Field type check passed for field: {} (path: {}, type: {})", fieldName, path, expectedType);
            return TaskExecutionResult.success(
                    getTaskCode(),
                    getTaskName(),
                    String.format("Field '%s' type validation passed (type: %s)", fieldName, expectedType)
            );

        } catch (Exception e) {
            log.error("Error in field type check rule", e);
            return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Error during field type validation: " + e.getMessage(),
                    "VALIDATION_ERROR"
            );
        }
    }

    private String getPathParameter(Map<String, Object> context) {
        // Try to get PATH from task parameters
        Object taskParams = context.get("taskParams");
        if (taskParams instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> params = (Map<String, Object>) taskParams;
            Object path = params.get(PATH_PARAM);
            if (path instanceof String) {
                return (String) path;
            }
        }
        return null;
    }

    private String getExpectedTypeParameter(Map<String, Object> context) {
        // Try to get EXPECTED_TYPE from task parameters
        Object taskParams = context.get("taskParams");
        if (taskParams instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> params = (Map<String, Object>) taskParams;
            Object expectedType = params.get(EXPECTED_TYPE_PARAM);
            if (expectedType instanceof String) {
                return (String) expectedType;
            }
        }
        return null;
    }

    private String getFieldNameParameter(Map<String, Object> context) {
        // Try to get FIELD_NAME from task parameters
        Object taskParams = context.get("taskParams");
        if (taskParams instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> params = (Map<String, Object>) taskParams;
            Object fieldName = params.get(FIELD_NAME_PARAM);
            if (fieldName instanceof String) {
                return (String) fieldName;
            }
        }
        return null;
    }

    private String extractFieldNameFromPath(String path) {
        // Extract field name from SpEL path
        // e.g., "./qty" -> "qty"
        if (path.startsWith("./")) {
            return path.substring(2);
        }
        return path;
    }

    private Object evaluateFieldValue(Object data, String path) {
        try {
            Expression expression = parser.parseExpression(path);
            StandardEvaluationContext context = new StandardEvaluationContext(data);
            return expression.getValue(context);
        } catch (Exception e) {
            log.warn("Failed to evaluate SpEL path '{}' on data object: {}", path, e.getMessage());
            return null;
        }
    }

    private boolean isExpectedType(Object fieldValue, String expectedType) {
        String actualType = getActualType(fieldValue);
        
        switch (expectedType.toLowerCase()) {
            case "number":
                return isNumber(fieldValue);
            case "integer":
                return isInteger(fieldValue);
            case "string":
                return fieldValue instanceof String;
            case "boolean":
                return fieldValue instanceof Boolean;
            case "decimal":
                return isDecimal(fieldValue);
            case "long":
                return fieldValue instanceof Long;
            case "double":
                return fieldValue instanceof Double;
            case "float":
                return fieldValue instanceof Float;
            default:
                log.warn("Unknown expected type: {}", expectedType);
                return false;
        }
    }

    private String getActualType(Object fieldValue) {
        if (fieldValue == null) {
            return "null";
        }
        
        Class<?> clazz = fieldValue.getClass();
        
        // Handle primitive types
        if (clazz == Integer.class || clazz == int.class) {
            return "integer";
        } else if (clazz == Long.class || clazz == long.class) {
            return "long";
        } else if (clazz == Double.class || clazz == double.class) {
            return "double";
        } else if (clazz == Float.class || clazz == float.class) {
            return "float";
        } else if (clazz == Boolean.class || clazz == boolean.class) {
            return "boolean";
        } else if (clazz == String.class) {
            return "string";
        } else if (clazz == BigDecimal.class) {
            return "decimal";
        } else {
            return clazz.getSimpleName().toLowerCase();
        }
    }

    private boolean isNumber(Object fieldValue) {
        return fieldValue instanceof Number || 
               fieldValue instanceof BigDecimal ||
               (fieldValue instanceof String && isNumericString((String) fieldValue));
    }

    private boolean isInteger(Object fieldValue) {
        return fieldValue instanceof Integer || 
               fieldValue instanceof Long ||
               (fieldValue instanceof String && isIntegerString((String) fieldValue));
    }

    private boolean isDecimal(Object fieldValue) {
        return fieldValue instanceof BigDecimal ||
               fieldValue instanceof Double ||
               fieldValue instanceof Float ||
               (fieldValue instanceof String && isDecimalString((String) fieldValue));
    }

    private boolean isNumericString(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isIntegerString(String value) {
        try {
            Long.parseLong(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isDecimalString(String value) {
        try {
            Double.parseDouble(value);
            return value.contains("."); // Must contain decimal point
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public String getTaskCode() {
        return "FIELD_TYPE_CHECK";
    }

    @Override
    public String getTaskName() {
        return "Field Type Check Rule";
    }

    @Override
    public int getPriority() {
        return 2; // Medium priority for type checks
    }
}
