package com.biztask.bolpoc.execution.rules;

import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Sample BOL validation rule
 */
@Slf4j
@Component
public class BolValidationRule implements TaskRule {
    
    @Override
    public boolean isApply(Map<String, Object> context) {
        // This rule should always execute for BOL operations
        String operation = (String) context.get("operation");
        String entityCode = (String) context.get("entityCode");
        
        return "BOL".equals(entityCode) && 
               (operation != null && (operation.contains("ADD") || operation.contains("EDIT") || operation.contains("DELETE")));
    }
    
    @Override
    public TaskExecutionResult execute(Map<String, Object> context) {
        log.info("Executing BOL validation rule");
        
        try {
            // Debug: Log all context keys
            log.info("Context keys: {}", context.keySet());
            log.info("Context data value: {}", context.get("data"));
            
            // Get BOL data from context
            Object bolData = context.get("data");
            if (bolData == null) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "BOL data not found in context. Available keys: " + context.keySet(),
                        "MISSING_BOL_DATA"
                );
            }
            
            // Perform validation logic here
            // For now, just a simple validation
            String operation = (String) context.get("operation");
            log.info("Validating BOL for operation: {}", operation);
            
            // Simulate validation logic
            boolean isValid = performValidation(bolData, operation);
            
            if (isValid) {
                return TaskExecutionResult.success(
                        getTaskCode(),
                        getTaskName(),
                        "BOL validation passed successfully"
                );
            } else {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "BOL validation failed",
                        "VALIDATION_FAILED"
                );
            }
            
        } catch (Exception e) {
            log.error("Error in BOL validation rule", e);
            return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Error during BOL validation: " + e.getMessage(),
                    "VALIDATION_ERROR"
            );
        }
    }
    
    private boolean performValidation(Object bolData, String operation) {
        // Add your validation logic here
        // For now, return true for demonstration
        log.debug("Performing validation for operation: {}", operation);
        return true;
    }
    
    @Override
    public String getTaskCode() {
        return "BOL_VALIDATION";
    }
    
    @Override
    public String getTaskName() {
        return "BOL Validation Rule";
    }
    
    @Override
    public int getPriority() {
        return 1; // High priority - should run early
    }
}
