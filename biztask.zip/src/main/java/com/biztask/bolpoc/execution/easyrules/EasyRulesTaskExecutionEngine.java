package com.biztask.bolpoc.execution.easyrules;

import com.biztask.bolpoc.execution.TaskExecutionEngine;
import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import com.biztask.bolpoc.dto.BizpTaskGroupDetailDto;
import com.biztask.bolpoc.dto.BizpTaskParamDto;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.DefaultRulesEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Easy Rules implementation of the task execution engine
 */
@Slf4j
@Component
public class EasyRulesTaskExecutionEngine implements TaskExecutionEngine {
    
    @Autowired
    private TaskRuleRegistry taskRuleRegistry;
    
    private final RulesEngine rulesEngine;
    
    public EasyRulesTaskExecutionEngine() {
        this.rulesEngine = new DefaultRulesEngine();
    }
    
    @Override
    public List<TaskExecutionResult> executeTasks(List<BizpTaskGroupDetailDto> tasks, String operation, String entityCode, Map<String, Object> context) {
        log.info("Executing {} tasks for operation: {}, entityCode: {}", tasks.size(), operation, entityCode);
        
        List<TaskExecutionResult> results = new ArrayList<>();
        
        try {
            // Execute each task
            for (BizpTaskGroupDetailDto taskDetail : tasks) {
                try {
                    TaskExecutionResult result = executeTask(taskDetail, context);
                    results.add(result);
                    
                    // If task execution failed and it's mandatory, stop execution
                    if (!result.isSuccess() && taskDetail.getIsMandatory()) {
                        log.error("Mandatory task {} failed, stopping execution", taskDetail.getTaskCode());
                        break;
                    }
                } catch (Exception e) {
                    log.error("Error executing task: {}", taskDetail.getTaskCode(), e);
                    TaskExecutionResult errorResult = TaskExecutionResult.error(
                            taskDetail.getTaskCode(),
                            taskDetail.getBizpTask().getImplementationClass(),
                            "Error executing task: " + e.getMessage(),
                            "EXECUTION_ERROR"
                    );
                    results.add(errorResult);
                }
            }
            
        } catch (Exception e) {
            log.error("Error executing tasks for operation: {}, entityCode: {}", operation, entityCode, e);
            TaskExecutionResult errorResult = TaskExecutionResult.error(
                    "TASK_GROUP_ERROR",
                    "Task Group Execution",
                    "Error executing task group: " + e.getMessage(),
                    "TASK_GROUP_ERROR"
            );
            results.add(errorResult);
        }
        
        log.info("Task execution completed. Results: {}", results.size());
        return results;
    }
    
    private TaskExecutionResult executeTask(BizpTaskGroupDetailDto taskDetail, Map<String, Object> context) {
        String taskCode = taskDetail.getTaskCode();
        String implementationClass = taskDetail.getBizpTask().getImplementationClass();
        
        log.debug("Executing task: {} with implementation: {}", taskCode, implementationClass);
        
        try {
            // Get the task rule implementation
            TaskRule taskRule = taskRuleRegistry.getTaskRule(implementationClass);
            if (taskRule == null) {
                return TaskExecutionResult.error(
                        taskCode,
                        implementationClass,
                        "Task rule implementation not found: " + implementationClass,
                        "RULE_NOT_FOUND"
                );
            }
            
            // Add task parameters to context
            Map<String, Object> taskContext = new HashMap<>(context);
            if (taskDetail.getBizpTask().getParams() != null) {
                Map<String, Object> taskParams = new HashMap<>();
                for (BizpTaskParamDto param : taskDetail.getBizpTask().getParams()) {
                    taskParams.put(param.getKey(), param.getValue());
                }
                taskContext.put("taskParams", taskParams);
            }
            
            // Check if rule should be executed
            if (!taskRule.isApply(taskContext)) {
                log.debug("Task {} not matched, skipping execution", taskCode);
                return TaskExecutionResult.success(
                        taskCode,
                        taskRule.getTaskName(),
                        "Task not matched, skipped"
                );
            }
            
            // Execute the rule
            TaskExecutionResult result = taskRule.execute(taskContext);
            log.debug("Task {} execution result: {}", taskCode, result);
            
            return result;
            
        } catch (Exception e) {
            log.error("Error executing task: {}", taskCode, e);
            return TaskExecutionResult.error(
                    taskCode,
                    implementationClass,
                    "Error executing task: " + e.getMessage(),
                    "EXECUTION_ERROR"
            );
        }
    }
    
    @Override
    public String getEngineName() {
        return "Easy Rules Engine";
    }
    
    @Override
    public boolean isAvailable() {
        try {
            // Check if Easy Rules is available
            Class.forName("org.jeasy.rules.api.RulesEngine");
            return true;
        } catch (ClassNotFoundException e) {
            log.warn("Easy Rules not available: {}", e.getMessage());
            return false;
        }
    }
}
