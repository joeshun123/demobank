package com.biztask.bolpoc.execution.drools;

import com.biztask.bolpoc.execution.TaskExecutionEngine;
import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.dto.BizpTaskGroupDetailDto;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Drools implementation of the task execution engine
 */
@Slf4j
@Component
public class DroolsTaskExecutionEngine implements TaskExecutionEngine {
    
    private KieContainer kieContainer;
    
    public DroolsTaskExecutionEngine() {
        initializeDrools();
    }
    
    private void initializeDrools() {
        try {
            KieServices kieServices = KieServices.Factory.get();
            KieFileSystem kfs = kieServices.newKieFileSystem();
            
            // Create a simple rule for BOL operations
            String rule = createBolRule();
            kfs.write("src/main/resources/rules/bol-rules.drl", rule);
            
            KieBuilder kieBuilder = kieServices.newKieBuilder(kfs);
            kieBuilder.buildAll();
            
            if (kieBuilder.getResults().hasMessages(Message.Level.ERROR)) {
                log.error("Drools build errors: {}", kieBuilder.getResults().getMessages());
                return;
            }
            
            this.kieContainer = kieServices.newKieContainer(kieBuilder.getKieModule().getReleaseId());
            log.info("Drools engine initialized successfully");
            
        } catch (Exception e) {
            log.error("Error initializing Drools engine", e);
        }
    }
    
    private String createBolRule() {
        return """
            package com.biztask.bolpoc.rules
            import com.biztask.bolpoc.execution.TaskExecutionResult
            import java.util.Map
            
            rule "BOL Validation Rule"
            when
                $context : Map()
                $operation : String() from $context.get("operation")
                $entityCode : String() from $context.get("entityCode")
                $bolData : Object() from $context.get("bolData")
            then
                System.out.println("Executing BOL validation rule for operation: " + $operation);
                // Add your validation logic here
            end
            
            rule "BOL Audit Rule"
            when
                $context : Map()
                $operation : String() from $context.get("operation")
                $entityCode : String() from $context.get("entityCode")
                $bolData : Object() from $context.get("bolData")
            then
                System.out.println("Executing BOL audit rule for operation: " + $operation);
                // Add your audit logic here
            end
            """;
    }
    
    @Override
    public List<TaskExecutionResult> executeTasks(List<BizpTaskGroupDetailDto> tasks, String operation, String entityCode, Map<String, Object> context) {
        log.info("Executing {} Drools tasks for operation: {}, entityCode: {}", tasks.size(), operation, entityCode);
        
        List<TaskExecutionResult> results = new ArrayList<>();
        
        if (kieContainer == null) {
            log.error("Drools container not initialized");
            results.add(TaskExecutionResult.error(
                    "DROOLS_ERROR",
                    "Drools Engine",
                    "Drools container not initialized",
                    "CONTAINER_NOT_INITIALIZED"
            ));
            return results;
        }
        
        try {
            // Execute tasks using Drools
            KieSession kieSession = kieContainer.newKieSession();
            
            try {
                // Insert facts into the session
                kieSession.insert(context);
                kieSession.insert(operation);
                kieSession.insert(entityCode);
                kieSession.insert(context.get("data"));
                
                // Fire all rules
                int rulesFired = kieSession.fireAllRules();
                log.info("Drools fired {} rules", rulesFired);
                
                // Create results based on the tasks provided
                for (BizpTaskGroupDetailDto taskDetail : tasks) {
                    TaskExecutionResult result = TaskExecutionResult.success(
                            taskDetail.getTaskCode(),
                            taskDetail.getBizpTask().getImplementationClass(),
                            "Drools rule executed successfully"
                    );
                    results.add(result);
                }
                
            } finally {
                kieSession.dispose();
            }
            
        } catch (Exception e) {
            log.error("Error executing Drools tasks", e);
            results.add(TaskExecutionResult.error(
                    "DROOLS_EXECUTION_ERROR",
                    "Drools Engine",
                    "Error executing Drools tasks: " + e.getMessage(),
                    "EXECUTION_ERROR"
            ));
        }
        
        log.info("Drools task execution completed. Results: {}", results.size());
        return results;
    }
    
    @Override
    public String getEngineName() {
        return "Drools Rule Engine";
    }
    
    @Override
    public boolean isAvailable() {
        try {
            // Check if Drools is available
            Class.forName("org.kie.api.KieServices");
            return kieContainer != null;
        } catch (ClassNotFoundException e) {
            log.warn("Drools not available: {}", e.getMessage());
            return false;
        }
    }
}
