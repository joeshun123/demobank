package com.biztask.bolpoc.execution;

import com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine;
import com.biztask.bolpoc.execution.drools.DroolsTaskExecutionEngine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.List;

/**
 * Configuration for task execution engines
 */
@Slf4j
@Configuration
public class TaskExecutionConfig {
    
    @Autowired
    private List<TaskExecutionEngine> executionEngines;
    
    @Bean
    @Primary
    public TaskExecutionEngine primaryExecutionEngine() {
        // Try Easy Rules first
        for (TaskExecutionEngine engine : executionEngines) {
            if (engine instanceof EasyRulesTaskExecutionEngine && engine.isAvailable()) {
                log.info("Setting Easy Rules as primary execution engine");
                return engine;
            }
        }
        
        // Fallback to Drools
        for (TaskExecutionEngine engine : executionEngines) {
            if (engine instanceof DroolsTaskExecutionEngine && engine.isAvailable()) {
                log.info("Setting Drools as primary execution engine");
                return engine;
            }
        }
        
        log.warn("No execution engines available, using first available engine");
        return executionEngines.isEmpty() ? null : executionEngines.get(0);
    }
}
