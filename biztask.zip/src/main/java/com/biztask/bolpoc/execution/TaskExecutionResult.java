package com.biztask.bolpoc.execution;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Represents the result of executing a single task/rule
 */
public class TaskExecutionResult {
    private String taskCode;
    private String taskName;
    private boolean success;
    private String message;
    private String errorCode;
    private LocalDateTime executionTime;
    private Map<String, Object> context;
    private Object result;

    public TaskExecutionResult() {
        this.executionTime = LocalDateTime.now();
    }

    public TaskExecutionResult(String taskCode, String taskName, boolean success, String message) {
        this();
        this.taskCode = taskCode;
        this.taskName = taskName;
        this.success = success;
        this.message = message;
    }

    // Getters and Setters
    public String getTaskCode() {
        return taskCode;
    }

    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public LocalDateTime getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(LocalDateTime executionTime) {
        this.executionTime = executionTime;
    }

    public Map<String, Object> getContext() {
        return context;
    }

    public void setContext(Map<String, Object> context) {
        this.context = context;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    // Static factory methods for common results
    public static TaskExecutionResult success(String taskCode, String taskName, String message) {
        return new TaskExecutionResult(taskCode, taskName, true, message);
    }

    public static TaskExecutionResult success(String taskCode, String taskName, String message, Object result) {
        TaskExecutionResult resultObj = new TaskExecutionResult(taskCode, taskName, true, message);
        resultObj.setResult(result);
        return resultObj;
    }

    public static TaskExecutionResult error(String taskCode, String taskName, String message) {
        return new TaskExecutionResult(taskCode, taskName, false, message);
    }

    public static TaskExecutionResult error(String taskCode, String taskName, String message, String errorCode) {
        TaskExecutionResult result = new TaskExecutionResult(taskCode, taskName, false, message);
        result.setErrorCode(errorCode);
        return result;
    }

    @Override
    public String toString() {
        return String.format("TaskExecutionResult{taskCode='%s', taskName='%s', success=%s, message='%s', executionTime=%s}",
                taskCode, taskName, success, message, executionTime);
    }
}
