package com.biztask.bolpoc.execution;

import com.biztask.bolpoc.dto.BizpTaskGroupDetailDto;
import java.util.List;
import java.util.Map;

/**
 * Interface for task execution engines
 */
public interface TaskExecutionEngine {
    
    /**
     * Executes tasks for a given operation
     * @param tasks The list of tasks to execute
     * @param operation The operation type (ADD_OS, EDIT_OS, DELETE_OS)
     * @param entityCode The entity code (e.g., "BOL")
     * @param context The execution context
     * @return List of task execution results
     */
    List<TaskExecutionResult> executeTasks(List<BizpTaskGroupDetailDto> tasks, String operation, String entityCode, Map<String, Object> context);
    
    /**
     * Gets the engine name
     * @return The engine name
     */
    String getEngineName();
    
    /**
     * Checks if the engine is available/configured
     * @return true if available, false otherwise
     */
    boolean isAvailable();
}
