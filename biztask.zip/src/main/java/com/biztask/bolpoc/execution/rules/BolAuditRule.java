package com.biztask.bolpoc.execution.rules;

import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Sample BOL audit rule
 */
@Slf4j
@Component
public class BolAuditRule implements TaskRule {
    
    @Override
    public boolean isApply(Map<String, Object> context) {
        // This rule should execute for all BOL operations
        String entityCode = (String) context.get("entityCode");
        return "BOL".equals(entityCode);
    }
    
    @Override
    public TaskExecutionResult execute(Map<String, Object> context) {
        log.info("Executing BOL audit rule");
        
        try {
            String operation = (String) context.get("operation");
            Object bolData = context.get("data");
            String userId = (String) context.get("userId");
            
            log.info("Auditing BOL operation: {} by user: {}", operation, userId);
            
            // Perform audit logic here
            boolean auditSuccess = performAudit(operation, bolData, userId);
            
            if (auditSuccess) {
                return TaskExecutionResult.success(
                        getTaskCode(),
                        getTaskName(),
                        "BOL audit completed successfully"
                );
            } else {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "BOL audit failed",
                        "AUDIT_FAILED"
                );
            }
            
        } catch (Exception e) {
            log.error("Error in BOL audit rule", e);
            return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Error during BOL audit: " + e.getMessage(),
                    "AUDIT_ERROR"
            );
        }
    }
    
    private boolean performAudit(String operation, Object bolData, String userId) {
        // Add your audit logic here
        log.debug("Performing audit for operation: {}, user: {}", operation, userId);
        
        // For now, just log the audit event
        log.info("AUDIT: BOL {} operation performed by user {} at {}", 
                operation, userId, LocalDateTime.now());
        
        return true;
    }
    
    @Override
    public String getTaskCode() {
        return "BOL_AUDIT";
    }
    
    @Override
    public String getTaskName() {
        return "BOL Audit Rule";
    }
    
    @Override
    public int getPriority() {
        return 10; // Lower priority - should run after validation
    }
}
