package com.biztask.bolpoc.execution.rules;

import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Generic rule for checking if a mandatory field exists and is not null/empty
 * Uses SpEL (Spring Expression Language) to evaluate field paths
 * 
 * Required parameters:
 * - PATH: SpEL path to the field (e.g., "./docNbr", "./consigneeName")
 */
@Slf4j
@Component
public class MandatoryFieldCheckRule implements TaskRule {

    private static final String PATH_PARAM = "PATH";
    private static final String FIELD_NAME_PARAM = "FIELD_NAME";
    
    private final ExpressionParser parser = new SpelExpressionParser();

    @Override
    public boolean isApply(Map<String, Object> context) {
        // This rule is always matched, validation logic is in execute
        return true;
    }

    @Override
    public TaskExecutionResult execute(Map<String, Object> context) {
        log.info("Executing mandatory field check rule");
        
        try {
            Object data = context.get("data");
            if (data == null) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "Data object not found in context",
                        "MISSING_DATA"
                );
            }

            // Get the PATH parameter from task parameters
            String path = getPathParameter(context);
            if (path == null || path.trim().isEmpty()) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        "PATH parameter is required for mandatory field check",
                        "MISSING_PATH_PARAM"
                );
            }

            // Get field name for error message (optional parameter)
            String fieldName = getFieldNameParameter(context);
            if (fieldName == null || fieldName.trim().isEmpty()) {
                // Extract field name from path if not provided
                fieldName = extractFieldNameFromPath(path);
            }

            // Evaluate the field value using SpEL
            Object fieldValue = evaluateFieldValue(data, path);
            
            // Check if field exists and is not null/empty
            if (isFieldMissing(fieldValue)) {
                return TaskExecutionResult.error(
                        getTaskCode(),
                        getTaskName(),
                        String.format("Mandatory field '%s' is missing or empty (path: %s)", fieldName, path),
                        "MANDATORY_FIELD_MISSING"
                );
            }

            log.info("Mandatory field check passed for field: {} (path: {})", fieldName, path);
            return TaskExecutionResult.success(
                    getTaskCode(),
                    getTaskName(),
                    String.format("Mandatory field '%s' validation passed", fieldName)
            );

        } catch (Exception e) {
            log.error("Error in mandatory field check rule", e);
            return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Error during mandatory field validation: " + e.getMessage(),
                    "VALIDATION_ERROR"
            );
        }
    }

    private String getPathParameter(Map<String, Object> context) {
        // Try to get PATH from task parameters
        Object taskParams = context.get("taskParams");
        if (taskParams instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> params = (Map<String, Object>) taskParams;
            Object path = params.get(PATH_PARAM);
            if (path instanceof String) {
                return (String) path;
            }
        }
        return null;
    }

    private String getFieldNameParameter(Map<String, Object> context) {
        // Try to get FIELD_NAME from task parameters
        Object taskParams = context.get("taskParams");
        if (taskParams instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> params = (Map<String, Object>) taskParams;
            Object fieldName = params.get(FIELD_NAME_PARAM);
            if (fieldName instanceof String) {
                return (String) fieldName;
            }
        }
        return null;
    }

    private String extractFieldNameFromPath(String path) {
        // Extract field name from SpEL path
        // e.g., "./docNbr" -> "docNbr"
        if (path.startsWith("./")) {
            return path.substring(2);
        }
        return path;
    }

    private Object evaluateFieldValue(Object data, String path) {
        try {
            Expression expression = parser.parseExpression(path);
            StandardEvaluationContext context = new StandardEvaluationContext(data);
            return expression.getValue(context);
        } catch (Exception e) {
            log.warn("Failed to evaluate SpEL path '{}' on data object: {}", path, e.getMessage());
            return null;
        }
    }

    private boolean isFieldMissing(Object fieldValue) {
        if (fieldValue == null) {
            return true;
        }
        
        // Check for empty string
        if (fieldValue instanceof String) {
            return ((String) fieldValue).trim().isEmpty();
        }
        
        // Check for empty collections
        if (fieldValue instanceof java.util.Collection) {
            return ((java.util.Collection<?>) fieldValue).isEmpty();
        }
        
        // Check for empty arrays
        if (fieldValue.getClass().isArray()) {
            return java.lang.reflect.Array.getLength(fieldValue) == 0;
        }
        
        return false;
    }

    @Override
    public String getTaskCode() {
        return "MANDATORY_FIELD_CHECK";
    }

    @Override
    public String getTaskName() {
        return "Mandatory Field Check Rule";
    }

    @Override
    public int getPriority() {
        return 1; // High priority for mandatory field checks
    }
}
