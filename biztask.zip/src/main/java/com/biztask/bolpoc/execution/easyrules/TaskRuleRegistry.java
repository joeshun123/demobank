package com.biztask.bolpoc.execution.easyrules;

import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * Registry for task rules that can be dynamically loaded and executed
 */
@Slf4j
@Component
public class TaskRuleRegistry {
    
    @Autowired
    private ApplicationContext applicationContext;
    
    private final Map<String, TaskRule> taskRules = new HashMap<>();
    
    @PostConstruct
    public void initializeTaskRules() {
        log.info("Initializing task rule registry...");
        
        // Get all TaskRule beans from Spring context
        Map<String, TaskRule> ruleBeans = applicationContext.getBeansOfType(TaskRule.class);
        
        for (Map.Entry<String, TaskRule> entry : ruleBeans.entrySet()) {
            TaskRule rule = entry.getValue();
            String taskCode = rule.getTaskCode();
            
            if (taskCode != null && !taskCode.trim().isEmpty()) {
                taskRules.put(taskCode, rule);
                log.info("Registered task rule: {} -> {}", taskCode, rule.getClass().getSimpleName());
            } else {
                log.warn("Task rule {} has no task code, skipping registration", entry.getKey());
            }
        }
        
        log.info("Task rule registry initialized with {} rules", taskRules.size());
    }
    
    /**
     * Gets a task rule by its implementation class name
     * @param implementationClass The implementation class name
     * @return The task rule or null if not found
     */
    public TaskRule getTaskRule(String implementationClass) {
        // First try to find by implementation class name
        for (TaskRule rule : taskRules.values()) {
            if (rule.getClass().getName().equals(implementationClass)) {
                return rule;
            }
        }
        
        // If not found, try to find by simple class name
        for (TaskRule rule : taskRules.values()) {
            if (rule.getClass().getSimpleName().equals(implementationClass)) {
                return rule;
            }
        }
        
        log.warn("Task rule not found for implementation class: {}", implementationClass);
        return null;
    }
    
    /**
     * Gets a task rule by its task code
     * @param taskCode The task code
     * @return The task rule or null if not found
     */
    public TaskRule getTaskRuleByCode(String taskCode) {
        return taskRules.get(taskCode);
    }
    
    /**
     * Registers a task rule
     * @param taskCode The task code
     * @param taskRule The task rule
     */
    public void registerTaskRule(String taskCode, TaskRule taskRule) {
        taskRules.put(taskCode, taskRule);
        log.info("Registered task rule: {} -> {}", taskCode, taskRule.getClass().getSimpleName());
    }
    
    /**
     * Gets all registered task rules
     * @return Map of task codes to task rules
     */
    public Map<String, TaskRule> getAllTaskRules() {
        return new HashMap<>(taskRules);
    }
}
