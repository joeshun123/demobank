package com.biztask.bolpoc.execution;

import com.biztask.bolpoc.dto.BizpTaskGroupDetailDto;
import com.biztask.bolpoc.dto.BizpTaskGroupDto;
import com.biztask.bolpoc.service.BizpTaskGroupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service for coordinating task execution
 */
@Slf4j
@Service
public class TaskExecutionService {
    
    @Autowired
    private List<TaskExecutionEngine> executionEngines;
    
    @Autowired
    private BizpTaskGroupService bizpTaskGroupService;
    
    /**
     * Executes tasks for any entity operations
     * @param taskGroupCode The task group code (e.g., "BOL_TASKS")
     * @param entityCode The entity code (e.g., "BOL")
     * @param operation The operation type (ADD_OS, EDIT_OS, DELETE_OS)
     * @param data The entity data
     * @param userId The user performing the operation
     * @return List of task execution results
     */
    public List<TaskExecutionResult> executeTasks(String taskGroupCode, String entityCode, String operation, Object data, String userId) {
        log.info("Executing tasks for taskGroup: {}, entity: {}, operation: {}", taskGroupCode, entityCode, operation);
        
        // Retrieve tasks to execute
        List<BizpTaskGroupDetailDto> tasks = bizpTaskGroupService.getTasksByCodeEntityAndTiming(taskGroupCode, entityCode, operation, true);
        log.info("Found {} tasks to execute for operation: {}", tasks.size(), operation);
        
        if (tasks.isEmpty()) {
            log.warn("No tasks found for taskGroup: {}, entity: {}, operation: {}", taskGroupCode, entityCode, operation);
            return List.of();
        }
        
        // Create execution context
        Map<String, Object> context = new HashMap<>();
        context.put("operation", operation);
        context.put("entityCode", entityCode);
        context.put("taskGroupCode", taskGroupCode);
        context.put("data", data);
        context.put("userId", userId);
        context.put("timestamp", System.currentTimeMillis());
        
        // Get the task group to determine which execution engine to use
        BizpTaskGroupDto taskGroup = bizpTaskGroupService.getTaskGroupByCodeAndEntity(taskGroupCode, entityCode);
        if (taskGroup == null) {
            log.error("Task group not found: {} for entity: {}", taskGroupCode, entityCode);
            return List.of(TaskExecutionResult.error(
                    "TASK_GROUP_NOT_FOUND",
                    "Task Group Not Found",
                    "Task group not found: " + taskGroupCode + " for entity: " + entityCode,
                    "TASK_GROUP_NOT_FOUND"
            ));
        }
        
        // Find the execution engine specified in the task group
        TaskExecutionEngine selectedEngine = findExecutionEngine(taskGroup.getTaskExecEngine());
        if (selectedEngine == null) {
            log.error("Execution engine not found: {}", taskGroup.getTaskExecEngine());
            return List.of(TaskExecutionResult.error(
                    "ENGINE_NOT_FOUND",
                    "Execution Engine Not Found",
                    "Execution engine not found: " + taskGroup.getTaskExecEngine(),
                    "ENGINE_NOT_FOUND"
            ));
        }
        
        if (!selectedEngine.isAvailable()) {
            log.error("Execution engine not available: {}", taskGroup.getTaskExecEngine());
            return List.of(TaskExecutionResult.error(
                    "ENGINE_NOT_AVAILABLE",
                    "Execution Engine Not Available",
                    "Execution engine not available: " + taskGroup.getTaskExecEngine(),
                    "ENGINE_NOT_AVAILABLE"
            ));
        }
        
        log.info("Using execution engine: {} for task group: {}", selectedEngine.getEngineName(), taskGroupCode);
        return selectedEngine.executeTasks(tasks, operation, entityCode, context);
    }
    
    /**
     * Finds an execution engine by its class name
     * @param engineClassName The fully qualified class name of the engine
     * @return The execution engine or null if not found
     */
    private TaskExecutionEngine findExecutionEngine(String engineClassName) {
        if (engineClassName == null || engineClassName.trim().isEmpty()) {
            log.warn("Engine class name is null or empty, using default Easy Rules engine");
            engineClassName = "com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine";
        }
        
        for (TaskExecutionEngine engine : executionEngines) {
            if (engineClassName.equals(engine.getClass().getName())) {
                return engine;
            }
        }
        
        log.warn("Execution engine not found: {}, available engines: {}", 
                engineClassName, 
                executionEngines.stream().map(e -> e.getClass().getName()).toList());
        return null;
    }
    
    /**
     * Gets the status of all execution engines
     * @return Map of engine names to their availability status
     */
    public Map<String, Boolean> getEngineStatus() {
        Map<String, Boolean> status = new HashMap<>();
        
        for (TaskExecutionEngine engine : executionEngines) {
            status.put(engine.getEngineName(), engine.isAvailable());
        }
        
        return status;
    }
}
