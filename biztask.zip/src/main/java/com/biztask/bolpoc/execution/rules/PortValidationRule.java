package com.biztask.bolpoc.execution.rules;

import com.biztask.bolpoc.dto.AdvtDocDto;
import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class PortValidationRule implements TaskRule {
    
    private static final List<String> VALID_PORTS = Arrays.asList(
        "USLAX", "SGSIN", "CNHKG", "DEHAM", "JPTYO", 
        "NLRTM", "USNYC", "AEJEA", "CNBND"
    );
    
    @Override
    public boolean isApply(Map<String, Object> context) {
        // This rule applies to all BOL operations
        String operation = (String) context.get("operation");
        return operation != null && (operation.equals("ADD_OS") || operation.equals("EDIT_OS"));
    }
    
    @Override
    public TaskExecutionResult execute(Map<String, Object> context) {
        log.info("Executing port validation rule");
        try {
            Object data = context.get("data");
            if (data == null) {
                return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "BOL data not found in context",
                    "MISSING_BOL_DATA"
                );
            }
            
            if (!(data instanceof AdvtDocDto)) {
                return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Invalid data type. Expected AdvtDocDto, got: " + data.getClass().getSimpleName(),
                    "INVALID_DATA_TYPE"
                );
            }
            
            AdvtDocDto bolData = (AdvtDocDto) data;
            String portOfDestination = bolData.getPortOfDestination();
            
            log.info("Validating port of destination: {}", portOfDestination);
            
            if (portOfDestination == null || portOfDestination.trim().isEmpty()) {
                return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Port of destination is required",
                    "MISSING_PORT"
                );
            }
            
            if (!VALID_PORTS.contains(portOfDestination)) {
                return TaskExecutionResult.error(
                    getTaskCode(),
                    getTaskName(),
                    "Invalid port of destination: " + portOfDestination + 
                    ". Must be one of: " + String.join(", ", VALID_PORTS),
                    "INVALID_PORT"
                );
            }
            
            log.info("Port validation passed for: {}", portOfDestination);
            return TaskExecutionResult.success(
                getTaskCode(),
                getTaskName(),
                "Port validation passed for: " + portOfDestination
            );
            
        } catch (Exception e) {
            log.error("Error in port validation rule", e);
            return TaskExecutionResult.error(
                getTaskCode(),
                getTaskName(),
                "Error during port validation: " + e.getMessage(),
                "VALIDATION_ERROR"
            );
        }
    }
    
    @Override
    public String getTaskCode() {
        return "PORT_VALIDATION";
    }
    
    @Override
    public String getTaskName() {
        return "Port Validation Rule";
    }
    
    @Override
    public int getPriority() {
        return 1; // High priority - should run early
    }
}
