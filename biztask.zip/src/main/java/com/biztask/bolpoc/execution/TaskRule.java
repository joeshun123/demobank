package com.biztask.bolpoc.execution;

import java.util.Map;

/**
 * Interface that all task/rule implementations must implement
 */
public interface TaskRule {
    
    /**
     * Determines if this rule should be executed based on the given context
     * @param context The execution context containing data and parameters
     * @return true if the rule should be executed, false otherwise
     */
    boolean isApply(Map<String, Object> context);
    
    /**
     * Executes the rule and returns the execution result
     * @param context The execution context containing data and parameters
     * @return TaskExecutionResult containing the execution outcome
     */
    TaskExecutionResult execute(Map<String, Object> context);
    
    /**
     * Gets the task code for this rule
     * @return The task code
     */
    String getTaskCode();
    
    /**
     * Gets the task name for this rule
     * @return The task name
     */
    String getTaskName();
    
    /**
     * Gets the priority of this rule (lower numbers execute first)
     * @return The priority value
     */
    default int getPriority() {
        return 0;
    }
}
