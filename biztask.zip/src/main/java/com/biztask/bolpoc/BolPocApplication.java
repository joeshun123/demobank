package com.biztask.bolpoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BolPocApplication {

    public static void main(String[] args) {
        SpringApplication.run(BolPocApplication.class, args);
    }

}
