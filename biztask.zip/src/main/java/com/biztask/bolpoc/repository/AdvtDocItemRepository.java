package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.AdvtDocItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdvtDocItemRepository extends JpaRepository<AdvtDocItem, Long> {
    
    List<AdvtDocItem> findByAdvtDocSkey(Long docSkey);
    
    void deleteByAdvtDocSkey(Long docSkey);
}
