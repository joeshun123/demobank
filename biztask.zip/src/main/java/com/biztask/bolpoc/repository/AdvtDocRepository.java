package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.AdvtDoc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdvtDocRepository extends JpaRepository<AdvtDoc, Long> {
    
    List<AdvtDoc> findByDocType(String docType);
    
    Optional<AdvtDoc> findByDocNbr(String docNbr);
    
    @Query("SELECT d FROM AdvtDoc d LEFT JOIN FETCH d.items WHERE d.skey = :id")
    Optional<AdvtDoc> findByIdWithItems(@Param("id") Long id);
    
    @Query("SELECT d FROM AdvtDoc d LEFT JOIN FETCH d.items")
    List<AdvtDoc> findAllWithItems();
}
