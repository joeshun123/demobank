package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.AdvmDoc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdvmDocRepository extends JpaRepository<AdvmDoc, Long> {
    
    @Query("SELECT d FROM AdvmDoc d LEFT JOIN FETCH d.items")
    List<AdvmDoc> findAllWithItems();
    
    Optional<AdvmDoc> findByEntityCode(String entityCode);
}
