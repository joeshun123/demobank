package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.AdvmItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdvmItemRepository extends JpaRepository<AdvmItem, Long> {
    
    List<AdvmItem> findByAdvmDocSkey(Long docSkey);
    
    @Query("SELECT i FROM AdvmItem i LEFT JOIN FETCH i.steps WHERE i.advmDoc.skey = :docSkey")
    List<AdvmItem> findByAdvmDocSkeyWithSteps(@Param("docSkey") Long docSkey);
}
