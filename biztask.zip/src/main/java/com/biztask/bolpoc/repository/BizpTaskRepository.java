package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.BizpTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BizpTaskRepository extends JpaRepository<BizpTask, Long> {
    
    @Query("SELECT t FROM BizpTask t LEFT JOIN FETCH t.params WHERE t.skey = :id")
    Optional<BizpTask> findByIdWithParams(@Param("id") Long id);
    
    List<BizpTask> findByEntityCode(String entityCode);
}
