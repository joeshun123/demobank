package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.AdvmStep;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdvmStepRepository extends JpaRepository<AdvmStep, Long> {
    
    List<AdvmStep> findByAdvmItemSkey(Long itemSkey);
}
