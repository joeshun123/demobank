package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.BizpTaskGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BizpTaskGroupRepository extends JpaRepository<BizpTaskGroup, Long> {
    
    @Query("SELECT g FROM BizpTaskGroup g")
    List<BizpTaskGroup> findAll();
    
    @Query("SELECT g FROM BizpTaskGroup g LEFT JOIN FETCH g.details WHERE g.skey = :id")
    Optional<BizpTaskGroup> findByIdWithDetails(@Param("id") Long id);
    
    List<BizpTaskGroup> findByEntityCode(String entityCode);
    
    Optional<BizpTaskGroup> findByCode(String code);
    
    Optional<BizpTaskGroup> findByCodeAndEntityCode(String code, String entityCode);
}
