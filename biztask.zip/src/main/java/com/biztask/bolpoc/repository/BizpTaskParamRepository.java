package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.BizpTaskParam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BizpTaskParamRepository extends JpaRepository<BizpTaskParam, Long> {
    
    List<BizpTaskParam> findByBizpTaskSkey(Long taskSkey);
    
    void deleteByBizpTaskSkey(Long taskSkey);
}
