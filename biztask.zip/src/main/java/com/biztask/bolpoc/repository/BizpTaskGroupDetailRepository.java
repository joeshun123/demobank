package com.biztask.bolpoc.repository;

import com.biztask.bolpoc.entity.BizpTaskGroupDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BizpTaskGroupDetailRepository extends JpaRepository<BizpTaskGroupDetail, Long> {
    
    List<BizpTaskGroupDetail> findByBizpTaskGroupSkey(Long groupSkey);
    
    void deleteByBizpTaskGroupSkey(Long groupSkey);
    
    int countByBizpTaskGroupSkey(Long groupSkey);
    
    @Query("SELECT d FROM BizpTaskGroupDetail d " +
           "JOIN d.bizpTaskGroup tg " +
           "WHERE tg.code = :code AND tg.entityCode = :entityCode AND d.timing = :timing " +
           "ORDER BY d.taskOrder")
    List<BizpTaskGroupDetail> findByTaskGroupCodeAndEntityCodeAndTiming(
            @Param("code") String code, 
            @Param("entityCode") String entityCode, 
            @Param("timing") String timing);
    
    @Query("SELECT d FROM BizpTaskGroupDetail d " +
           "JOIN d.bizpTaskGroup tg " +
           "JOIN d.bizpTask t " +
           "WHERE tg.code = :code AND tg.entityCode = :entityCode AND d.timing = :timing " +
           "AND t.isActive = true " +
           "ORDER BY d.taskOrder")
    List<BizpTaskGroupDetail> findByTaskGroupCodeAndEntityCodeAndTimingAndActive(
            @Param("code") String code, 
            @Param("entityCode") String entityCode, 
            @Param("timing") String timing);
}
