package com.biztask.bolpoc.service;

import com.biztask.bolpoc.entity.*;
import com.biztask.bolpoc.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DataInitializationService implements CommandLineRunner {
    
    @Autowired
    private AdvmDocRepository advmDocRepository;
    
    @Autowired
    private AdvmItemRepository advmItemRepository;
    
    @Autowired
    private AdvmStepRepository advmStepRepository;
    
    @Autowired
    private BizmTaskMasterRepository bizmTaskMasterRepository;
    
    @Autowired
    private BizpTaskGroupRepository bizpTaskGroupRepository;
    
    @Autowired
    private BizpTaskGroupDetailRepository bizpTaskGroupDetailRepository;
    
    @Autowired
    private BizpTaskRepository bizpTaskRepository;
    
    @Autowired
    private BizpTaskParamRepository bizpTaskParamRepository;
    
    @Override
    @Transactional
    public void run(String... args) throws Exception {
        initializeSampleData();
        initializeTaskMasterData();
    }
    
    private void initializeSampleData() {
        // Check if data already exists
        if (advmDocRepository.count() > 0) {
            return; // Data already initialized
        }
        
        // Create ADVM_DOC records
        AdvmDoc bolDoc = new AdvmDoc("BOL");
        bolDoc = advmDocRepository.save(bolDoc);
        // Create BIZM_TASK_MASTER records
        BizmTaskMaster bolValidationTask = new BizmTaskMaster("BOL", "BOL_VALIDATION", "com.biztask.bolpoc.task.BolValidationTask", false);
        bizmTaskMasterRepository.save(bolValidationTask);

        BizmTaskMaster bolNotificationTask = new BizmTaskMaster("BOL", "BOL_NOTIFICATION", "com.biztask.bolpoc.task.BolNotificationTask", false);
        bizmTaskMasterRepository.save(bolNotificationTask);

        AdvmDoc woStrippingDoc = new AdvmDoc("WO_STRIPPING");
        woStrippingDoc = advmDocRepository.save(woStrippingDoc);
        
        // Create ADVM_ITEM records
        AdvmItem bolItem = new AdvmItem("BOL_ITEM", bolDoc);
        bolItem = advmItemRepository.save(bolItem);
        
        AdvmItem woStrippingItem = new AdvmItem("WO_STRIPPING_ITEM", woStrippingDoc);
        woStrippingItem = advmItemRepository.save(woStrippingItem);
        
        // Create ADVM_STEP records
        AdvmStep woStrippingStep1 = new AdvmStep("WO_STRIPPING_STEP1", woStrippingItem);
        advmStepRepository.save(woStrippingStep1);
        
        AdvmStep woStrippingStep2 = new AdvmStep("WO_STRIPPING_STEP2", woStrippingItem);
        advmStepRepository.save(woStrippingStep2);

        BizmTaskMaster bolItemValidationTask = new BizmTaskMaster("BOL_ITEM", "BOL_ITEM_VALIDATION", "com.biztask.bolpoc.task.BolItemValidationTask", true);
        bizmTaskMasterRepository.save(bolItemValidationTask);
        
        BizmTaskMaster woStrippingTask = new BizmTaskMaster("WO_STRIPPING", "WO_STRIPPING_PROCESS", "com.biztask.bolpoc.task.WoStrippingTask", true);
        bizmTaskMasterRepository.save(woStrippingTask);
        
        BizmTaskMaster woStrippingStep1Task = new BizmTaskMaster("WO_STRIPPING_STEP1", "WO_STRIPPING_STEP1_PROCESS", "com.biztask.bolpoc.task.WoStrippingStep1Task", true);
        bizmTaskMasterRepository.save(woStrippingStep1Task);
        
        BizmTaskMaster woStrippingStep2Task = new BizmTaskMaster("WO_STRIPPING_STEP2", "WO_STRIPPING_STEP2_PROCESS", "com.biztask.bolpoc.task.WoStrippingStep2Task", true);
        bizmTaskMasterRepository.save(woStrippingStep2Task);
        
        // Initialize BOL task group
        initializeBolTaskGroup();
        
        System.out.println("Sample data initialized successfully!");
    }
    
    private void initializeBolTaskGroup() {
        // Check if BOL task group already exists
        if (bizpTaskGroupRepository.findByCodeAndEntityCode("BOL_TASKS", "BOL").isPresent()) {
            return; // Already initialized
        }
        
        // Create BOL task group
        BizpTaskGroup bolTaskGroup = new BizpTaskGroup();
        bolTaskGroup.setCode("BOL_TASKS");
        bolTaskGroup.setEntityCode("BOL");
        bolTaskGroup.setTaskExecMode("EVALUATE_ALL");
        bolTaskGroup.setTaskErrorHandleMode("THROW");
        bolTaskGroup.setTaskExecEngine("com.biztask.bolpoc.execution.easyrules.EasyRulesTaskExecutionEngine");
        bolTaskGroup = bizpTaskGroupRepository.save(bolTaskGroup);
        
        // Create BOL validation task
        BizpTask bolValidationTask = new BizpTask();
        bolValidationTask.setEntityCode("BOL");
        bolValidationTask.setImplementationClass("com.biztask.bolpoc.execution.rules.BolValidationRule");
        bolValidationTask.setIsActive(true);
        bolValidationTask = bizpTaskRepository.save(bolValidationTask);
        
        // Create BOL audit task
        BizpTask bolAuditTask = new BizpTask();
        bolAuditTask.setEntityCode("BOL");
        bolAuditTask.setImplementationClass("com.biztask.bolpoc.execution.rules.BolAuditRule");
        bolAuditTask.setIsActive(true);
        bolAuditTask = bizpTaskRepository.save(bolAuditTask);
        
        // Create port validation task
        BizpTask portValidationTask = new BizpTask();
        portValidationTask.setEntityCode("BOL");
        portValidationTask.setImplementationClass("com.biztask.bolpoc.execution.rules.PortValidationRule");
        portValidationTask.setIsActive(true);
        portValidationTask = bizpTaskRepository.save(portValidationTask);
        
        // Create mandatory field check task
        BizpTask mandatoryFieldTask = new BizpTask();
        mandatoryFieldTask.setEntityCode("BOL");
        mandatoryFieldTask.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldTask.setIsActive(true);
        mandatoryFieldTask = bizpTaskRepository.save(mandatoryFieldTask);
        
        // Create field type check task
        BizpTask fieldTypeTask = new BizpTask();
        fieldTypeTask.setEntityCode("BOL");
        fieldTypeTask.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeTask.setIsActive(true);
        fieldTypeTask = bizpTaskRepository.save(fieldTypeTask);
        
        // Add parameters to mandatory field check task
        BizpTaskParam docNbrParam = new BizpTaskParam();
        docNbrParam.setKey("PATH");
        docNbrParam.setValue("docNbr");
        docNbrParam.setBizpTask(mandatoryFieldTask);
        bizpTaskParamRepository.save(docNbrParam);
        
        BizpTaskParam docNbrNameParam = new BizpTaskParam();
        docNbrNameParam.setKey("FIELD_NAME");
        docNbrNameParam.setValue("Document Number");
        docNbrNameParam.setBizpTask(mandatoryFieldTask);
        bizpTaskParamRepository.save(docNbrNameParam);
        
        // Add parameters to field type check task
        BizpTaskParam qtyPathParam = new BizpTaskParam();
        qtyPathParam.setKey("PATH");
        qtyPathParam.setValue("items[0].qty");
        qtyPathParam.setBizpTask(fieldTypeTask);
        bizpTaskParamRepository.save(qtyPathParam);
        
        BizpTaskParam qtyTypeParam = new BizpTaskParam();
        qtyTypeParam.setKey("EXPECTED_TYPE");
        qtyTypeParam.setValue("number");
        qtyTypeParam.setBizpTask(fieldTypeTask);
        bizpTaskParamRepository.save(qtyTypeParam);
        
        BizpTaskParam qtyNameParam = new BizpTaskParam();
        qtyNameParam.setKey("FIELD_NAME");
        qtyNameParam.setValue("Quantity");
        qtyNameParam.setBizpTask(fieldTypeTask);
        bizpTaskParamRepository.save(qtyNameParam);
        
        // Create task group details for ADD_OS
        BizpTaskGroupDetail addPortValidationDetail = new BizpTaskGroupDetail();
        addPortValidationDetail.setBizpTaskGroup(bolTaskGroup);
        addPortValidationDetail.setTaskCode("PORT_VALIDATION");
        addPortValidationDetail.setTaskOrder(1L);
        addPortValidationDetail.setTiming("ADD_OS");
        addPortValidationDetail.setIsMandatory(true);
        addPortValidationDetail.setBizpTask(portValidationTask);
        bizpTaskGroupDetailRepository.save(addPortValidationDetail);
        
        BizpTaskGroupDetail addValidationDetail = new BizpTaskGroupDetail();
        addValidationDetail.setBizpTaskGroup(bolTaskGroup);
        addValidationDetail.setTaskCode("BOL_VALIDATION");
        addValidationDetail.setTaskOrder(2L);
        addValidationDetail.setTiming("ADD_OS");
        addValidationDetail.setIsMandatory(true);
        addValidationDetail.setBizpTask(bolValidationTask);
        bizpTaskGroupDetailRepository.save(addValidationDetail);
        
        BizpTaskGroupDetail addAuditDetail = new BizpTaskGroupDetail();
        addAuditDetail.setBizpTaskGroup(bolTaskGroup);
        addAuditDetail.setTaskCode("BOL_AUDIT");
        addAuditDetail.setTaskOrder(3L);
        addAuditDetail.setTiming("ADD_OS");
        addAuditDetail.setIsMandatory(false);
        addAuditDetail.setBizpTask(bolAuditTask);
        bizpTaskGroupDetailRepository.save(addAuditDetail);
        
        // Add mandatory field check task for ADD_OS
        BizpTaskGroupDetail addMandatoryFieldDetail = new BizpTaskGroupDetail();
        addMandatoryFieldDetail.setBizpTaskGroup(bolTaskGroup);
        addMandatoryFieldDetail.setTaskCode("MANDATORY_FIELD_CHECK");
        addMandatoryFieldDetail.setTaskOrder(4L);
        addMandatoryFieldDetail.setTiming("ADD_OS");
        addMandatoryFieldDetail.setIsMandatory(true);
        addMandatoryFieldDetail.setBizpTask(mandatoryFieldTask);
        bizpTaskGroupDetailRepository.save(addMandatoryFieldDetail);
        
        // Add field type check task for ADD_OS
        BizpTaskGroupDetail addFieldTypeDetail = new BizpTaskGroupDetail();
        addFieldTypeDetail.setBizpTaskGroup(bolTaskGroup);
        addFieldTypeDetail.setTaskCode("FIELD_TYPE_CHECK");
        addFieldTypeDetail.setTaskOrder(5L);
        addFieldTypeDetail.setTiming("ADD_OS");
        addFieldTypeDetail.setIsMandatory(false);
        addFieldTypeDetail.setBizpTask(fieldTypeTask);
        bizpTaskGroupDetailRepository.save(addFieldTypeDetail);
        
        // Create task group details for EDIT_OS
        BizpTaskGroupDetail editPortValidationDetail = new BizpTaskGroupDetail();
        editPortValidationDetail.setBizpTaskGroup(bolTaskGroup);
        editPortValidationDetail.setTaskCode("PORT_VALIDATION");
        editPortValidationDetail.setTaskOrder(1L);
        editPortValidationDetail.setTiming("EDIT_OS");
        editPortValidationDetail.setIsMandatory(true);
        editPortValidationDetail.setBizpTask(portValidationTask);
        bizpTaskGroupDetailRepository.save(editPortValidationDetail);
        
        BizpTaskGroupDetail editValidationDetail = new BizpTaskGroupDetail();
        editValidationDetail.setBizpTaskGroup(bolTaskGroup);
        editValidationDetail.setTaskCode("BOL_VALIDATION");
        editValidationDetail.setTaskOrder(2L);
        editValidationDetail.setTiming("EDIT_OS");
        editValidationDetail.setIsMandatory(true);
        editValidationDetail.setBizpTask(bolValidationTask);
        bizpTaskGroupDetailRepository.save(editValidationDetail);
        
        BizpTaskGroupDetail editAuditDetail = new BizpTaskGroupDetail();
        editAuditDetail.setBizpTaskGroup(bolTaskGroup);
        editAuditDetail.setTaskCode("BOL_AUDIT");
        editAuditDetail.setTaskOrder(3L);
        editAuditDetail.setTiming("EDIT_OS");
        editAuditDetail.setIsMandatory(false);
        editAuditDetail.setBizpTask(bolAuditTask);
        bizpTaskGroupDetailRepository.save(editAuditDetail);
        
        // Create task group details for DELETE_OS
        BizpTaskGroupDetail deleteValidationDetail = new BizpTaskGroupDetail();
        deleteValidationDetail.setBizpTaskGroup(bolTaskGroup);
        deleteValidationDetail.setTaskCode("BOL_VALIDATION");
        deleteValidationDetail.setTaskOrder(1L);
        deleteValidationDetail.setTiming("DELETE_OS");
        deleteValidationDetail.setIsMandatory(true);
        deleteValidationDetail.setBizpTask(bolValidationTask);
        bizpTaskGroupDetailRepository.save(deleteValidationDetail);
        
        BizpTaskGroupDetail deleteAuditDetail = new BizpTaskGroupDetail();
        deleteAuditDetail.setBizpTaskGroup(bolTaskGroup);
        deleteAuditDetail.setTaskCode("BOL_AUDIT");
        deleteAuditDetail.setTaskOrder(2L);
        deleteAuditDetail.setTiming("DELETE_OS");
        deleteAuditDetail.setIsMandatory(false);
        deleteAuditDetail.setBizpTask(bolAuditTask);
        bizpTaskGroupDetailRepository.save(deleteAuditDetail);
        
        System.out.println("BOL task group initialized successfully!");
    }
    
    private void initializeTaskMasterData() {
        // Check if validation rules already exist
        if (bizmTaskMasterRepository.findByCodeAndEntityCode("PORT_VALIDATION", "BOL").isPresent()) {
            return; // Validation rules already initialized
        }
        
        // PortValidationRule for BOL entity
        BizmTaskMaster portValidationMaster = new BizmTaskMaster();
        portValidationMaster.setCode("PORT_VALIDATION");
        portValidationMaster.setEntityCode("BOL");
        portValidationMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.PortValidationRule");
        portValidationMaster.setIsActive(true);
        bizmTaskMasterRepository.save(portValidationMaster);
        
        // MandatoryFieldCheckRule for BOL entity
        BizmTaskMaster mandatoryFieldBolMaster = new BizmTaskMaster();
        mandatoryFieldBolMaster.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldBolMaster.setEntityCode("BOL");
        mandatoryFieldBolMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldBolMaster.setIsActive(false);
        mandatoryFieldBolMaster.setParameters("{\"PATH\": \"The SpEL path of the target field\", \"FIELD_NAME\": \"The display name of the field for error messages\"}");
        bizmTaskMasterRepository.save(mandatoryFieldBolMaster);
        
        // MandatoryFieldCheckRule for BOL_ITEM entity
        BizmTaskMaster mandatoryFieldBolItemMaster = new BizmTaskMaster();
        mandatoryFieldBolItemMaster.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldBolItemMaster.setEntityCode("BOL_ITEM");
        mandatoryFieldBolItemMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldBolItemMaster.setIsActive(true);
        bizmTaskMasterRepository.save(mandatoryFieldBolItemMaster);
        
        // MandatoryFieldCheckRule for WO_STRIPPING entity
        BizmTaskMaster mandatoryFieldWoStrippingMaster = new BizmTaskMaster();
        mandatoryFieldWoStrippingMaster.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldWoStrippingMaster.setEntityCode("WO_STRIPPING");
        mandatoryFieldWoStrippingMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldWoStrippingMaster.setIsActive(true);
        bizmTaskMasterRepository.save(mandatoryFieldWoStrippingMaster);
        
        // MandatoryFieldCheckRule for WO_STRIPPING_ITEM entity
        BizmTaskMaster mandatoryFieldWoStrippingItemMaster = new BizmTaskMaster();
        mandatoryFieldWoStrippingItemMaster.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldWoStrippingItemMaster.setEntityCode("WO_STRIPPING_ITEM");
        mandatoryFieldWoStrippingItemMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldWoStrippingItemMaster.setIsActive(true);
        bizmTaskMasterRepository.save(mandatoryFieldWoStrippingItemMaster);
        
        // MandatoryFieldCheckRule for WO_STRIPPING_STEP1 entity
        BizmTaskMaster mandatoryFieldWoStrippingStep1Master = new BizmTaskMaster();
        mandatoryFieldWoStrippingStep1Master.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldWoStrippingStep1Master.setEntityCode("WO_STRIPPING_STEP1");
        mandatoryFieldWoStrippingStep1Master.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldWoStrippingStep1Master.setIsActive(true);
        bizmTaskMasterRepository.save(mandatoryFieldWoStrippingStep1Master);
        
        // MandatoryFieldCheckRule for WO_STRIPPING_STEP2 entity
        BizmTaskMaster mandatoryFieldWoStrippingStep2Master = new BizmTaskMaster();
        mandatoryFieldWoStrippingStep2Master.setCode("MANDATORY_FIELD_CHECK");
        mandatoryFieldWoStrippingStep2Master.setEntityCode("WO_STRIPPING_STEP2");
        mandatoryFieldWoStrippingStep2Master.setImplementationClass("com.biztask.bolpoc.execution.rules.MandatoryFieldCheckRule");
        mandatoryFieldWoStrippingStep2Master.setIsActive(true);
        bizmTaskMasterRepository.save(mandatoryFieldWoStrippingStep2Master);
        
        // FieldTypeCheckRule for BOL entity
        BizmTaskMaster fieldTypeBolMaster = new BizmTaskMaster();
        fieldTypeBolMaster.setCode("FIELD_TYPE_CHECK");
        fieldTypeBolMaster.setEntityCode("BOL");
        fieldTypeBolMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeBolMaster.setIsActive(true);
        fieldTypeBolMaster.setParameters("{\"PATH\": \"The SpEL path of the target field\", \"EXPECTED_TYPE\": \"The expected data type (number, string, boolean, etc.)\", \"FIELD_NAME\": \"The display name of the field for error messages\"}");
        bizmTaskMasterRepository.save(fieldTypeBolMaster);
        
        // FieldTypeCheckRule for BOL_ITEM entity
        BizmTaskMaster fieldTypeBolItemMaster = new BizmTaskMaster();
        fieldTypeBolItemMaster.setCode("FIELD_TYPE_CHECK");
        fieldTypeBolItemMaster.setEntityCode("BOL_ITEM");
        fieldTypeBolItemMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeBolItemMaster.setIsActive(true);
        bizmTaskMasterRepository.save(fieldTypeBolItemMaster);
        
        // FieldTypeCheckRule for WO_STRIPPING entity
        BizmTaskMaster fieldTypeWoStrippingMaster = new BizmTaskMaster();
        fieldTypeWoStrippingMaster.setCode("FIELD_TYPE_CHECK");
        fieldTypeWoStrippingMaster.setEntityCode("WO_STRIPPING");
        fieldTypeWoStrippingMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeWoStrippingMaster.setIsActive(true);
        bizmTaskMasterRepository.save(fieldTypeWoStrippingMaster);
        
        // FieldTypeCheckRule for WO_STRIPPING_ITEM entity
        BizmTaskMaster fieldTypeWoStrippingItemMaster = new BizmTaskMaster();
        fieldTypeWoStrippingItemMaster.setCode("FIELD_TYPE_CHECK");
        fieldTypeWoStrippingItemMaster.setEntityCode("WO_STRIPPING_ITEM");
        fieldTypeWoStrippingItemMaster.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeWoStrippingItemMaster.setIsActive(true);
        bizmTaskMasterRepository.save(fieldTypeWoStrippingItemMaster);
        
        // FieldTypeCheckRule for WO_STRIPPING_STEP1 entity
        BizmTaskMaster fieldTypeWoStrippingStep1Master = new BizmTaskMaster();
        fieldTypeWoStrippingStep1Master.setCode("FIELD_TYPE_CHECK");
        fieldTypeWoStrippingStep1Master.setEntityCode("WO_STRIPPING_STEP1");
        fieldTypeWoStrippingStep1Master.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeWoStrippingStep1Master.setIsActive(true);
        bizmTaskMasterRepository.save(fieldTypeWoStrippingStep1Master);
        
        // FieldTypeCheckRule for WO_STRIPPING_STEP2 entity
        BizmTaskMaster fieldTypeWoStrippingStep2Master = new BizmTaskMaster();
        fieldTypeWoStrippingStep2Master.setCode("FIELD_TYPE_CHECK");
        fieldTypeWoStrippingStep2Master.setEntityCode("WO_STRIPPING_STEP2");
        fieldTypeWoStrippingStep2Master.setImplementationClass("com.biztask.bolpoc.execution.rules.FieldTypeCheckRule");
        fieldTypeWoStrippingStep2Master.setIsActive(true);
        bizmTaskMasterRepository.save(fieldTypeWoStrippingStep2Master);
        
        System.out.println("Task master data initialized successfully!");
    }
}
