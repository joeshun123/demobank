package com.biztask.bolpoc.service;

import com.biztask.bolpoc.dto.*;
import com.biztask.bolpoc.entity.*;
import com.biztask.bolpoc.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class BizpTaskGroupService {
    
    @Autowired
    private BizpTaskGroupRepository bizpTaskGroupRepository;
    
    @Autowired
    private BizpTaskGroupDetailRepository bizpTaskGroupDetailRepository;
    
    @Autowired
    private BizpTaskRepository bizpTaskRepository;
    
    @Autowired
    private BizpTaskParamRepository bizpTaskParamRepository;
    
    @Autowired
    private BizmTaskMasterRepository bizmTaskMasterRepository;
    
    @Autowired
    private AdvmDocRepository advmDocRepository;
    
    @Autowired
    private AdvmItemRepository advmItemRepository;
    
    @Autowired
    private AdvmStepRepository advmStepRepository;
    
    public List<BizpTaskGroupDto> getAllTaskGroups() {
        return bizpTaskGroupRepository.findAll().stream()
                .map(this::convertToDtoWithTaskCount)
                .collect(Collectors.toList());
    }
    
    public Optional<BizpTaskGroupDto> getTaskGroupById(Long id) {
        return bizpTaskGroupRepository.findByIdWithDetails(id)
                .map(entity -> {
                    BizpTaskGroupDto dto = new BizpTaskGroupDto();
                    dto.setSkey(entity.getSkey());
                    dto.setCode(entity.getCode());
                    dto.setEntityCode(entity.getEntityCode());
                    dto.setTaskExecMode(entity.getTaskExecMode());
                    dto.setTaskErrorHandleMode(entity.getTaskErrorHandleMode());
                    
                    // Convert details with proper handling
                    if (entity.getDetails() != null) {
                        dto.setDetails(entity.getDetails().stream()
                                .map(this::convertDetailToDto)
                                .collect(Collectors.toList()));
                    } else {
                        dto.setDetails(new ArrayList<>());
                    }
                    
                    return dto;
                });
    }
    
    public BizpTaskGroupDto getTaskGroupByCodeAndEntity(String code, String entityCode) {
        return bizpTaskGroupRepository.findByCodeAndEntityCode(code, entityCode)
                .map(this::convertToDto)
                .orElse(null);
    }
    
    public List<BizpTaskGroupDetailDto> getTasksByCodeEntityAndTiming(String code, String entityCode, String timing) {
        return bizpTaskGroupDetailRepository.findByTaskGroupCodeAndEntityCodeAndTiming(code, entityCode, timing)
                .stream()
                .map(this::convertDetailToDto)
                .collect(Collectors.toList());
    }
    
    public List<BizpTaskGroupDetailDto> getTasksByCodeEntityAndTiming(String code, String entityCode, String timing, boolean activeOnly) {
        if (activeOnly) {
            return bizpTaskGroupDetailRepository.findByTaskGroupCodeAndEntityCodeAndTimingAndActive(code, entityCode, timing)
                    .stream()
                    .map(this::convertDetailToDto)
                    .collect(Collectors.toList());
        } else {
            return getTasksByCodeEntityAndTiming(code, entityCode, timing);
        }
    }
    
    public BizpTaskGroupDto createTaskGroup(BizpTaskGroupDto dto) {
        BizpTaskGroup entity = convertToEntity(dto);
        BizpTaskGroup savedEntity = bizpTaskGroupRepository.save(entity);
        
        // Save details if provided
        if (dto.getDetails() != null && !dto.getDetails().isEmpty()) {
            for (BizpTaskGroupDetailDto detailDto : dto.getDetails()) {
                // First save the BizpTask if it exists
                BizpTask bizpTask = null;
                if (detailDto.getBizpTask() != null) {
                    bizpTask = convertBizpTaskToEntity(detailDto.getBizpTask());
                    bizpTask = bizpTaskRepository.save(bizpTask);
                }
                
                // Then create and save the detail
                BizpTaskGroupDetail detail = new BizpTaskGroupDetail();
                detail.setTaskCode(detailDto.getTaskCode());
                detail.setTaskOrder(detailDto.getTaskOrder());
                detail.setTiming(detailDto.getTiming());
                detail.setIsMandatory(detailDto.getIsMandatory());
                detail.setBizpTaskGroup(savedEntity);
                detail.setBizpTask(bizpTask);
                
                bizpTaskGroupDetailRepository.save(detail);
            }
        }
        
        return convertToDto(savedEntity);
    }
    
    public BizpTaskGroupDto updateTaskGroup(Long id, BizpTaskGroupDto dto) {
        log.info("Starting updateTaskGroup for id: {}, dto: {}", id, dto);
        BizpTaskGroup existingEntity = bizpTaskGroupRepository.findByIdWithDetails(id)
                .orElseThrow(() -> {
                    log.error("Task group not found with id: {}", id);
                    return new RuntimeException("Task group not found with id: " + id);
                });
        
        // Update main group
        log.info("Updating main group properties");
        existingEntity.setCode(dto.getCode());
        existingEntity.setEntityCode(dto.getEntityCode());
        existingEntity.setTaskExecMode(dto.getTaskExecMode());
        existingEntity.setTaskErrorHandleMode(dto.getTaskErrorHandleMode());
        
        // Clear existing details - explicitly delete them from repository
        log.info("Clearing existing details, count: {}", existingEntity.getDetails().size());
        List<BizpTaskGroupDetail> existingDetails = new ArrayList<>(existingEntity.getDetails());
        for (BizpTaskGroupDetail detail : existingDetails) {
            existingEntity.removeDetail(detail);
        }
        // Also delete from repository to ensure they are removed
        bizpTaskGroupDetailRepository.deleteAll(existingDetails);
        
        // Add new details
        if (dto.getDetails() != null && !dto.getDetails().isEmpty()) {
            log.info("Processing {} new details", dto.getDetails().size());
            for (BizpTaskGroupDetailDto detailDto : dto.getDetails()) {
                // Handle BizpTask - update if exists, create if new
                log.info("Processing detail: taskCode={}, taskSkey={}", detailDto.getTaskCode(), 
                        detailDto.getBizpTask() != null ? detailDto.getBizpTask().getSkey() : "null");
                BizpTask bizpTask = null;
                if (detailDto.getBizpTask() != null) {
                    if (detailDto.getBizpTask().getSkey() != null) {
                        // Update existing task
                        log.info("Updating existing task with skey: {}", detailDto.getBizpTask().getSkey());
                        bizpTask = bizpTaskRepository.findById(detailDto.getBizpTask().getSkey())
                                .orElseThrow(() -> {
                                    log.error("Task not found with id: {}", detailDto.getBizpTask().getSkey());
                                    return new RuntimeException("Task not found with id: " + detailDto.getBizpTask().getSkey());
                                });
                        bizpTask.setEntityCode(detailDto.getBizpTask().getEntityCode());
                        bizpTask.setImplementationClass(detailDto.getBizpTask().getImplementationClass());
                        bizpTask.setIsActive(detailDto.getBizpTask().getIsActive());
                        
                        // Clear existing params and add new ones
                        log.info("Clearing existing params and adding new ones, count: {}", 
                                detailDto.getBizpTask().getParams() != null ? detailDto.getBizpTask().getParams().size() : 0);
                        bizpTask.getParams().clear();
                        if (detailDto.getBizpTask().getParams() != null) {
                            for (BizpTaskParamDto paramDto : detailDto.getBizpTask().getParams()) {
                                BizpTaskParam param = convertBizpTaskParamToEntity(paramDto);
                                param.setBizpTask(bizpTask);
                                bizpTask.addParam(param);
                            }
                        }
                    } else {
                        // Create new task
                        log.info("Creating new task");
                        bizpTask = convertBizpTaskToEntity(detailDto.getBizpTask());
                    }
                    log.info("Saving task with skey: {}", bizpTask.getSkey());
                    bizpTask = bizpTaskRepository.save(bizpTask);
                }
                
                // Create and add the detail
                log.info("Creating detail for taskCode: {}", detailDto.getTaskCode());
                BizpTaskGroupDetail detail = new BizpTaskGroupDetail();
                detail.setTaskCode(detailDto.getTaskCode());
                detail.setTaskOrder(detailDto.getTaskOrder());
                detail.setTiming(detailDto.getTiming());
                detail.setIsMandatory(detailDto.getIsMandatory());
                detail.setBizpTaskGroup(existingEntity);
                detail.setBizpTask(bizpTask);
                
                existingEntity.addDetail(detail);
            }
        }
        
        log.info("Saving updated entity");
        BizpTaskGroup savedEntity = bizpTaskGroupRepository.save(existingEntity);
        
        // Return a simple response without trying to reload all data
        log.info("Creating response DTO");
        BizpTaskGroupDto responseDto = new BizpTaskGroupDto();
        responseDto.setSkey(savedEntity.getSkey());
        responseDto.setCode(savedEntity.getCode());
        responseDto.setEntityCode(savedEntity.getEntityCode());
        responseDto.setTaskExecMode(savedEntity.getTaskExecMode());
        responseDto.setTaskErrorHandleMode(savedEntity.getTaskErrorHandleMode());
        responseDto.setDetails(new ArrayList<>());
        responseDto.setTaskCount(0);
        
        log.info("Update completed successfully, returning response: {}", responseDto);
        return responseDto;
    }
    
    public void deleteTaskGroup(Long id) {
        if (!bizpTaskGroupRepository.existsById(id)) {
            throw new RuntimeException("Task group not found with id: " + id);
        }
        bizpTaskGroupRepository.deleteById(id);
    }
    
    // Metadata services
    public List<AdvmDocDto> getAllAdvmDocs() {
        return advmDocRepository.findAllWithItems().stream()
                .map(this::convertAdvmDocToDto)
                .collect(Collectors.toList());
    }
    
    public List<AdvmItemDto> getAdvmItemsByDocSkey(Long docSkey) {
        return advmItemRepository.findByAdvmDocSkeyWithSteps(docSkey).stream()
                .map(this::convertAdvmItemToDto)
                .collect(Collectors.toList());
    }
    
    public List<AdvmStepDto> getAdvmStepsByItemSkey(Long itemSkey) {
        return advmStepRepository.findByAdvmItemSkey(itemSkey).stream()
                .map(this::convertAdvmStepToDto)
                .collect(Collectors.toList());
    }
    
    public List<BizmTaskMasterDto> getActiveTasksByEntityCode(String entityCode) {
        return bizmTaskMasterRepository.findByEntityCodeAndIsActiveTrue(entityCode).stream()
                .map(this::convertBizmTaskMasterToDto)
                .collect(Collectors.toList());
    }
    
    public List<String> getTaskExecModes() {
        return List.of("EVALUATE_ALL", "STOP_ON_FAILURE");
    }
    
    public List<String> getTaskErrorHandleModes() {
        return List.of("GO_TO_TROUBLE", "THROW");
    }
    
    public List<String> getTimingOptions() {
        return List.of("ADD_OS", "EDIT_OS", "DELETE_OS", "ON_TROUBLE", "NO_TROUBLE");
    }
    
    // Task Master services
    public List<BizmTaskMasterDto> getAllTaskMasters() {
        return bizmTaskMasterRepository.findAll().stream()
                .map(this::convertBizmTaskMasterToDto)
                .collect(Collectors.toList());
    }
    
    public Optional<BizmTaskMasterDto> getTaskMasterById(Long id) {
        return bizmTaskMasterRepository.findById(id)
                .map(this::convertBizmTaskMasterToDto);
    }
    
    public BizmTaskMasterDto createTaskMaster(BizmTaskMasterDto dto) {
        BizmTaskMaster entity = convertBizmTaskMasterToEntity(dto);
        BizmTaskMaster savedEntity = bizmTaskMasterRepository.save(entity);
        return convertBizmTaskMasterToDto(savedEntity);
    }
    
    public BizmTaskMasterDto updateTaskMaster(Long id, BizmTaskMasterDto dto) {
        BizmTaskMaster existingEntity = bizmTaskMasterRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task master not found with id: " + id));
        
        existingEntity.setEntityCode(dto.getEntityCode());
        existingEntity.setCode(dto.getCode());
        existingEntity.setImplementationClass(dto.getImplementationClass());
        existingEntity.setIsActive(dto.getIsActive());
        existingEntity.setParameters(dto.getParameters());
        
        BizmTaskMaster savedEntity = bizmTaskMasterRepository.save(existingEntity);
        return convertBizmTaskMasterToDto(savedEntity);
    }
    
    public void deleteTaskMaster(Long id) {
        if (!bizmTaskMasterRepository.existsById(id)) {
            throw new RuntimeException("Task master not found with id: " + id);
        }
        bizmTaskMasterRepository.deleteById(id);
    }
    
    // Conversion methods
    private BizpTaskGroupDto convertToDto(BizpTaskGroup entity) {
        BizpTaskGroupDto dto = new BizpTaskGroupDto();
        dto.setSkey(entity.getSkey());
        dto.setCode(entity.getCode());
        dto.setEntityCode(entity.getEntityCode());
        dto.setTaskExecMode(entity.getTaskExecMode());
        dto.setTaskErrorHandleMode(entity.getTaskErrorHandleMode());
        dto.setTaskExecEngine(entity.getTaskExecEngine());
        
        // For now, set empty details to avoid lazy loading issues
        dto.setDetails(new ArrayList<>());
        
        return dto;
    }
    
    private BizpTaskGroupDto convertToDtoWithTaskCount(BizpTaskGroup entity) {
        BizpTaskGroupDto dto = new BizpTaskGroupDto();
        dto.setSkey(entity.getSkey());
        dto.setCode(entity.getCode());
        dto.setEntityCode(entity.getEntityCode());
        dto.setTaskExecMode(entity.getTaskExecMode());
        dto.setTaskErrorHandleMode(entity.getTaskErrorHandleMode());
        dto.setTaskExecEngine(entity.getTaskExecEngine());
        
        // Get task count without loading all details
        int taskCount = bizpTaskGroupDetailRepository.countByBizpTaskGroupSkey(entity.getSkey());
        dto.setTaskCount(taskCount);
        dto.setDetails(new ArrayList<>()); // Empty details but we'll show the count in the UI
        
        return dto;
    }
    
    private BizpTaskGroupDto convertToDtoWithDetails(BizpTaskGroup entity) {
        try {
            BizpTaskGroupDto dto = new BizpTaskGroupDto();
            dto.setSkey(entity.getSkey());
            dto.setCode(entity.getCode());
            dto.setEntityCode(entity.getEntityCode());
            dto.setTaskExecMode(entity.getTaskExecMode());
            dto.setTaskErrorHandleMode(entity.getTaskErrorHandleMode());
            dto.setTaskExecEngine(entity.getTaskExecEngine());
            
            // Convert details with proper handling
            if (entity.getDetails() != null) {
                System.out.println("Converting details, count: " + entity.getDetails().size());
                dto.setDetails(entity.getDetails().stream()
                        .map(this::convertDetailToDto)
                        .collect(Collectors.toList()));
            } else {
                System.out.println("Details is null, setting empty list");
                dto.setDetails(new ArrayList<>());
            }
            
            System.out.println("Converted DTO successfully, details count: " + dto.getDetails().size());
            return dto;
        } catch (Exception e) {
            System.err.println("Error in convertToDtoWithDetails: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    private BizpTaskGroup convertToEntity(BizpTaskGroupDto dto) {
        BizpTaskGroup entity = new BizpTaskGroup();
        entity.setSkey(dto.getSkey());
        entity.setCode(dto.getCode());
        entity.setEntityCode(dto.getEntityCode());
        entity.setTaskExecMode(dto.getTaskExecMode());
        entity.setTaskErrorHandleMode(dto.getTaskErrorHandleMode());
        return entity;
    }
    
    private BizpTaskGroupDetailDto convertDetailToDto(BizpTaskGroupDetail entity) {
        try {
            System.out.println("Converting detail: " + entity.getSkey() + ", taskCode: " + entity.getTaskCode());
            BizpTaskGroupDetailDto dto = new BizpTaskGroupDetailDto();
            dto.setSkey(entity.getSkey());
            dto.setTaskCode(entity.getTaskCode());
            dto.setTaskOrder(entity.getTaskOrder());
            dto.setTiming(entity.getTiming());
            dto.setIsMandatory(entity.getIsMandatory());
            
            if (entity.getBizpTask() != null) {
                System.out.println("Converting bizpTask: " + entity.getBizpTask().getSkey());
                dto.setBizpTask(convertBizpTaskToDto(entity.getBizpTask()));
            } else {
                System.out.println("BizpTask is null for detail: " + entity.getSkey());
            }
            
            return dto;
        } catch (Exception e) {
            System.err.println("Error in convertDetailToDto: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    private BizpTaskGroupDetail convertDetailToEntity(BizpTaskGroupDetailDto dto) {
        BizpTaskGroupDetail entity = new BizpTaskGroupDetail();
        entity.setSkey(dto.getSkey());
        entity.setTaskCode(dto.getTaskCode());
        entity.setTaskOrder(dto.getTaskOrder());
        entity.setTiming(dto.getTiming());
        entity.setIsMandatory(dto.getIsMandatory());
        
        if (dto.getBizpTask() != null) {
            entity.setBizpTask(convertBizpTaskToEntity(dto.getBizpTask()));
        }
        
        return entity;
    }
    
    private BizpTaskDto convertBizpTaskToDto(BizpTask entity) {
        BizpTaskDto dto = new BizpTaskDto();
        dto.setSkey(entity.getSkey());
        dto.setEntityCode(entity.getEntityCode());
        dto.setImplementationClass(entity.getImplementationClass());
        dto.setIsActive(entity.getIsActive());
        
        if (entity.getParams() != null) {
            dto.setParams(entity.getParams().stream()
                    .map(this::convertBizpTaskParamToDto)
                    .collect(Collectors.toList()));
        }
        
        // Fetch master task parameters from BIZM_TASK_MASTER
        try {
            Optional<BizmTaskMaster> masterTask = bizmTaskMasterRepository.findByCodeAndEntityCode(
                entity.getImplementationClass().substring(entity.getImplementationClass().lastIndexOf('.') + 1),
                entity.getEntityCode()
            );
            if (masterTask.isPresent()) {
                dto.setParameters(masterTask.get().getParameters());
            }
        } catch (Exception e) {
            log.warn("Could not fetch master task parameters for implementation class: {}", entity.getImplementationClass(), e);
        }
        
        return dto;
    }
    
    private BizpTask convertBizpTaskToEntity(BizpTaskDto dto) {
        BizpTask entity = new BizpTask();
        entity.setSkey(dto.getSkey());
        entity.setEntityCode(dto.getEntityCode());
        entity.setImplementationClass(dto.getImplementationClass());
        entity.setIsActive(dto.getIsActive());
        
        if (dto.getParams() != null) {
            for (BizpTaskParamDto paramDto : dto.getParams()) {
                BizpTaskParam param = convertBizpTaskParamToEntity(paramDto);
                param.setBizpTask(entity);
                entity.addParam(param);
            }
        }
        
        return entity;
    }
    
    private BizpTaskParamDto convertBizpTaskParamToDto(BizpTaskParam entity) {
        BizpTaskParamDto dto = new BizpTaskParamDto();
        dto.setSkey(entity.getSkey());
        dto.setKey(entity.getKey());
        dto.setValue(entity.getValue());
        return dto;
    }
    
    private BizpTaskParam convertBizpTaskParamToEntity(BizpTaskParamDto dto) {
        BizpTaskParam entity = new BizpTaskParam();
        entity.setSkey(dto.getSkey());
        entity.setKey(dto.getKey());
        entity.setValue(dto.getValue());
        return entity;
    }
    
    private AdvmDocDto convertAdvmDocToDto(AdvmDoc entity) {
        AdvmDocDto dto = new AdvmDocDto();
        dto.setSkey(entity.getSkey());
        dto.setEntityCode(entity.getEntityCode());
        
        if (entity.getItems() != null) {
            dto.setItems(entity.getItems().stream()
                    .map(this::convertAdvmItemToDto)
                    .collect(Collectors.toList()));
        }
        
        return dto;
    }
    
    private AdvmItemDto convertAdvmItemToDto(AdvmItem entity) {
        AdvmItemDto dto = new AdvmItemDto();
        dto.setSkey(entity.getSkey());
        dto.setEntityCode(entity.getEntityCode());
        dto.setDocKey(entity.getAdvmDoc() != null ? entity.getAdvmDoc().getSkey() : null);
        
        if (entity.getSteps() != null) {
            dto.setSteps(entity.getSteps().stream()
                    .map(this::convertAdvmStepToDto)
                    .collect(Collectors.toList()));
        }
        
        return dto;
    }
    
    private AdvmStepDto convertAdvmStepToDto(AdvmStep entity) {
        AdvmStepDto dto = new AdvmStepDto();
        dto.setSkey(entity.getSkey());
        dto.setEntityCode(entity.getEntityCode());
        dto.setItemKey(entity.getAdvmItem() != null ? entity.getAdvmItem().getSkey() : null);
        return dto;
    }
    
    private BizmTaskMasterDto convertBizmTaskMasterToDto(BizmTaskMaster entity) {
        BizmTaskMasterDto dto = new BizmTaskMasterDto();
        dto.setSkey(entity.getSkey());
        dto.setEntityCode(entity.getEntityCode());
        dto.setCode(entity.getCode());
        dto.setImplementationClass(entity.getImplementationClass());
        dto.setIsActive(entity.getIsActive());
        dto.setParameters(entity.getParameters());
        return dto;
    }
    
    private BizmTaskMaster convertBizmTaskMasterToEntity(BizmTaskMasterDto dto) {
        BizmTaskMaster entity = new BizmTaskMaster();
        entity.setSkey(dto.getSkey());
        entity.setEntityCode(dto.getEntityCode());
        entity.setCode(dto.getCode());
        entity.setImplementationClass(dto.getImplementationClass());
        entity.setIsActive(dto.getIsActive());
        entity.setParameters(dto.getParameters());
        return entity;
    }
}
