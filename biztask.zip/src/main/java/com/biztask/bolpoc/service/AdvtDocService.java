package com.biztask.bolpoc.service;

import com.biztask.bolpoc.dto.AdvtDocDto;
import com.biztask.bolpoc.dto.AdvtDocItemDto;
import com.biztask.bolpoc.entity.AdvtDoc;
import com.biztask.bolpoc.entity.AdvtDocItem;
import com.biztask.bolpoc.exception.ValidationException;
import com.biztask.bolpoc.execution.TaskExecutionResult;
import com.biztask.bolpoc.execution.TaskExecutionService;
import com.biztask.bolpoc.repository.AdvtDocRepository;
import com.biztask.bolpoc.repository.AdvtDocItemRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@Transactional
public class AdvtDocService {
    
    @Autowired
    private AdvtDocRepository advtDocRepository;
    
    @Autowired
    private AdvtDocItemRepository advtDocItemRepository;
    
    @Autowired
    private TaskExecutionService taskExecutionService;
    
    private static final String[] VALID_PORTS = {
        "USLAX", "SGSIN", "CNHKG", "DEHAM", "JPTYO", 
        "NLRTM", "USNYC", "AEJEA", "CNBND"
    };
    
    public List<AdvtDocDto> getAllBolDocuments() {
        return advtDocRepository.findAllWithItems().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    public Optional<AdvtDocDto> getBolDocumentById(Long id) {
        return advtDocRepository.findByIdWithItems(id)
                .map(this::convertToDto);
    }
    
    public AdvtDocDto createBolDocument(AdvtDocDto dto) {
        log.info("Creating BOL document: {}", dto.getDocNbr());
        
        // Execute validation tasks before creating the document
        List<TaskExecutionResult> validationResults = taskExecutionService.executeTasks(
            "BOL_TASKS", "BOL", "ADD_OS", dto, "system"
        );
        
        // Check for validation failures
        List<TaskExecutionResult> failures = validationResults.stream()
            .filter(result -> !result.isSuccess())
            .collect(Collectors.toList());
        
        if (!failures.isEmpty()) {
            log.error("Validation failed for BOL creation: {}", failures);
            String errorMessage = failures.stream()
                .map(TaskExecutionResult::getMessage)
                .collect(Collectors.joining("; "));
            throw new RuntimeException("Validation failed: " + errorMessage);
        }
        
        log.info("All validations passed, proceeding with BOL creation");
        
        AdvtDoc entity = convertToEntity(dto);
        entity.setDocType("BOL"); // Set default document type
        
        AdvtDoc savedEntity = advtDocRepository.save(entity);
        
        // Save items if provided
        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            for (AdvtDocItemDto itemDto : dto.getItems()) {
                AdvtDocItem item = convertItemToEntity(itemDto);
                item.setAdvtDoc(savedEntity);
                advtDocItemRepository.save(item);
            }
        }
        
        log.info("BOL document created successfully with ID: {}", savedEntity.getSkey());
        return convertToDto(savedEntity);
    }
    
    public AdvtDocDto updateBolDocument(Long id, AdvtDocDto dto) {
        log.info("Updating BOL document: {} with ID: {}", dto.getDocNbr(), id);
        
        // Execute validation tasks before updating the document
        List<TaskExecutionResult> validationResults = taskExecutionService.executeTasks(
            "BOL_TASKS", "BOL", "EDIT_OS", dto, "system"
        );
        
        // Check for validation failures
        List<TaskExecutionResult> failures = validationResults.stream()
            .filter(result -> !result.isSuccess())
            .collect(Collectors.toList());
        
        if (!failures.isEmpty()) {
            log.error("Validation failed for BOL update: {}", failures);
            String errorMessage = failures.stream()
                .map(TaskExecutionResult::getMessage)
                .collect(Collectors.joining("; "));
            throw new RuntimeException("Validation failed: " + errorMessage);
        }
        
        log.info("All validations passed, proceeding with BOL update");
        
        AdvtDoc existingEntity = advtDocRepository.findByIdWithItems(id)
                .orElseThrow(() -> new RuntimeException("BOL document not found with id: " + id));
        
        // Update main document
        existingEntity.setDocNbr(dto.getDocNbr());
        existingEntity.setConsigneeName(dto.getConsigneeName());
        existingEntity.setPortOfDestination(dto.getPortOfDestination());
        
        // Clear existing items
        existingEntity.getItems().clear();
        
        // Add new items
        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            for (AdvtDocItemDto itemDto : dto.getItems()) {
                AdvtDocItem item = convertItemToEntity(itemDto);
                item.setAdvtDoc(existingEntity);
                existingEntity.addItem(item);
            }
        }
        
        AdvtDoc savedEntity = advtDocRepository.save(existingEntity);
        log.info("BOL document updated successfully with ID: {}", savedEntity.getSkey());
        return convertToDto(savedEntity);
    }
    
    public void deleteBolDocument(Long id) {
        if (!advtDocRepository.existsById(id)) {
            throw new RuntimeException("BOL document not found with id: " + id);
        }
        advtDocRepository.deleteById(id);
    }
    
    public List<String> getValidPorts() {
        return List.of(VALID_PORTS);
    }
    
    
    private AdvtDocDto convertToDto(AdvtDoc entity) {
        AdvtDocDto dto = new AdvtDocDto();
        dto.setSkey(entity.getSkey());
        dto.setDocType(entity.getDocType());
        dto.setDocNbr(entity.getDocNbr());
        dto.setConsigneeName(entity.getConsigneeName());
        dto.setPortOfDestination(entity.getPortOfDestination());
        
        if (entity.getItems() != null) {
            dto.setItems(entity.getItems().stream()
                    .map(this::convertItemToDto)
                    .collect(Collectors.toList()));
        }
        
        return dto;
    }
    
    private AdvtDoc convertToEntity(AdvtDocDto dto) {
        AdvtDoc entity = new AdvtDoc();
        entity.setSkey(dto.getSkey());
        entity.setDocType(dto.getDocType());
        entity.setDocNbr(dto.getDocNbr());
        entity.setConsigneeName(dto.getConsigneeName());
        entity.setPortOfDestination(dto.getPortOfDestination());
        return entity;
    }
    
    private AdvtDocItemDto convertItemToDto(AdvtDocItem entity) {
        AdvtDocItemDto dto = new AdvtDocItemDto();
        dto.setSkey(entity.getSkey());
        dto.setDocKey(entity.getAdvtDoc() != null ? entity.getAdvtDoc().getSkey() : null);
        dto.setCargoDescription(entity.getCargoDescription());
        dto.setQty(entity.getQty());
        dto.setWeight(entity.getWeight());
        dto.setVolume(entity.getVolume());
        dto.setMarks(entity.getMarks());
        return dto;
    }
    
    private AdvtDocItem convertItemToEntity(AdvtDocItemDto dto) {
        AdvtDocItem entity = new AdvtDocItem();
        entity.setSkey(dto.getSkey());
        entity.setCargoDescription(dto.getCargoDescription());
        entity.setQty(dto.getQty());
        entity.setWeight(dto.getWeight());
        entity.setVolume(dto.getVolume());
        entity.setMarks(dto.getMarks());
        return entity;
    }
}
