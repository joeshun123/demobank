# Bill of Lading (BOL) POC - BizTask Framework

This is a Proof of Concept (POC) application for the BizTask framework, implementing a Bill of Lading management system.

## Technology Stack

- **Backend**: Java 21, Spring Boot 3.2.0, Spring Data JPA
- **Frontend**: React.js 18.2.0
- **Database**: H2 (in-memory)
- **Build Tool**: Maven

## Features

### 1. BOL Document Management
- Create, Read, Update, Delete BOL documents
- Document validation with required fields
- Consignee name validation against predefined list

### 2. BOL Item Management
- Add, Edit, Delete items for each BOL document
- Item validation (quantity, weight, volume, marks)
- Real-time item management in modal dialogs

### 3. User Interface
- Responsive React.js frontend
- Modal-based item management
- Checkbox selection for bulk operations
- Form validation and error handling

### 4. Database Schema

#### ADVT_DOC Table
- `SKEY` (Primary Key, Auto-generated)
- `DOC_TYPE` (String, Not Null) - Document type (BOL)
- `DOC_NBR` (String, Not Null) - Document number
- `CONSIGNEE_NAME` (String, Not Null) - Consignee name (validated against predefined list)
- `PORT_OF_DESTINATION` (String, Not Null) - Port of destination

#### ADVT_DOC_ITEM Table
- `SKEY` (Primary Key, Auto-generated)
- `DOC_KEY` (Foreign Key) - References ADVT_DOC.SKEY
- `CARGO_DESCRIPTION` (String, Not Null) - Cargo description
- `QTY` (Number, Not Null) - Quantity
- `WEIGHT` (Number, Not Null) - Weight
- `VOLUME` (Number, Nullable) - Volume
- `MARKS` (String, Nullable) - Marks and numbers

## Getting Started

### Prerequisites
- Java 21 or higher
- Node.js 16 or higher
- Maven 3.6 or higher

### Backend Setup

1. Navigate to the project root directory
2. Run the Spring Boot application:
   ```bash
   mvn spring-boot:run
   ```
3. The backend will start on `http://localhost:8080`
4. H2 Console is available at `http://localhost:8080/h2-console`
   - JDBC URL: `jdbc:h2:mem:bol_db`
   - Username: `sa`
   - Password: `password`

### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the React development server:
   ```bash
   npm start
   ```
4. The frontend will start on `http://localhost:3000`

## Usage

### 1. BOL Listing Page
- View all BOL documents in a table format
- Select documents using checkboxes
- Use action buttons:
  - **Add BOL**: Create new BOL document (only when no documents selected)
  - **Edit BOL**: Edit selected document (only when one document selected)
  - **Delete BOL**: Delete selected documents (only when documents selected)
  - **BOL BizTask Config**: Configure BizTask settings for BOL documents
  - **BOL Item BizTask Config**: Configure BizTask settings for BOL items

### 2. Add/Edit BOL Page
- **Header Section**: Enter document number, select consignee, enter port of destination
- **Items Section**: Manage BOL items with Add/Edit/Delete functionality
- **Save**: Save the complete BOL document with all items

### 3. BOL Item Management
- Click "Add Item" to create new items
- Click "Edit" on existing items to modify them
- Click "Delete" to remove items
- All changes are saved when the main BOL document is saved

## Valid Consignee Names
The application validates consignee names against this predefined list:
- USLAX (Los Angeles)
- SGSIN (Singapore)
- CNHKG (Hong Kong)
- DEHAM (Hamburg)
- JPTYO (Tokyo)
- NLRTM (Rotterdam)
- USNYC (New York)
- AEJEA (Jebel Ali)
- CNBND (Bandar Abbas)

## API Endpoints

### BOL Documents
- `GET /api/bol` - Get all BOL documents
- `GET /api/bol/{id}` - Get BOL document by ID
- `POST /api/bol` - Create new BOL document
- `PUT /api/bol/{id}` - Update BOL document
- `DELETE /api/bol/{id}` - Delete BOL document
- `GET /api/bol/consignees` - Get valid consignee names

## Development Notes

### Backend
- Uses Spring Boot with JPA/Hibernate for data persistence
- H2 in-memory database for easy development
- RESTful API with CORS enabled for frontend communication
- Input validation using Bean Validation annotations

### Frontend
- React.js with functional components and hooks
- Axios for API communication
- CSS modules for component styling
- React Router for navigation
- Modal dialogs for item management

## Future Enhancements

1. **Authentication & Authorization**: Add user login and role-based access
2. **File Upload**: Support for document attachments
3. **Export/Import**: PDF generation and Excel import/export
4. **Audit Trail**: Track all changes to BOL documents
5. **Workflow Engine**: Implement actual BizTask workflow processing
6. **Real-time Updates**: WebSocket support for live updates
7. **Advanced Search**: Filter and search capabilities
8. **Bulk Operations**: Enhanced bulk editing and processing

## Troubleshooting

### Common Issues

1. **Port Conflicts**: If port 8080 or 3000 are in use, change them in the respective configuration files
2. **CORS Issues**: Ensure the backend CORS configuration allows the frontend URL
3. **Database Connection**: Check H2 console access if database issues occur
4. **Node Modules**: Delete `node_modules` and run `npm install` if frontend issues occur

### Logs
- Backend logs: Check console output when running `mvn spring-boot:run`
- Frontend logs: Check browser console and terminal output when running `npm start`
