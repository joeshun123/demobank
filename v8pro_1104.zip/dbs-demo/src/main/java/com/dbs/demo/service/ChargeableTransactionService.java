package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import jakarta.annotation.PreDestroy;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.IntStream;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ChargeableTransactionService {

  private static final int THREAD_POOL_SIZE = 50; // Number of threads to use
  private static final int BATCH_SIZE = 1000; // Number of records per batch
  private final ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE,new NamedThreadFactory("ChargeableTransactionThread"));

  public List<ChargeableTransactions> fetchChargeableTransactions(InvoiceRequestDTO invoiceRequestDTO) {
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(110,130); // fetch invoice type
    log.info("Step) 4. ChargeableTransactionService >> fetchInvoiceType() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    startTime = System.currentTimeMillis();
    t=DBSUtil.randomSleep(160,180); // fetch invoice criteria
    log.info("Step) 5. ChargeableTransactionService >> fetchInvoiceTypeCriteria() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    startTime = System.currentTimeMillis();
    // considered 1-5 criteria
    List<CompletableFuture<List<ChargeableTransactions>>> futures = IntStream.rangeClosed(1, getRandom(5))
        .mapToObj(id -> CompletableFuture.supplyAsync(() -> getTransaction(getRandom(1), getRandom(5000)))).toList();
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    List<ChargeableTransactions> list = allFutures.thenApply(v -> futures.stream()
        .flatMap(future -> future.join().stream()).distinct()
        .toList()
    ).join();
    log.info("Step) 6. ChargeableTransactionService >> fetchChargeableTransactions() ,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
    return list;
    //return futures.stream().flatMap(cf -> cf.join().stream()).distinct().toList();
  }

  private List<ChargeableTransactions> getTransaction(int startRange, int endrange) {
    DBSUtil.sleep(150);
    return IntStream.rangeClosed(startRange, endrange).mapToObj(id -> new ChargeableTransactions((long) id, "name" + id, getRandomString())).toList();
  }

  private int getRandom(int bound) {
    return new Random().nextInt(bound);
  }

  public static String getRandomString() {
    List<String> stringList = List.of("ServiceType1", "ServiceType2", "ServiceType3");
    Random random = new Random();
    // Select a random index from the list
    int randomIndex = random.nextInt(stringList.size());

    // Return the string at the random index
    return stringList.get(randomIndex);
  }

  public void lockTransactions(List<ChargeableTransactions> transactions) {
    long startTime = System.currentTimeMillis();
    List<List<ChargeableTransactions>> batches = partitionList(transactions, BATCH_SIZE);
    runTransactionInBatch(batches, batch -> CompletableFuture.runAsync(() -> insertBatch(batch), executorService));
    log.info("Step) 7. ChargeableTransactionService >> lockTransactions() ,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
    startTime = System.currentTimeMillis();
    updateTransactionStatus(transactions);
    int i = DBSUtil.randomSleep(50,60);
    log.info("Step) 8. ChargeableTransactionService >> lockTransactions() ,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
  }

  private void runTransactionInBatch(List<List<ChargeableTransactions>> batches,
      Function<? super List<ChargeableTransactions>, CompletableFuture<Void>> mapper) {
    List<CompletableFuture<Void>> futures = batches.stream().map(mapper).toList();
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
        .exceptionally(ex -> {
          ex.printStackTrace();
          return null;
        }).join();
  }


  /**
   * # Enable JDBC batching spring.jpa.properties.hibernate.jdbc.batch_size=1000
   * <p>
   * # Optimize insert statements for better batching performance spring.jpa.properties.hibernate.order_inserts=true
   * spring.jpa.properties.hibernate.order_updates=true
   * <p>
   * # Disable the second-level cache if not needed spring.jpa.properties.hibernate.cache.use_second_level_cache=false
   * spring.jpa.properties.hibernate.cache.use_query_cache=false
   * <p>
   * # Flush size control spring.jpa.properties.hibernate.jdbc.batch_versioned_data=true
   */
  private void insertBatch(List<ChargeableTransactions> batch) {
    // considered db & hibernate optimization step done. avg batch complete in 1.5 sec max of 1000 record
    for (int i = 0; i < batch.size(); i++) {
      //entityManager.persist(batch.get(i));
      // Flush and clear every BATCH_SIZE iterations to avoid memory issues
      if (i % BATCH_SIZE == 0 && i > 0) {
        DBSUtil.sleep(DBSUtil.getRandom(500, 1500));
        //entityManager.flush();
        //entityManager.clear();
      }
    }

    // Ensure all remaining entities are persisted
    //entityManager.flush();
    //entityManager.clear();

  }

  //@Transactional
  public void batchUpdate(List<ChargeableTransactions> transactions) {
    for (int i = 0; i < transactions.size(); i++) {
      // ChargeableTransactions transaction = entityManager.find(ChargeableTransactions.class, transactions.get(i).getId());

      // Update required fields
      //transaction.setStatus("CALCULATING");
      //transaction.setLastUpdated(new Date());

      // Flush and clear after every batch to avoid memory overhead
      if (i % BATCH_SIZE == 0 && i > 0) {
        DBSUtil.sleep(DBSUtil.getRandom(700, 2500));
        //entityManager.flush();
        //entityManager.clear();
      }
    }

    // Final flush and clear
    //entityManager.flush();
    //entityManager.clear();
  }

  private List<List<ChargeableTransactions>> partitionList(List<ChargeableTransactions> transactions, int batchSize) {
    int totalSize = transactions.size();
    int numBatches = (totalSize + batchSize - 1) / batchSize; // Ceiling division
    return java.util.stream.IntStream.range(0, numBatches)
        .mapToObj(i -> transactions.subList(i * batchSize, Math.min(totalSize, (i + 1) * batchSize)))
        .toList();
  }

  public void updateTransactionStatus(List<ChargeableTransactions> transactions) {
    List<List<ChargeableTransactions>> batches = partitionList(transactions, BATCH_SIZE);
    runTransactionInBatch(batches, batch -> CompletableFuture.runAsync(() -> batchUpdate(batch), executorService));
  }

  @PreDestroy
  public void shutdownExecutor() {
    executorService.shutdown();
  }
}