package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.dto.InvoiceResponseDTO;
import com.dbs.demo.dto.TerrifRule;
import com.dbs.demo.util.DBSUtil;
import com.dbs.demo.validator.InvoiceValidator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InvoiceService2 {

  @Autowired
  private InvoiceValidator invoiceValidator;

  @Autowired
  private ChargeableTransactionService chargeableTransactionService;

  @Autowired
  private CustomerService customerService;

  @Autowired
  private PaymentTermService paymentTermService;

  @Autowired
  private ServiceTypeService serviceTypeService;

  @Autowired
  private TariffService terrifRuleService;

  @Autowired
  private InterceptionService interceptionService;

  public InvoiceResponseDTO createInvoice(InvoiceRequestDTO requestDTO) {
    invoiceValidator.validateRequest(requestDTO);
    String customer = customerService.getCustomer(requestDTO.getCustomerId());
    String defaultPaymentTerms = paymentTermService.getDefaultPaymentTerm();
    List<ChargeableTransactions> transactions = chargeableTransactionService.fetchChargeableTransactions(requestDTO);
    if(transactions.isEmpty()){
      return new InvoiceResponseDTO("No Transaction Found",
          "Invoice Not generated");
    }
    System.out.println("Total transactions : "+transactions.size());
    chargeableTransactionService.lockTransactions(transactions);
    List<String> serviceTypes = serviceTypeService.getServiceTypes("criteria");
    List<TerrifRule> terrifRules = terrifRuleService.getTerrifRules(serviceTypes);
    terrifRuleService.deduceTerrifCodeAndUpdateTransaction(serviceTypes, terrifRules, transactions);
    List<TerrifRule> timeBaseTerrifRules = terrifRuleService.getTerrifRules(serviceTypes);
    terrifRuleService.deduceFreeQtyCodeAndUpdateTransaction(serviceTypes, timeBaseTerrifRules, transactions);
    if(checkInterceptionsIsActive()){
      interceptionService.intercept2(transactions);
    }
    //InterceptionService.intercept(transactions);
    if(!transactions.isEmpty()) {
      System.out.println("===============" + transactions.get(0));
    }
    return new InvoiceResponseDTO("invoice generated",
        "Invoice generated successfully (total chargeable transactions processed = " + transactions.size() + ")");
  }

  private boolean checkInterceptionsIsActive() {
    DBSUtil.randomSleep(10,50);
    return true;
  }


}
