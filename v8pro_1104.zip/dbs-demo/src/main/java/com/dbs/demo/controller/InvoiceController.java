package com.dbs.demo.controller;

import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.dto.InvoiceResponseDTO;
import com.dbs.demo.service.InvoiceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

@Slf4j
@RestController
public class InvoiceController {

  @Autowired
  private InvoiceService invoiceService;

/*  @Autowired
  private InterceptionService interceptionService;*/
  @GetMapping("/h")
  public void test() throws Exception {
    String traceId = (new Random()).nextLong(1000000, 9999999) + "";
    String url = "http://localhost:8081/api/intercept-call-code?tariffCode=A&callTime=" + System.currentTimeMillis() + "&traceId=" + traceId;
    HttpClient client = HttpClient.newHttpClient();
    HttpRequest request = HttpRequest.newBuilder(URI.create(url)).build();
    //HttpResponse response = client.send(request, HttpResponse.BodyHandlers.ofString());
    CompletableFuture<HttpResponse<String>> response = client.sendAsync(request, HttpResponse.BodyHandlers.ofString());
    response.thenAcceptAsync(r -> System.out.println(r.body()));
  }

  @PostMapping("/draft-invoice")
  public InvoiceResponseDTO draftInvoice(@RequestBody InvoiceRequestDTO invoiceRequestDTO) {
    long startTime = System.currentTimeMillis();
    InvoiceResponseDTO responseDTO = invoiceService.createInvoice(invoiceRequestDTO);
    log.info("Step) 1. InvoiceController >> draftInvoice duration :" + (System.currentTimeMillis() - startTime));
    return responseDTO;
  }

/*  @PostMapping("/interception")
  public InvoiceResponseDTO checkInterception(@RequestBody InvoiceRequestDTO invoiceRequestDTO) {
    long startTime = System.currentTimeMillis();
    interceptionService.intercept(new ChargeLine(1));
    log.info("Step) 1. InvoiceController >> checkInterception duration :" + (System.currentTimeMillis() - startTime));
    return new InvoiceResponseDTO("ok", "intercept success");
  }*/
}
