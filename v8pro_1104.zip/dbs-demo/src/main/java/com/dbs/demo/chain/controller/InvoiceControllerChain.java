package com.dbs.demo.chain.controller;

import com.dbs.demo.chain.service.InvoiceServiceChain;
import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.dto.InvoiceResponseDTO;
import com.dbs.demo.service.ChargeableTransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InvoiceControllerChain {

  @Autowired
  private InvoiceServiceChain invoiceService;

  @PostMapping("/draft-invoice-chain")
  public InvoiceResponseDTO draftInvoice(@RequestBody InvoiceRequestDTO invoiceRequestDTO) {
    return invoiceService.createInvoice(invoiceRequestDTO);
  }
}
