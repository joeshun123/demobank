package com.dbs.demo.dto;

public class ApiResponseDto<T> {

  private static final long serialVersionUID = 1L;
  private int status;
  private int code;
  private String message;
  private T content;
  private T data;

  public ApiResponseDto(int status, int code, String message, T content, T data) {
    super();
    this.status = status;
    this.code = code;
    this.message = message;
    this.content = content;
    this.data = data;
  }

  public ApiResponseDto(int status, int code, String message, T content) {
    super();
    this.status = status;
    this.code = code;
    this.message = message;
    this.content = content;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public int getCode() {
    return code;
  }

  public void setCode(int code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public T getContent() {
    return content;
  }

  public void setContent(T content) {
    this.content = content;
  }

  public T getData() {
    return data;
  }

  public void setData(T data) {
    this.data = data;
  }
}
