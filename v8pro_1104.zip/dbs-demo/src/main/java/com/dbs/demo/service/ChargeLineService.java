package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeLine;
import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ChargeLineService {
  private final ExecutorService executor = Executors.newFixedThreadPool(150,new NamedThreadFactory("ChargeLineServiceThread"));

  public List<ChargeLine> prepareChargeLines(List<ChargeableTransactions> transactions) {
    long startTime = System.currentTimeMillis();
    List<CompletableFuture<ChargeLine>> futures = transactions.stream()
        .map(tx -> CompletableFuture.supplyAsync(() -> convertIntoChargeLine(tx), executor))
        .toList();

    // Wait for all futures to complete and collect results
    List<ChargeLine> list = futures.stream()
        .map(CompletableFuture::join) // Block and get the result
        .toList();
    log.info("Step) 19. ChargeLineService >> prepareChargeLines() ,Sleep Time: NA , Duration: "+(System.currentTimeMillis() -startTime));
    return list;
  }

  public ChargeLine convertIntoChargeLine(ChargeableTransactions transaction) {
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(15, 20); // Simulate processing delay
    ChargeLine chargeLine = new ChargeLine(transaction.getId());
    log.info("ChargeLineService >> convertIntoChargeLine() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    return chargeLine;
  }
}
