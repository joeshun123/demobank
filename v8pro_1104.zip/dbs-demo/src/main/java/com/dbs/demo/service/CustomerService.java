package com.dbs.demo.service;

import com.dbs.demo.util.DBSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CustomerService {

  public String getCustomer(Long id){
    long startTime= System.currentTimeMillis();
    int t = DBSUtil.randomSleep(100,120); //sleep(10)
    log.info("Step) 3. CustomerService >> getCustomer() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis()-startTime));
    return "Customer";
  }
}
