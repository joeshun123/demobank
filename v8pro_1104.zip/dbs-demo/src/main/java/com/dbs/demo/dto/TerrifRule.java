package com.dbs.demo.dto;

public class TerrifRule {
  private String serviceType;
  private String terrifCode;

  public TerrifRule(String serviceType, String terrifCode) {
    this.serviceType = serviceType;
    this.terrifCode = terrifCode;
  }

  public String getServiceType() {
    return serviceType;
  }

  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }

  public String getTerrifCode() {
    return terrifCode;
  }

  public void setTerrifCode(String terrifCode) {
    this.terrifCode = terrifCode;
  }

  @Override public String toString() {
    return "TerrifRule{" +
        "serviceType='" + serviceType + '\'' +
        ", terrifCode='" + terrifCode + '\'' +
        '}';
  }
}
