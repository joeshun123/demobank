package com.dbs.demo.dto;

public class InvoiceRequestDTO {
  private Long customerId;
  // Add more fields like revenue center, invoice type, etc.

  public Long getCustomerId() {
    return customerId;
  }

  public void setCustomerId(Long customerId) {
    this.customerId = customerId;
  }
}
