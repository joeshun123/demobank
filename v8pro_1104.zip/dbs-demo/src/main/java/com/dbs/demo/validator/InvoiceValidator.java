package com.dbs.demo.validator;

import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.util.DBSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class InvoiceValidator {
  public void validateRequest(InvoiceRequestDTO request) {
    long startTime = System.currentTimeMillis();
    // Perform request validation, throw exception if invalid
    if (request.getCustomerId() == null || request.getCustomerId() <= 0) {
      throw new IllegalArgumentException("Invalid Customer ID");
    }
    int t = DBSUtil.randomSleep(10,15);
    log.info("Step) 2. InvoiceValidator >> validateRequest()  ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    // Additional validations can be added
  }
}
