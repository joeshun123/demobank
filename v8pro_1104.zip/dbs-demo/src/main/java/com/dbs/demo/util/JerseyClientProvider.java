package com.dbs.demo.util;

import com.sun.jersey.api.client.Client;
import jakarta.annotation.PreDestroy;
import java.util.concurrent.ExecutorService;
import org.springframework.stereotype.Component;

@Component
public class JerseyClientProvider {

  private final Client jerseyClient;
  private final ExecutorService executorService;

  public JerseyClientProvider() {
    this.jerseyClient = JerseyClientFactory.createJerseyClient();
    this.executorService = JerseyExecutorServiceFactory.createExecutorService();
  }

  public Client getClient(){
    return jerseyClient;
  }

  @PreDestroy
  public void done(){
    executorService.shutdownNow();
  }

/*  public CompletableFuture<String> fetchResourceAsync(String resourceUrl) {
    return CompletableFuture.supplyAsync(() -> {
      try {
        Invocation.Builder request = jerseyClient.target(resourceUrl).request(MediaType.APPLICATION_JSON);
        return request.get(String.class); // Fetching resource
      } catch (Exception e) {
        e.printStackTrace();
        return null;
      }
    }, executorService);
  }*/
}
