package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.dto.TerrifRule;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import jakarta.annotation.PreDestroy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TariffService {

  private final ExecutorService executor = Executors.newFixedThreadPool(400,new NamedThreadFactory("TariffService")); // Adjust the pool size as needed

  public List<TerrifRule> getTerrifRules(List<String> serviceTypes) {
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(10, 150);
    List<TerrifRule>  rules =  Arrays.asList(new TerrifRule("ServiceType1", "TerrifCode1"), new TerrifRule("ServiceType2", "TerrifCode2"),
        new TerrifRule("ServiceType3", "TerrifCode3"));
      log.info("Step) 11. TariffService >> getTerrifRules() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    return rules;
  }

  public List<TerrifRule> getTerrifRulesTimeBased(List<String> serviceTypes) {
    DBSUtil.sleep(DBSUtil.getRandom(10, 150));
    return Collections.emptyList();
  }

/*  public void deduceTerrifCodeAndUpdateTransaction(List<String> serviceTypes, List<TerrifRule> terrifRules,
      List<ChargeableTransactions> transactions) {
    List<CompletableFuture<Void>> futures = terrifRules.stream()
        .filter(t -> serviceTypes.contains(t.getServiceType()))
        .map(t -> CompletableFuture.runAsync(()->deduceTerrifCodeAndUpdateTransaction(t, transactions.stream()
            .filter(tx -> t.getServiceType().equals(tx.getServiceType()))
            .toList()),executor)).toList();
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
  }*/

  public void deduceTerrifCodeAndUpdateTransaction(List<String> serviceTypes, List<TerrifRule> terrifRules,
      List<ChargeableTransactions> transactions) {

    long overallStart = System.currentTimeMillis(); // Track overall start time

    List<CompletableFuture<Void>> futures = terrifRules.stream()
        .filter(rule -> serviceTypes.contains(rule.getServiceType())) // Filter matching service types
        .map(rule -> CompletableFuture.runAsync(() -> {
              long start = System.currentTimeMillis(); // Track individual task start time

              // Filter transactions for the current service type
              Stream<ChargeableTransactions> matchingTransactions = transactions.stream()
                  .filter(tx -> rule.getServiceType().equals(tx.getServiceType()));

              // Deduce tariff code and update transactions
              deduceTerrifCodeAndUpdateTransaction(rule, matchingTransactions.toList());

              long end = System.currentTimeMillis(); // Track individual task end time
              log.info("Processed rule for service type: " + rule.getServiceType() +
                  " in " + (end - start) + " ms");

            }, executor)
            .handle((result, ex) -> {
              if (ex != null) {
                log.info("Error processing rule for service type: " + rule.getServiceType() +
                    " - " + ex.getMessage());
              }
              return result; // Return the result, even if it's null in case of failure
            })).toList();

    // Wait for all futures to complete
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

    log.info("Step) 12. TariffService >> deduceTerrifCodeAndUpdateTransaction() ,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -overallStart));

  }

/*  public void deduceTerrifCodeAndUpdateTransaction(TerrifRule terrifRule, List<ChargeableTransactions> transactions) {
    System.out.println("Deducing terrif code for " + terrifRule + " transactions = " + transactions.size());
    List<CompletableFuture<Void>> futures = transactions.stream()
        .map(t -> CompletableFuture.runAsync(() -> deduceTerrifCodeAndUpdateTransaction(terrifRule, t), executor))
        .toList();
    CompletableFuture<Void> allOf = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    allOf.join(); // Wait for all tasks to complete
  }

  public void deduceTerrifCodeAndUpdateTransaction(TerrifRule terrifRule, ChargeableTransactions transaction) {
    DBSUtil.randomSleep(150, 200);
    transaction.setTerrifCode(terrifRule.getTerrifCode());
  }*/

  public void deduceTerrifCodeAndUpdateTransaction(TerrifRule terrifRule, List<ChargeableTransactions> transactions) {
    long startTime = System.currentTimeMillis();
      log.info("Deducing tariff code for " + terrifRule + " transactions = " + transactions.size());
    int time = DBSUtil.randomSleep(150, 500);
    transactions.forEach(t -> t.setTerrifCode(terrifRule.getTerrifCode()));
      log.info("TariffService >> deduceTerrifCodeAndUpdateTransaction()  ,Sleep Time: "+time+" , Duration: "+(System.currentTimeMillis() -startTime));
  }

  @PreDestroy
  public void shutdownExecutor() {
    executor.shutdown();
  }

/*  public void deduceFreeQtyCodeAndUpdateTransaction(List<String> serviceTypes, List<TerrifRule> timeBaseTerrifRules, List<ChargeableTransactions> transactions) {
      List<CompletableFuture<Void>> futures = timeBaseTerrifRules.stream()
          .filter(t -> serviceTypes.contains(t.getServiceType()))
          .map(t -> CompletableFuture.runAsync(()->deduceTerrifCodeAndUpdateTransaction(t, transactions.stream()
              .filter(tx -> t.getServiceType().equals(tx.getServiceType()))
              .toList()),executor)).toList();
      CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
  }*/

  public void deduceFreeQtyCodeAndUpdateTransaction(List<String> serviceTypes, List<TerrifRule> timeBaseTerrifRules,
      List<ChargeableTransactions> transactions) {

    long overallStart = System.currentTimeMillis(); // Track overall start time

    List<CompletableFuture<Void>> futures = timeBaseTerrifRules.stream()
        .filter(rule -> serviceTypes.contains(rule.getServiceType())) // Filter matching service types
        .map(rule -> CompletableFuture.runAsync(() -> {
              long start = System.currentTimeMillis(); // Track individual task start time

              // Filter transactions for the current service type (avoid intermediate list creation)
              Stream<ChargeableTransactions> matchingTransactions = transactions.stream()
                  .filter(tx -> rule.getServiceType().equals(tx.getServiceType()));

              // Deduce tariff code and update transactions
              deduceTerrifCodeAndUpdateTransaction(rule, matchingTransactions.toList());

              long end = System.currentTimeMillis(); // Track individual task end time
              log.info("Processed FreeQty for service type: " + rule.getServiceType() +
                  " in " + (end - start) + " ms");
            }, executor)
            .handle((result, ex) -> {
              if (ex != null) {
                System.err.println("Error processing FreeQty for service type: " + rule.getServiceType() +
                    " - " + ex.getMessage());
              }
              return result; // Return result (even null if failure)
            })).toList();

    // Wait for all futures to complete
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

      log.info("Step) 13. TariffService >> deduceFreeQtyCodeAndUpdateTransaction() ,Sleep Time: NA , Duration: "+(System.currentTimeMillis() -overallStart));
  }

    public String getTariffRateForContract(){
        long startTime = System.currentTimeMillis();
        int t =DBSUtil.randomSleep(120,140);
        log.info("Step) 16. TariffService >> getTariffRateForContract() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
        return "default base tariff rate";
    }
    public String getFreeQtyForContract(){
        long startTime = System.currentTimeMillis();
        int t =DBSUtil.randomSleep(120,140);
        log.info("Step) 17. TariffService >> getFreeForContract() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
        return "default base free qty";
    }

    public String updateCharteUptoTime(){
        long startTime = System.currentTimeMillis();
        int t =DBSUtil.randomSleep(120,140);
        log.info("Step) 0. TariffService >> updateCharteUptoTime() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
        return "default base free qty";
    }

    public String updateTariffRateAndFreeQtyToTransaction(){
        long startTime = System.currentTimeMillis();
        int t =DBSUtil.randomSleep(120,140);
        log.info("Step) 0. TariffService >> updateTariffRateAndFreeQtyToTransaction() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
        return "default base free qty";
    }
}
