package com.dbs.demo.dto;

public class ChargeLine {
  private long id;

  public ChargeLine(long id) {
    this.id = id;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }
}
