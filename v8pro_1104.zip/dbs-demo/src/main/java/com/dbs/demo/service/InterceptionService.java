package com.dbs.demo.service;


import com.dbs.demo.dto.ChargeLine;
import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import com.dbs.demo.util.JerseyClientProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import jakarta.annotation.Nonnull;
import jakarta.annotation.PreDestroy;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.ws.rs.core.Cookie;

import jakarta.ws.rs.client.Invocation;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
public class InterceptionService {

  @Autowired
  private JerseyClientProvider jerseyClientProvider;

  @Autowired
  private RestTemplate restTemplate;

  @Autowired
  private ObjectMapper objectMapper;

  private final ExecutorService executor = Executors.newFixedThreadPool(400,new NamedThreadFactory("I"));
  private final ExecutorService executor2 = Executors.newFixedThreadPool(400,new NamedThreadFactory("B"));

/*  public List<Map<String, Object>> intercept(List<ChargeableTransactions> transactions) {
    long start= System.currentTimeMillis();
    System.out.println("Interception start");
    List<CompletableFuture<Map<String, Object>>> futures = transactions.stream().map(t -> CompletableFuture.supplyAsync(() -> intercept(t),executor)).toList();
    List<Map<String, Object>> list =futures.stream().map(CompletableFuture::join).toList();
    System.out.println("Interception finish in "+ (System.currentTimeMillis()-start)+" ms");
    return list;
  }*/

  public List<Map<String, Object>> intercept(List<ChargeableTransactions> transactions) {
    long start = System.currentTimeMillis();
    log.info("Interception start");
    // Submit all tasks asynchronously
    List<CompletableFuture<Map<String, Object>>> futures = transactions.stream()
            .map(t -> CompletableFuture.supplyAsync(() -> intercept(t), executor)
                    .handle((result, ex) -> { // Handle any exception
                      if (ex != null) {
                        log.error("Error in transaction: " + t.getId() + ", " + ex.getMessage(), ex);
                        return new HashMap<String, Object>(); // Return an empty result or error result
                      }
                      return result;
                    })
            )
            .toList();
    // Wait for all futures to complete
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    // When all are done, collect results
    List<Map<String, Object>> results = allFutures.thenApplyAsync(v -> futures.stream().map(CompletableFuture::join).toList(), executor2)
            .join(); // Wait for the combined future to complete
    log.info("Step) 18. InterceptionService >> intercept() ,Sleep Time: NA , Duration: " + (System.currentTimeMillis() - start));
    return results;
  }

  private HttpRequest prepareHttpRequest(ChargeableTransactions transaction) {
    long traceId = (new Random()).nextLong(10000000, 99999999);
    long startTime = System.currentTimeMillis();
    String url = "http://localhost:8081/api/intercept-call-code?tariffCode=" + transaction.getTerrifCode() + "&traceId=T" + traceId + "&callTime=" + startTime;
    log.info("TraceId: {}, Building request", traceId);
    return HttpRequest.newBuilder(URI.create(url)).build();
  }
  private Map<String, Object> parseResponse(final String response) {
    log.info("Parsing result");
    return Collections.emptyMap();
  }
  public List<Map<String, Object>> intercept2(List<ChargeableTransactions> transactions) {
    List<List<ChargeableTransactions>> batches = this.partitionList(transactions, 200);
    List<Map<String, Object>> results = new ArrayList<>();
    batches.stream().forEach(b->results.addAll(intercept3(b)));
    return results;
  }
  public List<Map<String, Object>> intercept3(List<ChargeableTransactions> transactions) {
    long start = System.currentTimeMillis();
    log.info("Interception start");
    HttpClient client = HttpClient.newBuilder().executor(executor).build();
    List<CompletableFuture<Map<String, Object>>> futures = transactions.stream()
            .map(t -> CompletableFuture.supplyAsync(() -> prepareHttpRequest(t), executor)
                    .thenComposeAsync(r->client.sendAsync(r, HttpResponse.BodyHandlers.ofString()).thenApplyAsync(HttpResponse::body), executor2)
                    .thenApplyAsync(this::parseResponse, executor2)
                    .handle((result, ex) -> { // Handle any exception
                      if (ex != null) {
                        log.error("Error in transaction: " + t.getId() + ", " + ex.getMessage(), ex);
                        return new HashMap<String, Object>(); // Return an empty result or error result
                      }
                      return result;
                    })
            )
            .toList();
    // Wait for all futures to complete
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    // When all are done, collect results
    List<Map<String, Object>> results = allFutures.thenApplyAsync(v -> futures.stream().map(CompletableFuture::join).toList(), executor2)
            .join(); // Wait for the combined future to complete
    log.info("Step) 18. InterceptionService >> intercept() ,Sleep Time: NA , Duration: " + (System.currentTimeMillis() - start));
    return results;
  }

/*  public List<Map<String, Object>> intercept(List<ChargeableTransactions> transactions) {
    long start = System.currentTimeMillis();
    log.info("Interception start");
    final int batchSize = 500;
    // Partition the transactions list into batches
    List<List<ChargeableTransactions>> batches = partitionList(transactions, batchSize);

    List<CompletableFuture<Map<String, Object>>> futures = new ArrayList<>();

    for (List<ChargeableTransactions> batch : batches) {
      // Submit a batch of transactions asynchronously
      List<CompletableFuture<Map<String, Object>>> batchFutures = batch.stream()
          .map(t -> CompletableFuture.supplyAsync(() -> intercept(t), executor)
              .handle((result, ex) -> {
                if (ex != null) {
                  log.error("Error in transaction: " + t.getId() + ", " + ex.getMessage(), ex);
                  return new HashMap<String, Object>(); // Handle exception with an empty map or error result
                }
                return result;
              })
          )
          .toList();

      // Add the batch futures to the overall futures list
      futures.addAll(batchFutures);

      // Wait for a short delay (20ms) before submitting the next batch
      //DBSUtil.sleep(1000);
    }

    // Wait for all futures to complete
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));

    // Collect all results after all batches are done
    List<Map<String, Object>> results = allFutures.thenApply(v -> futures.stream()
        .map(CompletableFuture::join)
        .toList()
    ).join();

    log.info("Step) 18. InterceptionService >> interceptInBatches() ,Sleep Time: " + 20 + "ms , Duration: " + (System.currentTimeMillis()
        - start) + "ms");
    return results;
  }*/


  private <T> List<List<T>> partitionList(List<T> list, int batchSize) {
    List<List<T>> partitions = new ArrayList<>();
    for (int i = 0; i < list.size(); i += batchSize) {
      partitions.add(list.subList(i, Math.min(i + batchSize, list.size())));
    }
    return partitions;
  }

  public Map<String, Object> intercept(ChargeableTransactions transactions) {
    //int t = DBSUtil.randomSleep(100, 300);
    long traceId = (new Random()).nextLong(10000000, 99999999);
    long startTime = System.currentTimeMillis();
    /*String response = restTemplate.getForEntity("http://localhost:8081/api/intercept-call-code?tariffCode=" + transactions.getTerrifCode(),
        String.class).getBody();*/
    String response = get("http://localhost:8081/api/intercept-call-code?tariffCode=" + transactions.getTerrifCode() + "&traceId=T" + traceId + "&callTime=" + startTime);
    //String response = callActualIntercept();
    log.info("interception done for transaction :" + transactions.getId() + ",  Duration: " + (System.currentTimeMillis() - startTime) + " Response :"
            + response);
    return Collections.emptyMap();
  }

  public Map<String, Object> intercept(ChargeLine transactions) {
    //int t = DBSUtil.randomSleep(100, 300);
    long traceId = (new Random()).nextLong(10000000, 99999999);
    long startTime = System.currentTimeMillis();
    String response = get("http://localhost:8081/api/intercept-call-code?tariffCode=" + transactions.getId() + "&traceId=C" + traceId + "&callTime=" + startTime);
    /*String response = restTemplate.getForEntity("http://localhost:8081/api/intercept-call-code?tariffCode=" + transactions.getId(), String.class)
        .getBody();*/
    //String response = callActualIntercept();
    log.info("Charge Line interception done for transaction :" + transactions.getId() + ",  Duration: " + (System.currentTimeMillis() - startTime)
            + " Response :" + response);
    return Collections.emptyMap();
  }

  @PreDestroy
  public void shutdownExecutor() {
    executor.shutdown();
  }

  public List<Map<String, Object>> interceptChargeLines(List<ChargeLine> lines) {
    long start = System.currentTimeMillis();
    log.info("Interception start");
    // Submit all tasks asynchronously
    List<CompletableFuture<Map<String, Object>>> futures = lines.stream()
            .map(t -> CompletableFuture.supplyAsync(() -> intercept(t), executor)
                    .handle((result, ex) -> { // Handle any exception
                      if (ex != null) {
                        log.error("Error in transaction: " + t.getId() + ", " + ex.getMessage(), ex);
                        return new HashMap<String, Object>(); // Return an empty result or error result
                      }
                      return result;
                    })
            )
            .toList();
    // Wait for all futures to complete
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
    // When all are done, collect results
    List<Map<String, Object>> results = allFutures.thenApplyAsync(v -> futures.stream().map(CompletableFuture::join).toList(), executor)
            .join(); // Wait for the combined future to complete
    log.info("Step) 20. InterceptionService >> interceptChargeLines() ,Sleep Time: NA , Duration: " + (System.currentTimeMillis() - start));
    return results;
  }

  public void intercept() {
    long start = System.currentTimeMillis();
    int t = DBSUtil.randomSleep(100, 300);
    log.info("Step) 26. InterceptionService >> intercept() ,Sleep Time: " + t + " , Duration: " + (System.currentTimeMillis() - start));
  }

  public @Nonnull String get(@Nonnull final String fullUrl) {
    String response = null;
    try {
      Client client = jerseyClientProvider.getClient();

      //Invocation.Builder request = client.target(fullUrl).request(MediaType.APPLICATION_JSON);
      //return request.get(String.class);

      WebResource builder = client.resource(fullUrl);
      //Invocation.Builder webBuilder = createBuilderWithHeaders(new HashMap<>(), builder);
      return builder.get(String.class);
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      throw e;
    } finally {
    }
  }

/*  public @Nonnull String post(@Nonnull final String fullUrl, @Nonnull final String requestBody, @Nonnull final Map<String, String> headers) {
    try {
      // Get the Jersey client from your provider
      Client client = jerseyClientProvider.getClient();

      // Set up the WebTarget (the URL)
      WebTarget webTarget = client.target(fullUrl);

      // Create the request builder and add headers
      Invocation.Builder request = webTarget.request(MediaType.APPLICATION_JSON);
      for (Map.Entry<String, String> header : headers.entrySet()) {
        request.header(header.getKey(), header.getValue());
      }

      // Post request with body
      Response response = request.post(Entity.entity(requestBody, MediaType.APPLICATION_JSON));

      // Handle the response, read the entity as a string
      if (response.getStatus() == Response.Status.OK.getStatusCode()) {
        return response.readEntity(String.class);
      } else {
        throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    }
  }*/

  public @Nonnull String post(@Nonnull final String fullUrl, @Nonnull final String requestBody, @Nonnull final Map<String, String> headers) {
    try {
      // Get the Jersey client from your provider
      Client client = jerseyClientProvider.getClient();

      // Set up the WebTarget (the URL)
      WebResource webResource = client.resource(fullUrl);

      // Create the request builder and add headers
      WebResource.Builder builder = null;
      for (Map.Entry<String, String> header : headers.entrySet()) {
        if(builder == null) {
          builder = webResource.header(header.getKey(), header.getValue());
        }else {
          builder = builder.header(header.getKey(), header.getValue());
        }
      }

     /* if (headers.containsKey("addTokenInCookie") && headers.containsKey("z.sessionToken")) {
        builder = webResource.cookie(new Cookie("token", headers.get("z.sessionToken").toString()));
      }*/

      ClientResponse response = (ClientResponse)((WebResource.Builder)builder.type("application/json")).post(ClientResponse.class, requestBody);

      // Handle the response, read the entity as a string
      return response.getEntity(String.class);
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    }
  }


/*  protected @Nonnull Invocation.Builder createBuilderWithHeaders(@Nonnull final Map<String, Object> headers,
      @Nonnull final Invocation.Builder builder) {
    Invocation.Builder newBuilder = builder;
    // set header parameter into rest request
    if (headers != null && headers.size() > 0) {
      for (Map.Entry<String, Object> headerEntry : headers.entrySet()) {
        if (builder != null) {
          newBuilder = newBuilder.header(headerEntry.getKey(), headerEntry.getValue() != null ? headerEntry.getValue().toString() : null);
        } else {
          newBuilder = newBuilder.header(headerEntry.getKey(), headerEntry.getValue() != null ? headerEntry.getValue().toString() : null);
        }
      }
      if (headers.containsKey("addTokenInCookie") && headers.containsKey("z.sessionToken")) {
        newBuilder = newBuilder.cookie(new Cookie("token", headers.get("z.sessionToken").toString()));
      }
    } else {
      newBuilder = newBuilder.acceptEncoding(APPLICATION_JSON);
    }
    return newBuilder;
  }*/

  private String callActualIntercept() {
    Map<String, String> headerMap = new HashMap<>();
    headerMap.put("z.sessionToken", "430f65d1-918a-4ac7-a2a6-cc06f4cab6ee");
    headerMap.put("z.currentDataScope", "CZ1");
    headerMap.put("Content-Type", "application/json");
    return post("http://srvwo4dev.odcdpw.ic:12406/zodiac/invoke/api/v1/service/intercept", prepareInterceptRequest(), headerMap);
  }

  private String callActualIntercept1() {
    Map<String, String> headerMap = new HashMap<>();
    headerMap.put("z.sessionToken", "430f65d1-918a-4ac7-a2a6-cc06f4cab6ee");
    headerMap.put("z.currentDataScope", "CZ1");
    headerMap.put("Content-Type", "application/json");

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON); // Set Content-Type to JSON
    headers.set("z.sessionToken", "430f65d1-918a-4ac7-a2a6-cc06f4cab6ee"); // Add Authorization header
    headers.set("z.currentDataScope", "CZ1"); // Add other custom headers if needed

    // Create request body (as an example, a JSON payload)
    String requestBody = prepareInterceptRequest();

    // Create HttpEntity with the headers and body
    HttpEntity<String> request = new HttpEntity<>(requestBody, headers);
    return restTemplate.postForEntity("http://srvwo4dev.odcdpw.ic:12406/zodiac/invoke/api/v1/service/intercept", request,String.class).getBody();
  }

  private String prepareInterceptRequest() {
    String json = "{\n" +
            "  \"eventContext\": {\n" +
            "    \"id\": null,\n" +
            "    \"traceId\": \"d7b8802673e3c605\",\n" +
            "    \"eventTypeCode\": \"INC_CHARGEABLE_TX_POST_CALCULATE\",\n" +
            "    \"siteCode\": \"CZ1\",\n" +
            "    \"userId\": \"cz1dp05\",\n" +
            "    \"eventTime\": \"2024-09-21T00:00:00\",\n" +
            "    \"isBillable\": null\n" +
            "  },\n" +
            "  \"data\": {\n" +
            "    \"original\": {\n" +
            "      \"eventTypeCode\": \"UD_BILL_VSL_RSTW\",\n" +
            "      \"serviceDate\": \"2024-09-13T10:38:32+08:00\",\n" +
            "      \"tariffRuleVersion\": \"1\",\n" +
            "      \"tariffCode\": \"FBT012\",\n" +
            "      \"totalQty\": \"3\",\n" +
            "      \"tariffRuleName\": \"STR012\",\n" +
            "      \"calculateStartTime\": \"2024-09-13T10:38:00+08:00\",\n" +
            "      \"freeQtyRuleVersion\": \"2\",\n" +
            "      \"chargeableTxKey\": \"1000029683310\",\n" +
            "      \"freeQtyCode\": \"FQC025\",\n" +
            "      \"billToCode\": \"MSK\",\n" +
            "      \"isBillable\": \"Y\",\n" +
            "      \"chargeableTxObject\": \"DbstChargeableUnit\",\n" +
            "      \"exchangeRateRefDate\": \"2024-08-30T21:00:00+08:00\",\n" +
            "      \"revenueCentreCode\": \"CZ1\",\n" +
            "      \"totalQty2\": \"1\",\n" +
            "      \"eventTime\": \"2024-08-15T08:00:00+08:00\",\n" +
            "      \"DbstChargeableUnit\": {\n" +
            "        \"isOog\": \"No\",\n" +
            "        \"firstTemperatureRead\": \"0\",\n" +
            "        \"pod\": \"GRSKG\",\n" +
            "        \"restowReason\": \"RESTOW B\",\n" +
            "        \"grossWeightInKg\": \"40200\",\n" +
            "        \"craneCode\": \"Q5\",\n" +
            "        \"pol\": \"CYLMS\",\n" +
            "        \"operator\": \"MSK\",\n" +
            "        \"shippingStatus\": \"RS\",\n" +
            "        \"eqpHistSeq\": \"0\",\n" +
            "        \"storageModeCode\": \"DR\",\n" +
            "        \"key\": \"1000029683311\",\n" +
            "        \"eqpNbr\": \"IMPT8020221\",\n" +
            "        \"eqpSize\": \"20\",\n" +
            "        \"owner\": \"MSK\",\n" +
            "        \"loadStatus\": \"F\",\n" +
            "        \"eqpType\": \"DR\",\n" +
            "        \"isLaden\": \"Yes\",\n" +
            "        \"outVisit\": \"MVMSK0533\",\n" +
            "        \"isHaz\": \"No\",\n" +
            "        \"shipmentMode\": \"RS\",\n" +
            "        \"isManualTwistLock\": \"No\",\n" +
            "        \"eqpCycleId\": \"0\",\n" +
            "        \"craneTypeCode\": \"MOBILE_SC\",\n" +
            "        \"isActiveReefer\": \"No\",\n" +
            "        \"isPowerVariance\": \"No\",\n" +
            "        \"inVisit\": \"MVMSK0533\",\n" +
            "        \"eqpHeight\": \"9.5\",\n" +
            "        \"isUcCargo\": \"No\",\n" +
            "        \"isExtraSpaceRequired\": \"No\"\n" +
            "      },\n" +
            "      \"freeQtyRuleName\": \"ST012\",\n" +
            "      \"serviceTypeName\": \"Storage-12\",\n" +
            "      \"remarks\": \"From Pre Interception\",\n" +
            "      \"key\": \"1000029683311\",\n" +
            "      \"status\": \"READY FOR BILLING\"\n" +
            "    },\n" +
            "    \"change\": {\n" +
            "      \"chargeLineInfos\": {\n" +
            "        \"added\": [\n" +
            "          {\n" +
            "            \"value\": \"zodiac.zdc.dto.ChargeLineDto@6c250ae5\"\n" +
            "          }\n" +
            "        ],\n" +
            "        \"key\": [\n" +
            "          \"1000029683310\"\n" +
            "        ]\n" +
            "      }\n" +
            "    },\n" +
            "    \"property\": {\n" +
            "      \"userInputParameters\": {\n" +
            "        \"invoiceType\": \"Import Delivery\",\n" +
            "        \"pickupDate\": \"2024-09-15T23:00:00+08:00\",\n" +
            "        \"billToCode\": \"MSK\",\n" +
            "        \"eqpNbr\": \"IMPT8020221\"\n" +
            "      }\n" +
            "    },\n" +
            "    \"target\": null\n" +
            "  }\n" +
            "}";

    return json;
    /*try {
      // Convert JSON string to Map
      return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException("error while preparing intercept request");
    }*/
  }
}
