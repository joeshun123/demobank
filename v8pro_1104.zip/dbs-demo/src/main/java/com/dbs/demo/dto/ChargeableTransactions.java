package com.dbs.demo.dto;


import java.util.Objects;

public class ChargeableTransactions {

  private Long id;
  private String name;
  private String serviceType;
  private String terrifCode;

  public ChargeableTransactions() {
  }

  public ChargeableTransactions(Long id, String name, String serviceType) {
    this.id = id;
    this.name = name;
    this.serviceType = serviceType;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChargeableTransactions that = (ChargeableTransactions) o;
    return Objects.equals(id, that.id);
  }

  @Override public int hashCode() {
    return Objects.hashCode(id);
  }

  public String getServiceType() {
    return serviceType;
  }

  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }

  public String getTerrifCode() {
    return terrifCode;
  }

  public void setTerrifCode(String terrifCode) {
    this.terrifCode = terrifCode;
  }

  @Override public String toString() {
    return "ChargeableTransactions{" +
        "id=" + id +
        ", name='" + name + '\'' +
        ", serviceType='" + serviceType + '\'' +
        ", terrifCode='" + terrifCode + '\'' +
        '}';
  }
}
