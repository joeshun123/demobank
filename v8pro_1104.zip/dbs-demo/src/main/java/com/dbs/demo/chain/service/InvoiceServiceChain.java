package com.dbs.demo.chain.service;

import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.dto.InvoiceResponseDTO;
import com.dbs.demo.dto.TerrifRule;
import com.dbs.demo.service.*;
import com.dbs.demo.service.TariffService;
import com.dbs.demo.util.DBSUtil;
import com.dbs.demo.validator.InvoiceValidator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InvoiceServiceChain {

  @Autowired
  private InvoiceValidator invoiceValidator;

  @Autowired
  private ChargeableTransactionService chargeableTransactionService;

  @Autowired
  private CustomerService customerService;

  @Autowired
  private PaymentTermService paymentTermService;

  @Autowired
  private ServiceTypeService serviceTypeService;

  @Autowired
  private TariffService terrifRuleService;

  @Autowired
  private com.dbs.demo.service.InterceptionService InterceptionService;

  public InvoiceResponseDTO createInvoice(InvoiceRequestDTO requestDTO) {
    invoiceValidator.validateRequest(requestDTO);
    String customer = customerService.getCustomer(requestDTO.getCustomerId());
    String defaultPaymentTerms = paymentTermService.getDefaultPaymentTerm();
    List<ChargeableTransactions> transactions = chargeableTransactionService.fetchChargeableTransactions(requestDTO);
    if (transactions.isEmpty()) {
      return new InvoiceResponseDTO("No Transaction Found",
          "Invoice Not generated");
    }
    System.out.println("Total transactions : " + transactions.size());
    chargeableTransactionService.lockTransactions(transactions);
    List<String> serviceTypes = serviceTypeService.getServiceTypes("criteria");
    List<TerrifRule> terrifRules = terrifRuleService.getTerrifRules(serviceTypes);
    Map<String,TerrifRule> terrifRuleMap = terrifRules.stream().collect(Collectors.toMap(TerrifRule::getServiceType,Function.identity()));
    Map<String,List<ChargeableTransactions>> tansactionMap = transactions.stream().collect(Collectors.groupingBy(ChargeableTransactions::getServiceType, Collectors.toList()));
    terrifRuleMap.forEach((key,value)->{
      List<CompletableFuture<ChargeableTransactions>> futures = deduceTerrifCode(value,tansactionMap.get(key));
    });


    return new InvoiceResponseDTO("invoice generated",
        "Invoice generated successfully (total chargeable transactions processed = " + transactions.size() + ")");
  }

  public ChargeableTransactions deduceTerrifCode(TerrifRule terrifRule, ChargeableTransactions transaction){
    DBSUtil.randomSleep(150,500);
    transaction.setTerrifCode(terrifRule.getTerrifCode());
    return transaction;
  }

  public ChargeableTransactions deduceFreeQty(TerrifRule terrifRule, ChargeableTransactions transaction){
    DBSUtil.randomSleep(150,500);
    transaction.setTerrifCode(terrifRule.getTerrifCode());
    return transaction;
  }

  public List<CompletableFuture<ChargeableTransactions>> deduceTerrifCode(TerrifRule terrifRule, List<ChargeableTransactions> transactions){
    return transactions.stream().map(t->CompletableFuture.supplyAsync(()->deduceTerrifCode(terrifRule,t))).toList();
  }
}
