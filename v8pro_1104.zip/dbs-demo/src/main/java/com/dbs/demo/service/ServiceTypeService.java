package com.dbs.demo.service;

import com.dbs.demo.util.DBSUtil;
import java.util.Arrays;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ServiceTypeService {

  public List<String> getServiceTypes(String criteria) {
    long startTime = System.currentTimeMillis();
    int t = DBSUtil.randomSleep(10, 150);
    List<String> list= Arrays.asList("ServiceType1", "ServiceType2", "ServiceType3");
    log.info("Step) 9. ServiceTypeService >> getServiceTypes() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    return list;
  }
}
