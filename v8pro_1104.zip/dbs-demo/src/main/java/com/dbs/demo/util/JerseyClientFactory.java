package com.dbs.demo.util;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandler;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.client.apache.ApacheHttpClient;
import com.sun.jersey.client.apache.ApacheHttpClientHandler;
import com.sun.jersey.client.apache.config.DefaultApacheHttpClientConfig;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.httpclient.protocol.Protocol;



public class JerseyClientFactory {

/*  public static Client createJerseyClient() {
    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
    connectionManager.setMaxTotal(400);
    connectionManager.setDefaultMaxPerRoute(200);
    CloseableHttpClient httpClient = HttpClients.custom()
        .setConnectionManager(connectionManager)
        .setConnectionManagerShared(true)
        .setConnectionReuseStrategy((httpRequest, httpResponse, httpContext) -> true)
        .build();

    ClientConfig clientConfig = new ClientConfig();
    clientConfig.connectorProvider(new ApacheConnectorProvider());
    clientConfig.property("jersey.config.client.connectTimeout", 5000);  // 2 seconds
    clientConfig.property("jersey.config.client.readTimeout", 10000);
    // Configure timeouts and other settings
    return JerseyClientBuilder.newBuilder()
        .withConfig(clientConfig)
        .property("jersey.config.client.httpClient", httpClient)// 5 seconds
        .executorService(JerseyExecutorServiceFactory.createExecutorService())
        .build();
  }*/

/*  public static Client createJerseyClient() {
    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
    connectionManager.setMaxTotal(1000); // Max connections across all routes
    connectionManager.setDefaultMaxPerRoute(200); // Max connections per route

    RequestConfig requestConfig = RequestConfig.custom()
        .setConnectTimeout(5000, TimeUnit.MILLISECONDS)  // 5 seconds connection timeout
        .setConnectionRequestTimeout(5000,TimeUnit.MILLISECONDS)   // 5 seconds socket timeout
        .build();

    CloseableHttpClient httpClient = HttpClients.custom()
        .setConnectionManager(connectionManager)
        .setConnectionReuseStrategy(new DefaultConnectionReuseStrategy()) // Reuse connections efficiently
        .setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy()) // Keep connections alive
        .setDefaultRequestConfig(requestConfig)
        .build();

    ClientConfig clientConfig = new ClientConfig();
    clientConfig.connectorProvider(new ApacheConnectorProvider());

    // Set timeouts
    clientConfig.property(ClientProperties.CONNECT_TIMEOUT, 2000); // 2 seconds
    clientConfig.property(ClientProperties.READ_TIMEOUT, 3000);    // 3 seconds

    return JerseyClientBuilder.newBuilder()
        .withConfig(clientConfig)
        .property("jersey.config.client.httpClient", httpClient)
        .executorService(Executors.newFixedThreadPool(24)) // Tune thread pool size
        .build();
  }*/

/*  public static Client createJerseyClient() {
    System.out.println("createJerseyClient called");
    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
    connectionManager.setMaxTotal(1000); // Maximum total connections
    connectionManager.setDefaultMaxPerRoute(500); // Maximum connections per rout

    SocketConfig socketConfig = SocketConfig.custom()
        .setSoTimeout(5000,TimeUnit.MILLISECONDS) // Set socket timeout (5 seconds)
        .setSoKeepAlive(true) // Keep connections alive
        .build();
    ConnectionConfig connectionConfig = ConnectionConfig.custom()
        .setSocketTimeout(Timeout.ofMilliseconds(5000))  // 5 second socket timeout
        .setTimeToLive(TimeValue.ofSeconds(60)) // 60 seconds for connection TTL
        .build();

    connectionManager.setDefaultSocketConfig(socketConfig);
    connectionManager.setDefaultConnectionConfig(connectionConfig);

    RequestConfig requestConfig = RequestConfig.custom()
        .setResponseTimeout(Timeout.ofMilliseconds(5000)) // 5 second read timeout
        .setConnectionRequestTimeout(Timeout.ofMilliseconds(3000)) // Timeout when requesting connection from pool
        .build();
    CloseableHttpClient httpClient = HttpClients.custom()
        .setConnectionManager(connectionManager)
        .setConnectionReuseStrategy(DefaultConnectionReuseStrategy.INSTANCE) // Reuse connections
        .setDefaultRequestConfig(requestConfig)
        .build();
    ClientConfig clientConfig = new ClientConfig();
    clientConfig.connectorProvider(new ApacheConnectorProvider());
    clientConfig.property("jersey.config.client.connectTimeout", 5000); // Connection timeout (5 seconds)
    clientConfig.property("jersey.config.client.readTimeout", 5000); // Read timeout (5 seconds)
    clientConfig.property("jersey.config.client.disableJndi", true);  // Disable JNDI
    clientConfig.property("jersey.config.client.disableHK2", true);
    clientConfig.property("jersey.config.client.backgroundScheduler.threadPoolSize", 150);

    //clientConfig.executorService(JerseyExecutorServiceFactory.createExecutorService());
    // clientConfig.register(new LoggingFeature(logger, Level.ALL, LoggingFeature.Verbosity.PAYLOAD_ANY, 8192));

    // Build Jersey client with the customized Apache HttpClient and ExecutorService
    return ClientBuilder.newBuilder()
        .withConfig(clientConfig)
        .property("jersey.config.client.httpClient", httpClient) // Use the configured HttpClient
        .executorService(JerseyExecutorServiceFactory.createExecutorService()) // Pass the executor service
        .build();

  }*/

  public static Client createJerseyClient() {
    System.out.println("called");
    HttpConnectionManagerParams params = new HttpConnectionManagerParams();
    params.setSoTimeout(60000);
    params.setConnectionTimeout(50000);
    params.setMaxTotalConnections(5000);
    params.setDefaultMaxConnectionsPerHost(30000);

    MultiThreadedHttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();
    connectionManager.setParams(params);

    HttpClient httpClient = new HttpClient(connectionManager);
   // httpClient.getParams().setParameter(RETRY_HANDLER, new DefaultHttpMethodRetryHandler(maxRetryCount, true));

    ClientConfig config = new DefaultApacheHttpClientConfig();
    //config.getProperties().put(JSONConfiguration.FEATURE_POJO_MAPPING, true);
    config.getProperties().put("com.sun.jersey.api.json.POJOMappingFeature", true);
    //config.getSingletons().add(new GsonProvider<>(inGsonWrapper));

    ApacheHttpClientHandler clientHandler = new ApacheHttpClientHandler(httpClient, config);
    ClientHandler root = new ApacheHttpClient(clientHandler);

    //registerProtocol("https", new Protocol("https", new NonValidatingSocketFactory(), 443));

    return new Client(root);
  }
}

