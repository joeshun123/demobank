package com.dbs.demo.service;

import com.dbs.demo.util.DBSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PaymentTermService {

  public String getDefaultPaymentTerm(){
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(100,120);
    log.info("Step) 14. PaymentTermService >> getDefaultPaymentTerm() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
    return "default payment term";
  }
}
