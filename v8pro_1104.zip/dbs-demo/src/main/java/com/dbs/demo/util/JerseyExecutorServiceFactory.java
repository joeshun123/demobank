package com.dbs.demo.util;

import com.dbs.demo.factory.NamedThreadFactory;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class JerseyExecutorServiceFactory {

  private static final int THREAD_POOL_SIZE = 150;

  public static ExecutorService createExecutorService() {
    return Executors.newFixedThreadPool(THREAD_POOL_SIZE,new NamedThreadFactory("Jersy-client"));
  }
}
