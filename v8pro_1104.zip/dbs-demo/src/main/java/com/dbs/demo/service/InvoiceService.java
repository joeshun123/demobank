package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeLine;
import com.dbs.demo.dto.ChargeableTransactions;
import com.dbs.demo.dto.InvoiceRequestDTO;
import com.dbs.demo.dto.InvoiceResponseDTO;
import com.dbs.demo.dto.TerrifRule;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import com.dbs.demo.validator.InvoiceValidator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class InvoiceService {

  private final ExecutorService executor = Executors.newFixedThreadPool(5,new NamedThreadFactory("deduceTerrifCode"));
  @Autowired
  private InvoiceValidator invoiceValidator;

  @Autowired
  private ChargeableTransactionService chargeableTransactionService;

  @Autowired
  private CustomerService customerService;

  @Autowired
  private PaymentTermService paymentTermService;

  @Autowired
  private ServiceTypeService serviceTypeService;

  @Autowired
  private TariffService tariffService;

  @Autowired
  private InterceptionService interceptionService;

  @Autowired
  private ChargeLineService chargeLineService;

  @Autowired
  private ExchangeRateService exchangeRateService;

  @Autowired
  private TaxGroupService taxGroupService;

  @Autowired
  private TaxRateService taxRateService;

  @Autowired
  private InvoiceLineService invoiceLineService;

  @Autowired
  private ContractService contractService;

  @Autowired
  private InvoiceHeaderService invoiceHeaderService;

  public InvoiceResponseDTO createInvoice(InvoiceRequestDTO requestDTO) {

    invoiceValidator.validateRequest(requestDTO);
    String customer = customerService.getCustomer(requestDTO.getCustomerId());
    List<ChargeableTransactions> transactions = chargeableTransactionService.fetchChargeableTransactions(requestDTO);
    if (transactions.isEmpty()) {
      return new InvoiceResponseDTO("Step) 5. No Transaction Found",
          "Invoice Not generated");
    }
   log.info("Total transactions : " + transactions.size());
    chargeableTransactionService.lockTransactions(transactions);
    List<String> serviceTypes = serviceTypeService.getServiceTypes("criteria");
    List<TerrifRule> terrifRules = tariffService.getTerrifRules(serviceTypes);
    List<TerrifRule> timeBaseTerrifRules = tariffService.getTerrifRules(serviceTypes);
    CompletableFuture<Void> allFutures = CompletableFuture.allOf(
        CompletableFuture.runAsync(() -> tariffService.deduceTerrifCodeAndUpdateTransaction(serviceTypes, terrifRules, transactions),executor),
        CompletableFuture.runAsync(() -> tariffService.deduceFreeQtyCodeAndUpdateTransaction(serviceTypes, timeBaseTerrifRules, transactions),executor));
    allFutures.thenRun(() -> log.info("Tariff code and free qty deduce successfully")).join();
    paymentTermService.getDefaultPaymentTerm();
    contractService.getContracts();
    tariffService.getTariffRateForContract();
    tariffService.getFreeQtyForContract();
    if (checkInterceptionsIsActive()) {
      interceptionService.intercept2(transactions);
    }
    List<ChargeLine> lines = chargeLineService.prepareChargeLines(transactions);
    interceptionService.interceptChargeLines(lines);

    taxGroupService.fetchTaxGroup();
    exchangeRateService.fetchExchangeRate(10L,10L);
    taxRateService.fetchTaxRate();
    invoiceLineService.prepareInvoiceLine(lines);
    invoiceLineService.applyTaxAndGenerateTaxLine(lines);
    interceptionService.intercept();//Draft interception
    invoiceHeaderService.createInvoiceHeader();
    saveAll(transactions);
    CompletableFuture.runAsync(()->updateChargableTransactionStatus(transactions)).thenRun(()-> log.info("Transaction updated successfully"));
    if (!transactions.isEmpty()) {
      log.info("===============" + transactions.get(0));
    }
    return new InvoiceResponseDTO("invoice generated",
        "Invoice generated successfully (total chargeable transactions processed = " + transactions.size() + ")");
  }

  private void updateChargableTransactionStatus(List<ChargeableTransactions> transactions) {
      long startTime = System.currentTimeMillis();
      chargeableTransactionService.updateTransactionStatus(transactions);
      log.info("Step) 29. InvoiceService >> updateChargableTransactionStatus,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
  }


  private void saveAll(List<ChargeableTransactions> transactions) {
    long startTime = System.currentTimeMillis();
    chargeableTransactionService.updateTransactionStatus(transactions);
    log.info("Step) 28. InvoiceService >> saveAll,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
  }

  private boolean checkInterceptionsIsActive() {
    DBSUtil.randomSleep(10, 50);
    return true;
  }


}
