package com.dbs.demo.service;

import com.dbs.demo.util.DBSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ExchangeRateService {

  public void fetchExchangeRate(Long baseCurrencyKey, Long customerCurrencyKey){
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(100,130);
    log.info("Step) 22. ExchangeRateService >> fetchExchangeRate() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
  }
}
