package com.dbs.demo.service;

import com.dbs.demo.util.DBSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ContractService {

  public String getContracts(){
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(100,120);
    log.info("Step) 15. ContractService >> getContracts() ,Sleep Time: "+t+", Duration : "+(System.currentTimeMillis() -startTime));
    return "default payment term";
  }
}
