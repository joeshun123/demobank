package com.dbs.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class DBSConfig {


  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

/*  @Bean
  public RestTemplate restTemplate() {
    HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
    factory.setHttpClient(httpClient());  // Set HttpClient with connection pooling and timeouts
    return new RestTemplate(factory);
  }*/

 /* @Bean
  public CloseableHttpClien httpClient() {
    // Configure connection manager for connection pooling
    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
    connectionManager.setMaxTotal(1000);  // Max total connections
    connectionManager.setDefaultMaxPerRoute(200);  // Max connections per route

    // Configure timeouts
    RequestConfig requestConfig = RequestConfig.custom()
        .setConnectTimeout(Timeout.ofSeconds(5))  // 5 seconds connection timeout
        .build();

    return HttpClients.custom()
        .setConnectionManager(connectionManager)
        .setDefaultRequestConfig(requestConfig)
        .build();
  }*/

/*  @Bean
  public Client jerseyClient() {
    // Set up a connection pool manager
    PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
    connectionManager.setMaxTotal(1000);  // Max total connections
    connectionManager.setDefaultMaxPerRoute(500);  // Max per host

    // Create a CloseableHttpClient with the connection manager
    CloseableHttpClient httpClient = HttpClients.custom()
        .setConnectionManager(connectionManager)
        .build();

    // Create a Jersey client with the custom HttpClient
    ClientConfig clientConfig = new ClientConfig();
    clientConfig.property(ClientProperties.HTTP_CLIENT, httpClient);

    // Set timeouts
    clientConfig.property(ClientProperties.CONNECT_TIMEOUT, 5000); // 5 seconds
    clientConfig.property(ClientProperties.READ_TIMEOUT, 10000);   // 10 seconds

    return JerseyClientBuilder.newBuilder()
        .withConfig(clientConfig)
        .build();
  }*/
}
