package com.dbs.demo.service;

import com.dbs.demo.dto.ChargeLine;
import com.dbs.demo.dto.InvoiceLine;
import com.dbs.demo.factory.NamedThreadFactory;
import com.dbs.demo.util.DBSUtil;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class InvoiceLineService {

  private final ExecutorService executor = Executors.newFixedThreadPool(150,new NamedThreadFactory("InvoiceLineServiceThread"));

  public List<InvoiceLine> prepareInvoiceLine(List<ChargeLine> chargeLines) {
    long startTime = System.currentTimeMillis();
    List<CompletableFuture<InvoiceLine>> futures = chargeLines.stream()
        .map(tx -> CompletableFuture.supplyAsync(() -> createInvoiceLine(tx), executor))
        .toList();
    // Wait for all futures to complete and collect results
    List<InvoiceLine> list = futures.stream()
        .map(CompletableFuture::join) // Block and get the result
        .toList();
    log.info("Step) 24. InvoiceLineService >> prepareInvoiceLine() ,Sleep Time: N/A , Duration: "+(System.currentTimeMillis() -startTime));
    return list;
  }

  public InvoiceLine createInvoiceLine(ChargeLine chargeLine) {
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(1, 10);
    log.info("InvoiceLineService >> createInvoiceLine() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    return new InvoiceLine(chargeLine.getId());
  }

  public String applyTaxAndGenerateTaxLine(List<ChargeLine> chargeLines) {
    //TODO : require to refactor based on actual code
    long startTime = System.currentTimeMillis();
    int t =DBSUtil.randomSleep(50, 60);
    log.info("Step) 25. InvoiceLineService >> applyTaxAndGenerateTaxLine() ,Sleep Time: "+t+" , Duration: "+(System.currentTimeMillis() -startTime));
    return "Generate Tax Line";
  }
}
