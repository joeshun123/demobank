package zodiac.zara.base.service;

import ch.qos.logback.classic.pattern.ThrowableHandlingConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxy;
import jakarta.annotation.Nonnull;

public class ExceptionMessageArgumentConverter extends ThrowableHandlingConverter {
    public String convert(@Nonnull ILoggingEvent event) {
        IThrowableProxy proxy = event.getThrowableProxy();
        if (proxy instanceof ThrowableProxy) {
            ThrowableProxy throwableProxy = (ThrowableProxy)proxy;
            return throwableToString(throwableProxy.getThrowable());
        } else {
            return "";
        }
    }

    private static String throwableToString(@Nonnull Throwable throwable) {
        return throwable == null ? "" : throwable.getLocalizedMessage();
    }
}
