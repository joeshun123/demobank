package zdc.demo.CompletableFuture;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.LongHistogram;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.metrics.ObservableLongGauge;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import jakarta.annotation.Nonnull;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api")
public class DemoController {
    @Autowired
    private Environment env;
    @Autowired
    private OpenTelemetry openTelemetry;
    //private Counter counter;
    private LongCounter counter;
    private ObservableLongGauge gauge;
    private LongHistogram histogram;
    private Tracer tracer;

    //public DemoController(final MeterRegistry meterRegistry) {
        /*
        this.counter = Counter.builder("news_fetch_request_total").
                tag("version", "v1").
                description("News Fetch Count").
                register(meterRegistry);
         */
    //}
    Attributes gaugeControllerDelay = Attributes.of(AttributeKey.stringKey("aspect"), "controller_wait");
    Attributes gaugeProcessDuration = Attributes.of(AttributeKey.stringKey("aspect"), "processing");
    Attributes htControllerDelay = Attributes.of(AttributeKey.stringKey("htAspect"), "controller_wait");
    Attributes htProcessDuration = Attributes.of(AttributeKey.stringKey("htAspect"), "processing");

    @PostConstruct
    public void init() {
        Meter meter = openTelemetry.getMeter("io.opentelemetry.example");
        counter = meter.counterBuilder("cf_counter").build();
        gauge = meter.gaugeBuilder("cf_duration").setUnit("ms").ofLongs().buildWithCallback(r->{
                    r.record(controllerDelayAt.get(), gaugeControllerDelay);
                    r.record(processDurationAt.get(), gaugeProcessDuration);
                });
        histogram = meter.histogramBuilder("cf_processing")
                .setUnit("ms")
                .ofLongs()
                .build();

        tracer = openTelemetry.getTracer("io.opentelemetry.example.metrics");
    }

    @GetMapping("/deduce-tariff-code")
    public String deduceTariffCode(@RequestParam String tariffCode){
        TSleepUtil.sleep(300);
        return "TariffCode ("+tariffCode+") deduced";
    }
    @GetMapping("/deduce-free-qty")
    public String deduceFreeQty(@RequestParam String tariffCode){
        TSleepUtil.sleep(300);
        return "FreeQty found for TariffCode ("+tariffCode+")";
    }
    //private Meter meter = GlobalOpenTelemetry.meterBuilder("io.opentelemetry.metrics.hello").build();
    //private LongCounter counter = meter.counterBuilder("helloCounter").build();

    private static AtomicLong processDurationAt = new AtomicLong();
    private static AtomicLong controllerDelayAt = new AtomicLong();
    @GetMapping("/intercept-call-code")
    public Test interceptCall(@RequestParam String tariffCode, @RequestParam long callTime, @RequestParam String traceId,
                              @Nonnull final HttpServletRequest httpServletRequest){
        Span span = tracer.spanBuilder("workflow").setSpanKind(SpanKind.INTERNAL).startSpan();
        try (Scope scope = span.makeCurrent()) {
            Test t = this.doInterceptCall(tariffCode, callTime, traceId, httpServletRequest);
            span.setStatus(StatusCode.OK);
        } catch (Exception e) {
            span.setStatus(StatusCode.ERROR, "Error while finding file");
            span.recordException(e);
        } finally {
            span.end();
        }
        return new Test("A");
    }
    //@GetMapping("/intercept-call-code")
    private Test doInterceptCall(@RequestParam String tariffCode, @RequestParam long callTime, @RequestParam String traceId,
        @Nonnull final HttpServletRequest httpServletRequest){
        //counter.add(1);
        counter.add(1);
        //log.info(httpServletRequest.getAttribute("valveTime") + "");
        long receive = System.currentTimeMillis();
        long controllerDelay = receive - callTime;
        long start = System.nanoTime();
        //int i = TSleepUtil.randomSleep(400,800);
        int sleepTime = -1;
        try {
            sleepTime = (new Random()).nextInt(50, 100);
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        long endTime = System.nanoTime();
        long processDuration = (endTime-start)/1000000;

        controllerDelayAt.set(controllerDelay);
        histogram.record((controllerDelay), htControllerDelay);
        processDurationAt.set(processDuration);
        histogram.record(processDuration, htProcessDuration);


        log.error("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, processDuration, receive, callTime);
        log.info("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, processDuration, receive, callTime);
        log.debug("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, processDuration, receive, callTime);
        log.trace("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, processDuration, receive, callTime);
        //return "Intercept API sleep time : no process";
        return new Test("A");
    }
    @Data
    @AllArgsConstructor
    public static class Test {
        private String field1;
    }

    @GetMapping("/test")
    public String test(){
        String maxThreads = env.getProperty("server.tomcat.threads.max");
        String maxConnections = env.getProperty("server.tomcat.max-connections");
        String acceptCount = env.getProperty("server.tomcat.accept-count");
        return "Max Threads: " + maxThreads + ", Max Connections: " + maxConnections+" acceptCount: "+acceptCount;
    }
}
