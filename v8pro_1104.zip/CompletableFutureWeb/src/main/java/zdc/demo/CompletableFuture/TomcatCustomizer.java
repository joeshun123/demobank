package zdc.demo.CompletableFuture;

import java.util.Collection;

import org.apache.catalina.core.StandardThreadExecutor;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatProtocolHandlerCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class TomcatCustomizer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {
  @Autowired
  private StandardThreadExecutor threadPoolTaskExecutor;
  //private ThreadPoolTaskExecutor threadPoolTaskExecutor;
  @Autowired
  private TestValve testValve;

  @Override
  public void customize(TomcatServletWebServerFactory factory) {
    Collection<TomcatProtocolHandlerCustomizer<?>> customizers = factory.getTomcatProtocolHandlerCustomizers();
    customizers.add(protocolHandlerCustomizer());
    factory.setTomcatProtocolHandlerCustomizers(customizers);

    //TomcatWebServer webServer = (TomcatWebServer) factory.getWebServer();
    //webServer.getTomcat().getService().addExecutor(threadPoolTaskExecutor);

    factory.addEngineValves(testValve);
    //factory.addContextValves(testValve);

    //Collection<TomcatConnectorCustomizer> connectorCustomizers = factory.getTomcatConnectorCustomizers();
    //connectorCustomizers.add(connectorCustomizer());
    factory.setProtocol("zdc.demo.CompletableFuture.CustomHttp11Nio2Protocol");
  }
  public TomcatProtocolHandlerCustomizer<?> protocolHandlerCustomizer(){
    return protocolHandler -> {
      protocolHandler.setExecutor(threadPoolTaskExecutor);
    };
  }

  public TomcatConnectorCustomizer connectorCustomizer() {
    return (connector) -> {
      ((AbstractHttp11Protocol<?>) connector.getProtocolHandler()).setProcessorCache(600);
    };
  }
}
