package zdc.demo.CompletableFuture;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.exporter.otlp.http.metrics.OtlpHttpMetricExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.MetricExporter;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.BatchSpanProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static io.opentelemetry.semconv.resource.attributes.ResourceAttributes.SERVICE_NAME;

@Configuration
public class MetricExporterConfig {
    public static MetricExporter otlpHttpMetricExporter(String endpoint) {
        return OtlpHttpMetricExporter.builder()
                .setEndpoint(endpoint)
                //.addHeader("api-key", "value")
                .setTimeout(Duration.ofSeconds(10))
                .build();
    }

    @Bean
    public OpenTelemetry initOpenTelemetry() {
        // Include required service.name resource attribute on all spans and metrics
        Resource resource =
                Resource.getDefault()
                        .merge(Resource.builder().put(SERVICE_NAME, "OtlpExporterExample").build());
        OpenTelemetrySdk openTelemetrySdk =
                OpenTelemetrySdk.builder()
                        .setTracerProvider(
                                SdkTracerProvider.builder()
                                        .setResource(resource)
                                        .addSpanProcessor(
                                                BatchSpanProcessor.builder(
                                                                SpanExporterConfig.otlpHttpSpanExporter("http://localhost:14318/v1/traces"))
                                                        //OtlpGrpcSpanExporter.builder()
                                                        //.setTimeout(2, TimeUnit.SECONDS)
                                                        //.build())
                                                        .setScheduleDelay(100, TimeUnit.MILLISECONDS)
                                                        .build())
                                        .build())
                        .setMeterProvider(
                                SdkMeterProvider.builder()
                                        .setResource(resource)
                                        .registerMetricReader(
                                                PeriodicMetricReader.builder(
                                                                MetricExporterConfig.otlpHttpMetricExporter("http://localhost:14318/v1/metrics"))
                                                        .setInterval(Duration.ofMillis(1000))
                                                        .build())
                                        .build())
                        .buildAndRegisterGlobal();

        Runtime.getRuntime().addShutdownHook(new Thread(openTelemetrySdk::close));

        return openTelemetrySdk;
    }
}
