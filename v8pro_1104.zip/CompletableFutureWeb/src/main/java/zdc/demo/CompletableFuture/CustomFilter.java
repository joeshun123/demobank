package zdc.demo.CompletableFuture;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CustomFilter implements Filter, Ordered {
  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
      throws IOException, ServletException {
    if (servletRequest.getParameter("callTime")!=null) {
      long sent = Long.parseLong(servletRequest.getParameter("callTime"));
      long received = System.currentTimeMillis();
      log.info("TraceId: {}: FilterDelay: {}",
              servletRequest.getParameter("traceId"), (received - sent));
    }
    filterChain.doFilter(servletRequest, servletResponse);
  }
  @Override
  public int getOrder() {
    return Ordered.HIGHEST_PRECEDENCE;
  }
}
