package fri.util.database.jpa.tree.examples.closuretable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import fri.util.database.jpa.tree.closuretable.ClosureTableTreeNode;

/** Example entity, Ctt = Closure Table Tree. */
@Entity
public class PersonCtt implements ClosureTableTreeNode
{
	@Id
	@GeneratedValue
	private Long id;

	@Column(nullable = false)
	private String name;

	public PersonCtt() {
	}

	public PersonCtt(String name) {
		this.name = name;
	}

	@Override
	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public ClosureTableTreeNode clone() {
		return new PersonCtt(getName());
	}

	@Override
	public String toString() {
		return getClass().getSimpleName()+"@"+System.identityHashCode(this)+": id="+getId()+", name="+getName();
	}
}