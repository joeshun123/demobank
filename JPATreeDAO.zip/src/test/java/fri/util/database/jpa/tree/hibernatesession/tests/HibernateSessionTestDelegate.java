package fri.util.database.jpa.tree.hibernatesession.tests;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import fri.util.database.jpa.commons.DbSession;
import fri.util.database.jpa.tree.closuretable.pojos.ClosureTableTreePojo;
import fri.util.database.jpa.tree.closuretable.pojos.TemporalTreePathImpl;
import fri.util.database.jpa.tree.closuretable.pojos.TreePathImpl;
import fri.util.database.jpa.tree.hibernatesession.DbSessionHibernateImpl;
import fri.util.database.jpa.tree.nestedsets.pojos.NestedSetsTreePojo;
import fri.util.database.jpa.tree.nestedsets.pojos.NonUniqueNestedSetsTreePojo;
import fri.util.database.jpa.tree.nestedsets.pojos.TemporalNestedSetsTreePojo;

/**
 * Implements Hibernate Session management for all Hibernate Session tests.
 * 
 * @author Fritz Ritzberger, Aug 24, 2013
 */
class HibernateSessionTestDelegate
{
	// any new test POJO class must be added here when used in AbstractTreeTest!
	private Class<?> [] persistenceClasses = new Class<?> []	{
		NestedSetsTreePojo.class,
		NonUniqueNestedSetsTreePojo.class,
		TemporalNestedSetsTreePojo.class,
		ClosureTableTreePojo.class,
		TreePathImpl.class,
		TemporalTreePathImpl.class,
	};

	private SessionFactory sessionFactory;
	private Session session;
	
	void setUp() throws Exception {
		final StandardServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		
		final MetadataSources metadataSources = new MetadataSources(serviceRegistry);
		for (Class<?> persistenceClass : persistenceClasses)
			metadataSources.addAnnotatedClass(persistenceClass);
		
		sessionFactory = metadataSources.buildMetadata().buildSessionFactory();
		session = sessionFactory.openSession();
	}
	
	void tearDown() throws Exception {
		session.close();
		sessionFactory.close();
	}
	
	DbSession newDbSession() {
		session.beginTransaction();
		return new DbSessionHibernateImpl(session);
	}
	
	void commitDbTransaction() {
		session.getTransaction().commit();
	}

	void rollbackDbTransaction() {
		session.getTransaction().rollback();
	}

}
