package com.test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.typeadapters.RuntimeTypeAdapterFactory;
import com.test.dto.*;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

import java.util.Map;

@Component
public class GsonRegister {
    @EventListener
    public void handleContextRefresh(final ContextRefreshedEvent event) {
        ConfigurableListableBeanFactory beanFactory = ((ConfigurableApplicationContext)event.getApplicationContext()).getBeanFactory();
        try {
            ClassPathScanningCandidateComponentProvider p = new ZaraCandidateComponentProvider(false);
            p.addIncludeFilter(new AnnotationTypeFilter(ZaraGsonType.class));
            Class typeClass = Class.forName(p.findCandidateComponents("com.test.dto").stream().findFirst().get().getBeanClassName());
            RuntimeTypeAdapterFactory<Vehicle> vehicleAdapterFactory = RuntimeTypeAdapterFactory.of(typeClass, "type");

            p = new ZaraCandidateComponentProvider(false);
            p.addIncludeFilter(new AnnotationTypeFilter(ZaraGsonSubType.class));
            p.findCandidateComponents("com.test").stream().forEach(s->{
                Class subTypeClass = null;
                try {
                    subTypeClass = Class.forName(s.getBeanClassName());
                    vehicleAdapterFactory.registerSubtype(subTypeClass, subTypeClass.getSimpleName());
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            });
            Gson gson = new GsonBuilder().registerTypeAdapterFactory(vehicleAdapterFactory).create();
            beanFactory.registerSingleton("Gson", gson);
            System.out.println("OK");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public class ZaraCandidateComponentProvider extends ClassPathScanningCandidateComponentProvider {
        public ZaraCandidateComponentProvider(boolean useDefaultFilters) {
            super(useDefaultFilters);
        }

        protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
            return true;
        }
    }
}
