package com.test.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;

@JsonTypeName("bicycle")
@Data
@ZaraGsonSubType
public class Bicycle extends Vehicle {
    private int frameHeight;
}
