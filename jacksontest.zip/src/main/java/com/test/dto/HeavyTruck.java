package com.test.dto;

import lombok.Data;

@Data
@ZaraGsonSubType
public class HeavyTruck extends Truck {
    private String heavyText;
}
