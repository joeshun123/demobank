package com.test.dto;

import lombok.Data;

@Data
@ZaraGsonSubType
public class LightTruck extends Truck {
    private String lightText;
}
