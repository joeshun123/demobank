package com.test.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;

@JsonTypeName("car")
@Data
@ZaraGsonSubType
public class Car extends Vehicle {
    private int cargoCapacityInLiter;
}
