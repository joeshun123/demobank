package com.test.dto;

import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;

@JsonTypeName("truck")
@Data
@ZaraGsonSubType
public class Truck extends Vehicle{
    private int maxLoad;
}
