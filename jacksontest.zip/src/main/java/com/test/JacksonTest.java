package com.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.dto.Bicycle;
import com.test.dto.Car;
import com.test.dto.Truck;
import com.test.dto.Vehicle;

/**
 * Created by N1057 on 9/8/2017.
 */
public class JacksonTest {
    public static void main(String args[]) {
        Bicycle v1 = new Bicycle();v1.setMaxSpeed(1);v1.setFrameHeight(10);
        Car v2 = new Car();v2.setMaxSpeed(5);v2.setCargoCapacityInLiter(2);
        Truck v3 = new Truck();v3.setMaxSpeed(6);v3.setMaxLoad(7);
        try {
            ObjectMapper mapper = new ObjectMapper();
            String result = mapper.writeValueAsString(v1);
            Vehicle b = mapper.readerFor(Vehicle.class).readValue(result);
            System.out.println(b.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
