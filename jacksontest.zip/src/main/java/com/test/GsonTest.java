package com.test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.typeadapters.RuntimeTypeAdapterFactory;
import com.test.dto.*;

public class GsonTest {
    public static void main(String args[]) {
        RuntimeTypeAdapterFactory<Vehicle> vehicleAdapterFactory = RuntimeTypeAdapterFactory.of(Vehicle.class, "type")
                .registerSubtype(Car.class, "car")
                .registerSubtype(Truck.class, "truck")
                .registerSubtype(Bicycle.class, "bicycle")
                .registerSubtype(HeavyTruck.class, "heavyTruck")
                .registerSubtype(LightTruck.class, "lightTruck");

        Gson gson = new GsonBuilder().registerTypeAdapterFactory(vehicleAdapterFactory).create();


        Bicycle v1 = new Bicycle();v1.setMaxSpeed(1);v1.setFrameHeight(10);
        Car v2 = new Car();v2.setMaxSpeed(5);v2.setCargoCapacityInLiter(2);
        Truck v3 = new Truck();v3.setMaxSpeed(6);v3.setMaxLoad(7);
        LightTruck v4 = new LightTruck();v4.setLightText("111");v4.setMaxLoad(8);v4.setMaxSpeed(9);
        HeavyTruck v5 = new HeavyTruck();v5.setHeavyText("222");v5.setMaxLoad(13);v5.setMaxSpeed(14);

        String vvString = gson.toJson(v4, Vehicle.class);
        Vehicle vehicle = gson.fromJson(vvString, Vehicle.class);
        System.out.println(vehicle.toString());
    }
}
