package com.test;

import com.google.gson.Gson;
import com.test.dto.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringMain {
    public static void main(String args[]) {
        ApplicationContext appContext = new AnnotationConfigApplicationContext(Config.class);

        Bicycle v1 = new Bicycle();v1.setMaxSpeed(1);v1.setFrameHeight(10);
        Car v2 = new Car();v2.setMaxSpeed(5);v2.setCargoCapacityInLiter(2);
        Truck v3 = new Truck();v3.setMaxSpeed(6);v3.setMaxLoad(7);
        LightTruck v4 = new LightTruck();v4.setLightText("111");v4.setMaxLoad(8);v4.setMaxSpeed(9);
        HeavyTruck v5 = new HeavyTruck();v5.setHeavyText("222");v5.setMaxLoad(13);v5.setMaxSpeed(14);

        Gson gson = appContext.getBean(Gson.class);
        String vvString = gson.toJson(v4, Vehicle.class);
        Vehicle vehicle = gson.fromJson(vvString, Vehicle.class);
        System.out.println(vehicle.toString());
/*
        String vvString = gson.toJson(v4, Vehicle.class);
        Vehicle vehicle = gson.fromJson(vvString, Vehicle.class);
        System.out.println(vehicle.toString());
        */
    }
}
