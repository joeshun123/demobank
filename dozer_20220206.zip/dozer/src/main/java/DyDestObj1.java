public class DyDestObj1 {
    private String d1Str1;
    private String d1Str2;

    public DyDestObj1() {
    }

    public DyDestObj1(String d1Str1, String d1Str2) {
        this.d1Str1 = d1Str1;
        this.d1Str2 = d1Str2;
    }

    public String getD1Str1() {
        return d1Str1;
    }

    public void setD1Str1(String d1Str1) {
        this.d1Str1 = d1Str1;
    }

    public String getD1Str2() {
        return d1Str2;
    }

    public void setD1Str2(String d1Str2) {
        this.d1Str2 = d1Str2;
    }

    @Override
    public String toString() {
        return "DyDestObj1{" +
                "d1Str1='" + d1Str1 + '\'' +
                ", d1Str2='" + d1Str2 + '\'' +
                '}';
    }
}
