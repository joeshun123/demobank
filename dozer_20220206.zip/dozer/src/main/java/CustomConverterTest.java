import java.util.ArrayList;
import java.util.List;
import org.dozer.DozerBeanMapper;
import org.dozer.DozerBeanMapperSingletonWrapper;
import org.dozer.Mapper;

public class CustomConverterTest {
  private void map() {
    List myMappingFiles = new ArrayList();
    myMappingFiles.add("customConverter.xml");
    CustomSourceObject src = new CustomSourceObject();
    src.setField1("F1");src.setField2("F2");

    CustomDestObject dest = new CustomDestObject();

    //Mapper mapper = DozerBeanMapperSingletonWrapper.getInstance();
    DozerBeanMapper mapper = new DozerBeanMapper();
    mapper.setMappingFiles(myMappingFiles);
    mapper.map(src, dest);
    System.out.println(dest);
  }

  public static void main(String args[]) {
    CustomConverterTest t = new CustomConverterTest();
    t.map();
  }
}
