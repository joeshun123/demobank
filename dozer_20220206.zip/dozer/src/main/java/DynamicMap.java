import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;

import java.util.ArrayList;
import java.util.List;

public class DynamicMap {
    public void test() {
        /**
        BeanMappingBuilder builder = new BeanMappingBuilder() {
            @Override
            protected void configure() {
                mapping(DySourceObj.class, DyDestObj1.class)

            }
        };
        **/
        DySourceObj s = new DySourceObj("DDD1", "DDD2");

        List myMappingFiles = new ArrayList();
        myMappingFiles.add("dynamicMapping.xml");
        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);
        DyDestObj1 obj1 = mapper.map(s, DyDestObj1.class);
        //DyDestObj1 obj2 = mapper.map(s, DyDestObj1.class, "B");
        System.out.println(obj1);
        //System.out.println(obj2);
    }
    public static void main(String[] args) {
        DynamicMap map = new DynamicMap();
        map.test();
    }
}
