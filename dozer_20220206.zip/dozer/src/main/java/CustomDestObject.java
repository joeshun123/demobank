public class CustomDestObject {
  private String field11;
  private String field22;

  public String getField11() {
    return field11;
  }

  public void setField11(String field11) {
    this.field11 = field11;
  }

  public String getField22() {
    return field22;
  }

  public void setField22(String field22) {
    this.field22 = field22;
  }
}
