import java.util.List;

/**
 * Created by user on 11/12/2014.
 */
public class DestinationObject {
    private String sameField;
    private Long destField1;
    private List<DestinationAddress> destinationAddresses;
    private FingerprintId fingerprintId;

    public List<DestinationAddress> getDestinationAddresses() {
        return destinationAddresses;
    }

    public void setDestinationAddresses(List<DestinationAddress> destinationAddresses) {
        this.destinationAddresses = destinationAddresses;
    }

    public Long getDestField1() {
        return destField1;
    }

    public void setDestField1(Long destField1) {
        this.destField1 = destField1;
    }

    public FingerprintId getFingerprintId() {
        return fingerprintId;
    }

    public void setFingerprintId(FingerprintId fingerprintId) {
        this.fingerprintId = fingerprintId;
    }
}
