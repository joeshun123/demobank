import org.dozer.DozerBeanMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MappingTest3 {
    public static void main(String args[]) {
        MappingTest3 m = new MappingTest3();
        //m.mapWithoutId();
        m.mapWithId();
    }
    private void mapWithId() {
        List myMappingFiles = new ArrayList();
        myMappingFiles.add("parentMapping.xml");
        myMappingFiles.add("childMapping.xml");

        Parent p = new Parent();
        p.setParentField("parentF");

        ChildDto c = new ChildDto();
        c.setChildField("childF");

        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);
        mapper.map(p, c, "pMap");
        //ParentDto pd = mapper.map(c, ParentDto.class);
        System.out.println(c.getParentField());
        //System.out.println(pd.getParentField() + " " + pd.getChildField());
    }
    private void mapWithoutId() {
        List myMappingFiles = new ArrayList();
        myMappingFiles.add("parentMapping.xml");
        myMappingFiles.add("childMapping.xml");

        //Parent p = new Parent();
        //p.setParentField("parentF");
        Child c = new Child();
        c.setChildField("childF");
        c.setParentField("parentF");

        DozerBeanMapper mapper = new DozerBeanMapper();
        mapper.setMappingFiles(myMappingFiles);
        ChildDto pd = mapper.map(c, ChildDto.class);
        //System.out.println(pd.getParentField());
        System.out.println(pd.getParentField() + " " + pd.getChildField());
    }
}
