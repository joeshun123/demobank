public class DestClass {
  public enum FromClass {
    SubClass1, SubClass2
  }
  private String field;
  private FromClass source;

  public FromClass getSource() {
    return source;
  }

  public void setSource(FromClass source) {
    this.source = source;
  }

  public String getField() {
    return field;
  }

  public void setField(String field) {
    this.field = field;
  }
}
