package org.hibernate.persister.entity;

import static java.util.stream.Collectors.joining;

import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AepGetter {
  public void get(final AbstractEntityPersister aep) {
    log.info(Arrays.stream(aep.getSQLInsertStrings()).collect(joining(",")));
    log.info(Arrays.stream(aep.getSQLUpdateStrings()).collect(joining(",")));
    log.info(Arrays.stream(aep.getSQLDeleteStrings()).collect(joining(",")));
  }
}
