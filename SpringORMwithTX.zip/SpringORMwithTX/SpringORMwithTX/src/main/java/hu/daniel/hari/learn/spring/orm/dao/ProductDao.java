package hu.daniel.hari.learn.spring.orm.dao;

import hu.daniel.hari.learn.spring.orm.model.Attribute;
import hu.daniel.hari.learn.spring.orm.model.Owner;
import hu.daniel.hari.learn.spring.orm.model.Part;
import hu.daniel.hari.learn.spring.orm.model.Product;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class ProductDao {

	@PersistenceContext
	private EntityManager em;

	public void persist(Product product) {
		em.persist(product);
	}

	public void persist(Owner owner) {
		em.persist(owner);
	}

	public void persist(Part part) {
		em.persist(part);
	}

	public void persist(Attribute attribute) {
		em.persist(attribute);
	}

	public List<Product> findAll() {
		return em.createQuery("SELECT p FROM Product p").getResultList();
	}

}
