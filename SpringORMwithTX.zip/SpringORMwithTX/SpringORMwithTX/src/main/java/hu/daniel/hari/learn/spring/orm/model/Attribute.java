package hu.daniel.hari.learn.spring.orm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "A_ATTRIBUTE")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Attribute extends BaseProduct {
  @Column(name = "NAME")
  private String name;
}
