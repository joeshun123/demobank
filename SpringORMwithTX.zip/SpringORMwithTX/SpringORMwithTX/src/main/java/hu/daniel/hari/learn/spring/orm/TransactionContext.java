package hu.daniel.hari.learn.spring.orm;

import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.NamedThreadLocal;

@Slf4j
public class TransactionContext {
  private static final ThreadLocal<List<EntityChange>> affectedEntityChanges = new NamedThreadLocal("Transaction affected entities");
  public static List<EntityChange> popAffectedEntityChanges() {
    List<EntityChange> changes = affectedEntityChanges.get();
    cleanup();
    return changes;
  }
  public static void addEntityChange(final EntityChange entityChange) {
    boolean isNewlyAdded = false;
    List<EntityChange> changes = affectedEntityChanges.get();
    if (changes==null) {
      isNewlyAdded = true;
      changes = new ArrayList<>();
    }
    changes.add(entityChange);
    if (isNewlyAdded) {
      affectedEntityChanges.set(changes);
    }
    log.info("EntityChange: " + entityChange + " added.");
  }
  public static void cleanup() {
    affectedEntityChanges.remove();
  }
}
