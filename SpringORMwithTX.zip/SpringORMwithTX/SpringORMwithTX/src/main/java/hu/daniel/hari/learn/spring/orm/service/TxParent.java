package hu.daniel.hari.learn.spring.orm.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public class TxParent {

}
