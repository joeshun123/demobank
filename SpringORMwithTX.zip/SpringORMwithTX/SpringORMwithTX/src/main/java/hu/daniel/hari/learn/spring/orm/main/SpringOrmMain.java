package hu.daniel.hari.learn.spring.orm.main;

import static java.util.stream.Collectors.joining;

import hu.daniel.hari.learn.spring.orm.dao.ProductDao;
import hu.daniel.hari.learn.spring.orm.model.Attribute;
import hu.daniel.hari.learn.spring.orm.model.Owner;
import hu.daniel.hari.learn.spring.orm.model.Part;
import hu.daniel.hari.learn.spring.orm.model.Product;

import hu.daniel.hari.learn.spring.orm.service.AbcServiceImpl;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.persistence.EntityManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.SessionFactory;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.hibernate.persister.entity.AepGetter;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.util.StringUtils;

@Slf4j
public class SpringOrmMain {
	
	public static void main(String[] args) {
		
		//Create Spring application context
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:/spring.xml");
		
		//Get service from context. (service's dependency (ProductDAO) is autowired in ProductService)
		//ProductService productService = ctx.getBean(ProductService.class);
		AbcServiceImpl productService = ctx.getBean(AbcServiceImpl.class);
		//AbcFacade productService = ctx.getBean(AbcFacade.class);
		
		//Do some data operation
		
		//productService.add(new Product(1, "Bulb"));
		//productService.add(new Product(2, "Dijone mustard"));
		
		//System.out.println("listAll: " + productService.listAll());
		
		//Test transaction rollback (duplicated key)

		EntityManagerFactory emf = ctx.getBean(EntityManagerFactory.class);
		Set<String> names = new HashSet<>();
		SessionFactory sessionFactory = emf.unwrap(SessionFactory.class);

		Map<String, ClassMetadata> classMetadataMap = sessionFactory.getAllClassMetadata();
		for (ClassMetadata classMetadata : classMetadataMap.values()) {
			AbstractEntityPersister aep = (AbstractEntityPersister) classMetadata;
			String tableName = aep.getTableName();
			if (StringUtils.isEmpty(tableName) || StringUtils.containsWhitespace(tableName)) {
				continue;
			}
			names.add(tableName);
			AepGetter getter = new AepGetter();
			getter.get(aep);

			log.info("TableName:" + aep.getTableName() + " " + "EntityName:" + aep.getEntityName());
			Arrays.stream(aep.getKeyColumnNames()).forEach(c->{
				log.info("key colName:" + c);
			});
			Arrays.stream(aep.getPropertyNames()).forEach(c->{
				log.info("property:" + c + "->" + aep.getPropertyTableName(c));
				log.info("property:" + c + " " + Arrays.stream(aep.getPropertyColumnNames(c)).collect(joining(",")));
			});
		}
		System.out.println(names);
		try {
			ProductDao dao = ctx.getBean(ProductDao.class);

			//productService.addAll(Arrays.asList(new Product(3, "Book"), new Product(4, "Soap"),
			//		new Product(3, "Computer")));
			Attribute a1 = new Attribute("min-computer");a1.setId(1);dao.persist(a1);
			Attribute a2 = new Attribute("blue");a2.setId(2);dao.persist(a2);
			Attribute a3 = new Attribute("made in China");a3.setId(3);dao.persist(a3);
			Attribute a4 = new Attribute("small size");a4.setId(4);dao.persist(a4);
			Attribute a5 = new Attribute("USB");a5.setId(5);dao.persist(a5);

			Owner o1 = new Owner("Owner1");o1.setId(1);dao.persist(o1);
			Product p1 = new Product();p1.setId(1);
			p1.setRealName("Computer1");
			p1.setOwnerId(o1);
			List<Attribute> p1A = Arrays.asList(a1, a2);
			p1.setAttributes(p1A);
			Part ppa1 = new Part("Part A", p1);ppa1.setId(1);
			Part ppa2 = new Part("Part B", p1);ppa2.setId(2);
			p1.setParts(Arrays.asList(ppa1, ppa2));
			dao.persist(p1);
			dao.persist(ppa1);dao.persist(ppa2);


			Product p2 = new Product();p2.setId(2);
			p2.setRealName("Computer2");
			p2.setOwnerId(o1);
			List<Attribute> p2A = Arrays.asList(a1, a2, a3);
			p2.setAttributes(p2A);
			Part ppa3 = new Part("Part C", p2);ppa3.setId(3);
			Part ppa4 = new Part("Part D", p2);ppa4.setId(4);
			p2.setParts(Arrays.asList(ppa3, ppa4));
			dao.persist(p2);
			dao.persist(ppa3);dao.persist(ppa4);

			Owner o2 = new Owner("Owner2");o2.setId(2);dao.persist(o2);
			Product p3 = new Product();p3.setId(3);
			p3.setRealName("Computer3");
			p3.setOwnerId(o2);
			List<Attribute> p3A = Arrays.asList(a1, a2, a4);
			p3.setAttributes(p3A);
			Part ppa5 = new Part("Part E", p3);ppa5.setId(5);
			p3.setParts(Arrays.asList(ppa5));
			dao.persist(p3);
			dao.persist(ppa5);
			//productService.addAll(Arrays.asList(p1, p2, p3));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//Test element list after rollback
		//System.out.println("listAll: " + productService.listAll());

		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		ctx.close();
		
	}
}
