package hu.daniel.hari.learn.spring.orm.service;

import hu.daniel.hari.learn.spring.orm.dao.ProductDao;
import hu.daniel.hari.learn.spring.orm.model.Product;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
@Transactional
public class AbcFacade {
  @Autowired
  private ProductDao productDao;

  public void addAll(Collection<Product> products) {
    for (Product product : products) {
      productDao.persist(product);
      log.info("Pre " + product.getRealName());
      //applicationEventPublisher.publishEvent(new Event(product));
    }
    log.info("Sleep...");
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    log.info("Before leaving addAll");
  }
}
