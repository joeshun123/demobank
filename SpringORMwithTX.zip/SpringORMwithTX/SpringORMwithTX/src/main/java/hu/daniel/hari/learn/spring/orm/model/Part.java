package hu.daniel.hari.learn.spring.orm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "A_PARTS")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Part extends BaseProduct {
  @Column(name = "NAME")
  private String name;

  @ManyToOne
  @JoinColumn(name = "product_id")
  private Product product;
}
