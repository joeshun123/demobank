package hu.daniel.hari.learn.spring.orm;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@AsyncListener
public class Generator implements ApplicationListener<GenerationStartEvent> {
  @Override
  public void onApplicationEvent(final GenerationStartEvent event) {
    log.debug("received GenerationStartEvent. start to enrich event");
    try {
      event.getEntityChanges().stream().forEach(e->log.info(e.getId() + " " + e.getName() + " " + e.getName()));
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    log.debug("enriched event.");
  }
}
