package hu.daniel.hari.learn.spring.orm;
import hu.daniel.hari.learn.spring.orm.model.Product;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Event {
  private Product payload;
}
