package hu.daniel.hari.learn.spring.orm.model;


import hu.daniel.hari.learn.spring.orm.ProductListener;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import lombok.Data;


@Data
@EntityListeners(ProductListener.class)
@MappedSuperclass
public abstract class BaseProduct {
  @Id
  @Column(name = "ID")
  private Integer id;
}
