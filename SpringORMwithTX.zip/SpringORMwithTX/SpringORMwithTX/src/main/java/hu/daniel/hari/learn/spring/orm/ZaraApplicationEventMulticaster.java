package hu.daniel.hari.learn.spring.orm;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ApplicationEventMulticaster;
import org.springframework.core.ResolvableType;


public class ZaraApplicationEventMulticaster implements ApplicationEventMulticaster, ApplicationContextAware {
  private ApplicationEventMulticaster asyncEventMulticaster;
  private ApplicationEventMulticaster syncEventMulticaster;
  private ApplicationContext applicationContext;

  public void setAsyncEventMulticaster(ApplicationEventMulticaster asyncEventMulticaster) {
    this.asyncEventMulticaster = asyncEventMulticaster;
  }

  public void setSyncEventMulticaster(ApplicationEventMulticaster syncEventMulticaster) {
    this.syncEventMulticaster = syncEventMulticaster;
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

  @Override
  public void addApplicationListener(ApplicationListener<?> listener) {
    if (listener.getClass().getAnnotation(AsyncListener.class) != null) {
      asyncEventMulticaster.addApplicationListener(listener);
    } else {
      syncEventMulticaster.addApplicationListener(listener);
    }
  }

  @Override
  public void addApplicationListenerBean(String listenerBeanName) {
    ApplicationListener<?> listener = this.applicationContext.getBean(listenerBeanName, ApplicationListener.class);
    addApplicationListener(listener);
  }

  @Override
  public void removeApplicationListener(ApplicationListener<?> listener) {
    syncEventMulticaster.removeApplicationListener(listener);
    asyncEventMulticaster.removeApplicationListener(listener);
  }

  @Override
  public void removeApplicationListenerBean(String listenerBeanName) {
    syncEventMulticaster.removeApplicationListenerBean(listenerBeanName);
    asyncEventMulticaster.removeApplicationListenerBean(listenerBeanName);
  }

  @Override
  public void removeAllListeners() {
    syncEventMulticaster.removeAllListeners();
    asyncEventMulticaster.removeAllListeners();
  }

  @Override
  public void multicastEvent(ApplicationEvent event) {
    syncEventMulticaster.multicastEvent(event);
    asyncEventMulticaster.multicastEvent(event);
  }

  @Override
  public void multicastEvent(ApplicationEvent event, ResolvableType eventType) {
    syncEventMulticaster.multicastEvent(event, eventType);
    asyncEventMulticaster.multicastEvent(event, eventType);
  }


}
