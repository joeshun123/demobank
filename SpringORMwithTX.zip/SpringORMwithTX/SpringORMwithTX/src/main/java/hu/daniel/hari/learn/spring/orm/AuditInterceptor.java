package hu.daniel.hari.learn.spring.orm;

import static java.util.stream.Collectors.joining;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.EmptyInterceptor;
import org.hibernate.Transaction;
import org.hibernate.type.Type;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AuditInterceptor extends EmptyInterceptor {
  @Override
  public String onPrepareStatement(String sql) {
    log.info(sql);
    return sql;
  }

  @Override
  public void postFlush(Iterator entities) {
    while (entities.hasNext()) {
      log.info(entities.next().getClass().toString());
    }
  }

  @Override
  public void afterTransactionCompletion(Transaction tx) {
    log.info("Committed");
  }

  @Override
  public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
    super.onDelete(entity, id, state, propertyNames, types);
  }

  @Override
  public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
    log.info("onSave:" + entity + " Id->" + id
        + " State->" + Arrays.stream(state).map(Object::toString).collect(joining(","))
        + " names->" + Arrays.stream(propertyNames).collect(joining(","))
        + " types->" + Arrays.stream(types).map(Object::toString).collect(joining(",")));
    return super.onSave(entity, id, state, propertyNames, types);
  }
}
