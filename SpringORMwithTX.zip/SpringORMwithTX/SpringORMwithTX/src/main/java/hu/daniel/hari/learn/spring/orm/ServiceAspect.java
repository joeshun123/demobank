package hu.daniel.hari.learn.spring.orm;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class ServiceAspect {
  @Autowired
  private ApplicationEventPublisher applicationEventPublisher;

  //@Pointcut("execution(* *ServiceImpl.* (..))")
  //@Pointcut("execution(* hu.daniel.hari.learn.spring.orm.service.AbcServiceImpl.addAll (..))")
  //@Pointcut("execution(* hu..*Service*.* (..))")
  //public void func() {};

  @Pointcut("within(@org.springframework.transaction.annotation.Transactional *)")
  public void tx() {}
  /*
  @Around("func()")
  public Object call(final ProceedingJoinPoint joinPoint) throws Throwable {
    Object returnObj = joinPoint.proceed();
    log.info("Around AOP done.");
    return returnObj;
  }
*/
/*
  @AfterReturning("func()")
  public void send() {
    log.info("About to fire TransactionCallCompletedEvent");
    applicationEventPublisher.publishEvent(new TransactionCallCompletedEvent());
    log.info("AfterReturning AOP done.");
  }
  @AfterThrowing("func()")
  public void error() {
    log.info("AfterThrowing~~~");
  }
*/
  @After("tx()")//target for all methods in @Transaction layer (i.e. SF layer)
  public void send() {
    log.info("About to fire TransactionCallCompletedEvent");
    applicationEventPublisher.publishEvent(new TransactionCallCompletedEvent());
    log.info("After AOP done.");
  }
}
