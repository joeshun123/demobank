package hu.daniel.hari.learn.spring.orm;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.context.ApplicationEvent;

@Data
public class GenerationStartEvent extends ApplicationEvent {
  private List<EntityChange> entityChanges;

  /**
   * Create a new ApplicationEvent.
   *
   * @param source the object on which the event initially occurred (never {@code null})
   */
  public GenerationStartEvent(Object source, List<EntityChange> entityChanges) {
    super(source);
    this.entityChanges = entityChanges;
  }
}
