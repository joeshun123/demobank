package hu.daniel.hari.learn.spring.orm;

import hu.daniel.hari.learn.spring.orm.model.BaseProduct;
import hu.daniel.hari.learn.spring.orm.model.Product;
import java.util.List;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
@Slf4j
public class ProductListener {
  @Autowired
  private ApplicationEventPublisher applicationEventPublisher;

  public ProductListener() {
    System.out.println("init");
  }


  @PostPersist
  public void productPostPersist(BaseProduct ob) {
    log.info("@PostPersist : ");
    TransactionContext.addEntityChange(new EntityChange(ob.getId(), ob.getClass().getName(), "CREATE"));
  }
/*
  @PrePersist
  public void productPrePersist(BaseProduct ob) {
    log.info("@PrePersist : ");
  }
  */

  //@TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
  public void beforeCommit(TransactionCallCompletedEvent event) {
    log.info("BEFORE_COMMIT : {}", event);
  }

  @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
  public void afterCommit(TransactionCallCompletedEvent event) {
    log.info("AFTER_COMMIT : {}", event);
    List<EntityChange> changes = TransactionContext.popAffectedEntityChanges();
    if (changes!=null && !changes.isEmpty()) {
      applicationEventPublisher.publishEvent(new GenerationStartEvent(this, changes));
    }
    log.info("cleanup afterCommit");
  }

  //@TransactionalEventListener(phase = TransactionPhase.AFTER_ROLLBACK)
  public void afterRollback(TransactionCallCompletedEvent event) {
    log.info("AFTER_ROLLBACK : {}", event);
    TransactionContext.cleanup();
  }

  //@TransactionalEventListener(phase = TransactionPhase.AFTER_COMPLETION)
  public void afterCompletion(TransactionCallCompletedEvent event) {
    log.info("AFTER_COMPLETION : {}", event);
    TransactionContext.cleanup();
  }
}
