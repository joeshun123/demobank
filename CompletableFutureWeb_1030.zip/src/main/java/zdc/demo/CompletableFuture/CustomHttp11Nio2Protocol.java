package zdc.demo.CompletableFuture;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.connector.CoyoteAdapter;
import org.apache.coyote.Adapter;
import org.apache.coyote.Processor;
import org.apache.coyote.RequestInfo;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.apache.coyote.http11.Http11Nio2Protocol;
import org.apache.coyote.http11.Http11Processor;
import org.apache.tomcat.util.net.AbstractEndpoint;
import org.apache.tomcat.util.net.SocketWrapperBase;

public class CustomHttp11Nio2Protocol extends Http11Nio2Protocol {
  protected Processor createProcessor() {
    Http11Processor processor = new CustomProcessor(this, this.adapter);
    return processor;
  }

  public static class CustomAdapter extends CoyoteAdapter {
    private Connector connector;
    public CustomAdapter(Connector connector) {
      super(connector);
      this.connector = connector;
    }
  }

  @Slf4j
  public static class CustomProcessor extends Http11Processor {
    public CustomProcessor(AbstractHttp11Protocol<?> protocol, Adapter adapter) {
      super(protocol, adapter);
    }
    public AbstractEndpoint.Handler.SocketState service(SocketWrapperBase<?> socketWrapper) throws IOException {
      //String traceId = this.request.getParameters().getParameter("traceId");
      //long callTime = Long.parseLong(this.request.getParameters().getParameter(("callTime")));
      //long now = System.currentTimeMillis();
      //log.info("TraceId: {}: ValveDelay: {}", traceId, (now - callTime));
      log.info("Received");
      return super.service(socketWrapper);
    }
  }
}
