package zdc.demo.CompletableFuture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompletableFutureDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompletableFutureDemoApplication.class, args);
	}

}
