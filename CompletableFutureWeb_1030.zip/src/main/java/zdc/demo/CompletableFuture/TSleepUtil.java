package zdc.demo.CompletableFuture;

import java.util.Random;

public class TSleepUtil {

  public static void sleep(long sleep) {
    simulateWorkSleep(sleep);
  }

  public static int getRandom(int min, int max) {
    return new Random().nextInt(max - min) + min;
  }

  public static int randomSleep(int min, int max) {
    int t = getRandom(min, max);
    sleep(t);
    return t;
  }

  public static long simulateWorkSleep(long sleepTimeMs) {
    long startTime = System.nanoTime();
    long endTime = startTime + sleepTimeMs * 1_000_000;
    while (System.nanoTime() < endTime) {
      performNonBlockingWork();
    }
    return sleepTimeMs;
  }

  private static void performNonBlockingWork() {
    double result = Math.sqrt(12345.6789);
  }
}
