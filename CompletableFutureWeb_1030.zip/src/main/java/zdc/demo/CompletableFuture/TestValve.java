package zdc.demo.CompletableFuture;

import jakarta.servlet.ServletException;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.valves.ValveBase;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TestValve extends ValveBase {
  @Override
  public void invoke(Request request, Response response) throws IOException, ServletException {
    //response.setContentType("text/plain");
    //response.setCharacterEncoding("UTF-8");

    Object callTimeObj = request.getParameter("callTime");
    if (callTimeObj!=null) {
      String traceId = request.getParameter("traceId");
      MDC.put("traceId", traceId);
      long callTime = Long.parseLong(request.getParameter("callTime"));
      long now = System.currentTimeMillis();
      log.info("TraceId: {}: ValveDelay: {}", traceId, (now - callTime));
    }
    this.getNext().invoke(request, response);
    //response.getWriter().write("OK");
  }
}
