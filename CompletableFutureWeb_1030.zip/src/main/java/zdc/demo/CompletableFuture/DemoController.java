package zdc.demo.CompletableFuture;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import jakarta.annotation.Nonnull;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Random;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api")
public class DemoController {

    @Autowired
    private Environment env;

    @GetMapping("/deduce-tariff-code")
    public String deduceTariffCode(@RequestParam String tariffCode){
        TSleepUtil.sleep(300);
        return "TariffCode ("+tariffCode+") deduced";
    }
    @GetMapping("/deduce-free-qty")
    public String deduceFreeQty(@RequestParam String tariffCode){
        TSleepUtil.sleep(300);
        return "FreeQty found for TariffCode ("+tariffCode+")";
    }
    private Meter meter = GlobalOpenTelemetry.meterBuilder("io.opentelemetry.metrics.hello").build();
    private LongCounter counter = meter.counterBuilder("helloCounter").build();

    @GetMapping("/intercept-call-code")
    public Test interceptCall(@RequestParam String tariffCode, @RequestParam long callTime, @RequestParam String traceId,
        @Nonnull final HttpServletRequest httpServletRequest){
        counter.add(1);
        //log.info(httpServletRequest.getAttribute("valveTime") + "");
        long receive = System.currentTimeMillis();
        long controllerDelay = receive - callTime;
        long start = System.nanoTime();
        //int i = TSleepUtil.randomSleep(400,800);
        int sleepTime = -1;
        try {
            sleepTime = (new Random()).nextInt(50, 100);
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        long endTime = System.nanoTime();
        log.error("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, (endTime-start)/1000000, receive, callTime);
        log.info("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, (endTime-start)/1000000, receive, callTime);
        log.debug("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, (endTime-start)/1000000, receive, callTime);
        log.trace("TraceId: {}: ControllerDelay: {}, SleepTime: {}, ProcessDuration: {}, Received: {}, callTime: {}", traceId,
                controllerDelay, sleepTime, (endTime-start)/1000000, receive, callTime);
        //return "Intercept API sleep time : no process";
        return new Test("A");
    }
    @Data
    @AllArgsConstructor
    public static class Test {
        private String field1;
    }

    @GetMapping("/test")
    public String test(){
        String maxThreads = env.getProperty("server.tomcat.threads.max");
        String maxConnections = env.getProperty("server.tomcat.max-connections");
        String acceptCount = env.getProperty("server.tomcat.accept-count");
        return "Max Threads: " + maxThreads + ", Max Connections: " + maxConnections+" acceptCount: "+acceptCount;
    }
}
