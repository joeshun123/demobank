package zdc.demo.CompletableFuture;

import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.core.StandardThreadExecutor;
import org.apache.tomcat.util.threads.TaskQueue;
import org.apache.tomcat.util.threads.TaskThreadFactory;
import org.apache.tomcat.util.threads.ThreadPoolExecutor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.TimeUnit;

@Slf4j
@Configuration
public class CustomExecutor {

  @Bean
  public StandardThreadExecutor threadPoolTaskExecutor() {
    StandardThreadExecutor executor = new CustomThreadExecutor();
    executor.setMaxThreads(800);
    executor.setNamePrefix("c-");
    executor.setMaxQueueSize(10000);
    return executor;
  }

  public static class CustomThreadExecutor extends StandardThreadExecutor {
    private TaskQueue taskqueue = null;
    public void startInternal() throws LifecycleException {
      taskqueue = new TaskQueue(maxQueueSize);
      TaskThreadFactory tf = new TaskThreadFactory(namePrefix, daemon, getThreadPriority());
      executor = new ThreadPoolExecutor(getMinSpareThreads(), getMaxThreads(), maxIdleTime, TimeUnit.MILLISECONDS,
              taskqueue, tf);
      executor.setThreadRenewalDelay(threadRenewalDelay);
      taskqueue.setParent(executor);

      setState(LifecycleState.STARTING);
    }
    @Override
    public void execute(Runnable command) {
      log.info("Queue size: {}", this.getQueueSize());
      if (executor != null) {
        // Note any RejectedExecutionException due to the use of TaskQueue
        // will be handled by the o.a.t.u.threads.ThreadPoolExecutor
        executor.execute(command);
      } else {
        throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
      }
    }
  }

  /*
  @Bean
  public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(25);
    //executor.setPrestartAllCoreThreads(true);
    executor.setMaxPoolSize(26);
    executor.setQueueCapacity(10000);
    executor.setThreadNamePrefix("d-");
    return executor;
  }
   */

}
