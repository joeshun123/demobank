package com.example.actuator;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.MultiGauge;
import io.micrometer.core.instrument.Tags;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/v1")
public class IndexController {
    @Autowired
    MeterRegistry registry;

    private Counter counter_core;
    private Counter counter_index;
    private AtomicInteger app_online_count;
    private MultiGauge statuses;

    @PostConstruct
    private void init(){
        counter_core = registry.counter("app_requests_method_count", "method", "IndexController.core");
        counter_index = registry.counter("app_requests_method_count", "method", "IndexController.index");
        app_online_count = registry.gauge("app_online_count", new AtomicInteger(0));
        statuses = MultiGauge.builder("statuses")
                .tag("job", "dirty")
                .description("The number of widgets in various statuses")
                .baseUnit("widgets")
                .register(registry);
    }

    @RequestMapping(value = "/index")
    public Object index(){
        try{
            counter_index.increment();
        } catch (Exception e) {
            return e;
        }
        return counter_index.count() + " index of springboot2-prometheus.";
    }

    @RequestMapping(value = "/core")
    public Object coreUrl(){
        try{
            counter_core.increment();
        } catch (Exception e) {
            return e;
        }
        return counter_core.count() + " coreUrl Monitor by Prometheus.";
    }

    @RequestMapping(value = "/online")
    public Object onlineCount(){
        int people = 0;
        try {
            people = new Random().nextInt(2000);
            app_online_count.set(people);
        } catch (Exception e){
            return e;
        }
        return "current online people: " + people;
    }

    @RequestMapping(value = "/sql")
    public Object sqlCount() {
        List<Status> s = new ArrayList<>();
        for (int i=0; i<30; i++) {
            s.add(new Status(RandomStringUtils.randomAlphabetic(4), i));
        }
        int people = 0;
        List<Status> s1;
        try {
            people = new Random().nextInt(30);
            s1 = new ArrayList<>();
            for (int j=0; j<=people; j++) {
                s1.add(s.get(j));
            }
            statuses.register(
                    s1.stream().map(r->MultiGauge.Row.of(Tags.of("sql", r.getSql()), r.getCount())).collect(Collectors.toList()));

        } catch (Exception e){
            log.error(e.getMessage(), e);
            return e;
        }
        return "sql: " + s1;
    }
    @Data
    @AllArgsConstructor
    private static class Status {
        private String sql;
        private int count;
    }
}
