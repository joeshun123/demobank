package com.test;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

@Component("singleEchoInstance")
public class SingletonEchoFactoryImpl extends AbstractEchoFactory {
  @Override
  public Class<?> getObjectType() {
    return SingletonEchoFactoryImpl.class;
  }

  @Override
  public boolean isSingleton() {
    return true;
  }
}
