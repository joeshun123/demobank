package com.test;


import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PrototypeBeanUser {
  @Autowired
  private ObjectFactory<PrototypeBeanInstance> instance;

  public void test() {
    PrototypeBeanInstance b = instance.getObject();
    System.out.println(System.identityHashCode(b) + " " + b.getTime());
  }
}
