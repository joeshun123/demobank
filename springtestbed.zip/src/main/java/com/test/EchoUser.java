package com.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class EchoUser {
  @Autowired
  @Qualifier("singleEchoInstance")
  private IEcho singleEcho;

  @Autowired
  @Qualifier("nonSingleEchoInstance")
  private IEcho nonSingleEcho;

  public void testEcho() {
    //System.out.println(System.identityHashCode(this.singleEcho) + " " + this.singleEcho.echo());
    System.out.println(System.identityHashCode(this.nonSingleEcho) + " " + this.nonSingleEcho.echo());
  }
}
