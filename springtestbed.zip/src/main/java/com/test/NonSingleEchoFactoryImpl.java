package com.test;

import org.springframework.stereotype.Component;

@Component("nonSingleEchoInstance")
public class NonSingleEchoFactoryImpl extends AbstractEchoFactory {
  @Override
  public Class<?> getObjectType() {
    return NonSingleEchoFactoryImpl.class;
  }

  @Override
  public boolean isSingleton() {
    return false;
  }
}
