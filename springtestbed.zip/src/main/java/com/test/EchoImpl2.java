package com.test;

import org.springframework.stereotype.Component;

@Component
public class EchoImpl2 implements IEcho {

  @Override
  public String echo() {
    return "happy2";
  }
}
