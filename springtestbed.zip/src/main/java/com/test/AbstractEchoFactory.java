package com.test;

import java.util.List;
import java.util.Random;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractEchoFactory implements FactoryBean<IEcho> {
  @Autowired
  private List<IEcho> allEchos;

  @Override
  public IEcho getObject() throws Exception {
    if (getConfig()%2==0) {
      return allEchos.get(0);
    } else {
      return allEchos.get(1);
    }
  }

  private int getConfig() {
    return new Random().nextInt();
  }


}
