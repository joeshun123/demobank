package com.test;

public interface IEcho {
  String echo();
}
