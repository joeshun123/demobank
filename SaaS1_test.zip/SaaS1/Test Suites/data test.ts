<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>data test</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>8e683f35-2b0f-4fc2-a217-dfe86cec8a8c</testSuiteGuid>
   <testCaseLink>
      <guid>412fdcea-7b8c-46dc-99b8-8c963b8bc949</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/logon</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>34e13982-db6f-4843-b363-2aaf0f47efae</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/idpass</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>34e13982-db6f-4843-b363-2aaf0f47efae</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>id</value>
         <variableId>f9530ed7-a3db-4e70-b5d2-4f38978c5c68</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>34e13982-db6f-4843-b363-2aaf0f47efae</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>pass</value>
         <variableId>d0b69308-56b5-4c3a-9dc8-2a92ddbbabe5</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>34e13982-db6f-4843-b363-2aaf0f47efae</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>flag</value>
         <variableId>3928b02b-b558-4997-80a4-5516da8ab504</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
