
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import com.applitools.eyes.selenium.Eyes

import org.openqa.selenium.WebElement

import com.applitools.eyes.RectangleSize


 /**
	 * Verify
	 * @param flag flag
	 * @return
	 */ 
def static "siteUICheck.verifySiteUI.verifyUI"(
    	String flag	) {
    (new siteUICheck.verifySiteUI()).verifyUI(
        	flag)
}

 /**
	 * Verify BL
	 * @return
	 */ 
def static "siteUICheck.verifySiteUI.verifyBl"() {
    (new siteUICheck.verifySiteUI()).verifyBl()
}

 /**
	 * Verify Request
	 * @return
	 */ 
def static "siteUICheck.verifySiteUI.verifyRequest"() {
    (new siteUICheck.verifySiteUI()).verifyRequest()
}

 /**
	 * Refresh browser
	 */ 
def static "siteUICheck.verifySiteUI.refreshBrowser"() {
    (new siteUICheck.verifySiteUI()).refreshBrowser()
}

 /**
	 * Click element
	 * @param to Katalon test object
	 */ 
def static "siteUICheck.verifySiteUI.clickElement"(
    	TestObject to	) {
    (new siteUICheck.verifySiteUI()).clickElement(
        	to)
}

 /**
	 * Get all rows of HTML table
	 * @param table Katalon test object represent for HTML table
	 * @param outerTagName outer tag name of TR tag, usually is TBODY
	 * @return All rows inside HTML table
	 */ 
def static "siteUICheck.verifySiteUI.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new siteUICheck.verifySiteUI()).getHtmlTableRows(
        	table
         , 	outerTagName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkTestObject"(
    	TestObject testObject	
     , 	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkTestObject(
        	testObject
         , 	testName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkWindow"(
    	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkWindow(
        	testName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkElement"(
    	Eyes eyes	
     , 	WebElement element	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkElement(
        	eyes
         , 	element)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpen"(
    	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpen(
        	testName
         , 	viewportSize)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesClose"(
    	Eyes eyes	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesClose(
        	eyes)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesInit"() {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesInit()
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpenWithBaseline"(
    	String baselineName	
     , 	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpenWithBaseline(
        	baselineName
         , 	testName
         , 	viewportSize)
}
