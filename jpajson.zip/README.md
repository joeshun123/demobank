# JPA JSON Demo Application

A Spring Boot application demonstrating JSON manipulation using Spring Data JPA with PostgreSQL and Oracle databases. The application features a React frontend with three tabs for different database approaches.

## Features

- **PostgreSQL Tab**: Uses native PostgreSQL queries for JSONB operations
- **Oracle Tab**: Uses native Oracle queries for JSON operations  
- **Universal Tab**: Uses JPA criteria for database-agnostic operations
- **CRUD Operations**: Create, Read, Update, Delete CAGO_LOT records
- **JSON Search**: Advanced search capabilities in JSON fields
- **GIN Indexes**: Optimized search performance with database-specific indexes

## Technology Stack

### Backend
- **JDK 21**
- **Spring Boot 3.2.0**
- **Spring Data JPA**
- **Hypersistence Utils for Hibernate 6.3**
- **Lombok**
- **PostgreSQL Driver**
- **Oracle Driver**

### Frontend
- **React 18.2.0**
- **React Bootstrap**
- **React Query**
- **Axios**

## Database Schema

The application uses a single table `CAGO_LOT` with the following structure:

```sql
CREATE TABLE CAGO_LOT (
    "key" BIGSERIAL PRIMARY KEY,           -- Auto-incrementing primary key
    "id" VARCHAR(5) NOT NULL,              -- 5-digit string identifier
    "doc" JSONB NOT NULL,                  -- JSONB (PostgreSQL) / JSON (Oracle)
    "data" JSONB NOT NULL                  -- JSONB (PostgreSQL) / JSON (Oracle)
);
```

### Sample Data

**Document (doc):**
```json
[
  {
    "doc_type": "bol",
    "doc_nbr": "B1234",
    "doc_key": 4564787
  },
  {
    "doc_type": "SSR",
    "doc_nbr": "SSR45412",
    "doc_key": 14548
  }
]
```

**Data (data):**
```json
{
  "vin": "V444546",
  "color": "white",
  "weight": 5656,
  "weightUom": "KG",
  "length": 748,
  "lengthUom": "M",
  "quantity": 100,
  "packageType": "UNIT",
  "description": "100 pack of phones: made in China"
}
```

## Setup Instructions

### Prerequisites
- JDK 21
- Maven 3.6+
- PostgreSQL 12+ or Oracle 19c+
- Node.js 16+ and npm

### Backend Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd jpajson
   ```

2. **Configure database connections**
   
   The application uses Spring profiles to switch between databases:
   
   **For PostgreSQL:**
   ```bash
   mvn spring-boot:run -Dspring.profiles.active=postgresql
   ```
   
   **For Oracle:**
   ```bash
   mvn spring-boot:run -Dspring.profiles.active=oracle
   ```
   
   You can also modify `src/main/resources/application.yml` to change the default profile:
   ```yaml
   spring:
     profiles:
       active: postgresql  # Change to 'oracle' for Oracle
   ```

3. **Create database and run schema scripts**
   
   **PostgreSQL:**
   ```bash
   createdb jpajson
   psql -d jpajson -f src/main/resources/sql/postgresql-schema.sql
   ```
   
   **Oracle:**
   ```bash
   sqlplus / as sysdba
   CREATE USER jpajson IDENTIFIED BY jpajson;
   GRANT CONNECT, RESOURCE TO jpajson;
   CONNECT jpajson/jpajson
   @src/main/resources/sql/oracle-schema.sql
   ```

4. **Build and run the application**
   ```bash
   mvn clean install
   ```
   
   **Run with PostgreSQL:**
   ```bash
   mvn spring-boot:run -Dspring.profiles.active=postgresql
   ```
   
   **Run with Oracle:**
   ```bash
   mvn spring-boot:run -Dspring.profiles.active=oracle
   ```

   The backend will be available at `http://localhost:8080`

### Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

   The frontend will be available at `http://localhost:3000`

## API Endpoints

### PostgreSQL Endpoints
- `GET /api/postgres/cagolot` - Get all records
- `GET /api/postgres/cagolot/{key}` - Get record by key
- `POST /api/postgres/cagolot` - Create new record
- `PUT /api/postgres/cagolot/{key}` - Update record
- `DELETE /api/postgres/cagolot/{key}` - Delete record
- `GET /api/postgres/cagolot/generate-id` - Generate new ID
- `POST /api/postgres/cagolot/search` - Search records

### Oracle Endpoints
- `GET /api/oracle/cagolot` - Get all records
- `GET /api/oracle/cagolot/{key}` - Get record by key
- `POST /api/oracle/cagolot` - Create new record
- `PUT /api/oracle/cagolot/{key}` - Update record
- `DELETE /api/oracle/cagolot/{key}` - Delete record
- `GET /api/oracle/cagolot/generate-id` - Generate new ID
- `POST /api/oracle/cagolot/search` - Search records

### Universal Endpoints
- `GET /api/universal/cagolot` - Get all records
- `GET /api/universal/cagolot/{key}` - Get record by key
- `POST /api/universal/cagolot` - Create new record
- `PUT /api/universal/cagolot/{key}` - Update record
- `DELETE /api/universal/cagolot/{key}` - Delete record
- `GET /api/universal/cagolot/generate-id` - Generate new ID
- `POST /api/universal/cagolot/search` - Search records

## Search Functionality

The application supports advanced JSON search with the following operators:

- **Equals (=)**: Exact match on JSON field values
- **LIKE**: Pattern matching on JSON field values

### Search Examples

**PostgreSQL:**
```sql
-- Search for documents with doc_nbr containing "23"
SELECT * FROM CAGO_LOT WHERE doc ->> 'doc_nbr' ILIKE '%23%'

-- Search for data with exact vin value
SELECT * FROM CAGO_LOT WHERE data ->> 'vin' = 'V444546'
```

**Oracle:**
```sql
-- Search for documents with doc_nbr containing "23"
SELECT * FROM CAGO_LOT WHERE JSON_VALUE(doc, '$.doc_nbr') LIKE '%23%'

-- Search for data with exact vin value
SELECT * FROM CAGO_LOT WHERE JSON_VALUE(data, '$.vin') = 'V444546'
```

## Performance Optimizations

### PostgreSQL
- GIN indexes on JSONB columns for fast search operations
- Native JSONB operators for efficient querying

### Oracle
- JSON indexes on JSON columns
- JSON_VALUE function for optimized field extraction

## Development

### Project Structure
```
jpajson/
├── src/main/java/com/example/jpajson/
│   ├── config/          # Configuration classes
│   ├── controller/      # REST controllers
│   ├── dto/            # Data transfer objects
│   ├── entity/         # JPA entities
│   ├── repository/     # Data access layer
│   └── service/        # Business logic
├── src/main/resources/
│   ├── sql/            # Database schema scripts
│   └── application.yml # Application configuration
├── frontend/           # React frontend application
└── pom.xml            # Maven configuration
```

### Key Components

- **CagoLot Entity**: JPA entity with JSON columns using Hypersistence Utils
- **Repository Interfaces**: Database-specific repositories with native queries
- **Service Layer**: Business logic and transaction management
- **REST Controllers**: API endpoints for each database type
- **React Components**: Tab-based UI for different database approaches

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Verify database credentials in `application.yml`
   - Ensure database service is running
   - Check network connectivity

2. **JSON Parsing Errors**
   - Validate JSON format in request payloads
   - Check for proper escaping of special characters

3. **Frontend Build Issues**
   - Clear `node_modules` and reinstall dependencies
   - Ensure Node.js version compatibility

### Logs

The application provides detailed logging for debugging:
- SQL queries are logged at DEBUG level
- JSON operations are logged with full context
- Error details include stack traces

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.
