import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import {
  Button, Table, Modal, Form, Alert, Spinner,
  Row, Col, Card, Badge, InputGroup
} from 'react-bootstrap';

const API_BASE = '/api/postgres';

const PostgresTab = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [currentItem, setCurrentItem] = useState(null);
  const [formData, setFormData] = useState({
    id: '',
    doc: '',
    data: ''
  });
  const [searchData, setSearchData] = useState({
    docField: '',
    docValue: '',
    docOperator: '=',
    dataField: '',
    dataValue: '',
    dataOperator: '='
  });

  const queryClient = useQueryClient();

  // Fetch all CAGO_LOT records
  const { data: cagoLots, isLoading, error, refetch } = useQuery(
    'postgresCagoLots',
    () => axios.get(`${API_BASE}/cagolot`).then(res => res.data),
    { refetchOnWindowFocus: false }
  );

  // Generate ID mutation
  const generateIdMutation = useMutation(
    () => axios.get(`${API_BASE}/cagolot/generate-id`).then(res => res.data),
    {
      onSuccess: (id) => {
        setFormData(prev => ({ ...prev, id }));
      }
    }
  );

  // Add mutation
  const addMutation = useMutation(
    (data) => axios.post(`${API_BASE}/cagolot`, data).then(res => res.data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('postgresCagoLots');
        setShowAddModal(false);
        setFormData({ id: '', doc: '', data: '' });
      }
    }
  );

  // Update mutation
  const updateMutation = useMutation(
    ({ key, data }) => axios.put(`${API_BASE}/cagolot/${key}`, data).then(res => res.data),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('postgresCagoLots');
        setShowUpdateModal(false);
        setCurrentItem(null);
        setSelectedItems([]);
      }
    }
  );

  // Delete mutation
  const deleteMutation = useMutation(
    (key) => axios.delete(`${API_BASE}/cagolot/${key}`),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('postgresCagoLots');
        setSelectedItems([]);
      }
    }
  );

  // Search mutation
  const searchMutation = useMutation(
    (searchCriteria) => axios.post(`${API_BASE}/cagolot/search`, searchCriteria).then(res => res.data),
    {
      onSuccess: (results) => {
        // Update the query data with search results
        queryClient.setQueryData('postgresCagoLots', results);
        setShowSearchModal(false);
      }
    }
  );

  const handleAdd = () => {
    generateIdMutation.mutate();
    setShowAddModal(true);
  };

  const handleUpdate = () => {
    if (selectedItems.length !== 1) {
      alert('Please select exactly one item to update');
      return;
    }
    const item = cagoLots.find(lot => lot.key === selectedItems[0]);
    setCurrentItem(item);
    setFormData({
      id: item.id,
      doc: JSON.stringify(item.doc, null, 2),
      data: JSON.stringify(item.data, null, 2)
    });
    setShowUpdateModal(false);
  };

  const handleDelete = () => {
    if (selectedItems.length === 0) {
      alert('Please select at least one item to delete');
      return;
    }
    if (window.confirm(`Are you sure you want to delete ${selectedItems.length} item(s)?`)) {
      selectedItems.forEach(key => deleteMutation.mutate(key));
    }
  };

  const handleSearch = () => {
    const searchCriteria = {
      docField: searchData.docField || null,
      docValue: searchData.docValue || null,
      docOperator: searchData.docOperator || '=',
      dataField: searchData.dataField || null,
      dataValue: searchData.dataValue || null,
      dataOperator: searchData.dataOperator || '='
    };
    
    // Only search if at least one field has values
    if (searchCriteria.docField && searchCriteria.docValue || searchCriteria.dataField && searchCriteria.dataValue) {
      searchMutation.mutate(searchCriteria);
    } else {
      alert('Please fill in at least one search field and value');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    try {
      const doc = JSON.parse(formData.doc);
      const data = JSON.parse(formData.data);
      
      if (currentItem) {
        updateMutation.mutate({
          key: currentItem.key,
          data: { id: formData.id, doc, data }
        });
      } else {
        addMutation.mutate({ id: formData.id, doc, data });
      }
    } catch (error) {
      alert('Invalid JSON format');
    }
  };

  const handleCheckboxChange = (key, checked) => {
    if (checked) {
      setSelectedItems(prev => [...prev, key]);
    } else {
      setSelectedItems(prev => prev.filter(k => k !== key));
    }
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      setSelectedItems(cagoLots.map(lot => lot.key));
    } else {
      setSelectedItems([]);
    }
  };

  if (isLoading) return <Spinner animation="border" />;
  if (error) return <Alert variant="danger">Error: {error.message}</Alert>;

  return (
    <div>
      <h2>PostgreSQL Tab</h2>
      <p className="text-muted">Using native PostgreSQL queries for JSONB operations</p>

      {/* Action Buttons */}
      <Row className="mb-3">
        <Col>
          <Button variant="outline-secondary" onClick={refetch} className="me-2">
            Reload
          </Button>
          <Button variant="success" onClick={handleAdd} className="me-2">
            Add
          </Button>
          <Button 
            variant="warning" 
            onClick={handleUpdate} 
            className="me-2"
            disabled={selectedItems.length !== 1}
          >
            Update
          </Button>
          <Button 
            variant="danger" 
            onClick={handleDelete}
            className="me-2"
            disabled={selectedItems.length === 0}
          >
            Delete
          </Button>
          <Button variant="info" onClick={() => setShowSearchModal(true)}>
            Search
          </Button>
        </Col>
      </Row>

      {/* Data Table */}
      <Card>
        <Card.Header>
          <Row className="align-items-center">
            <Col>
              <strong>CAGO_LOT Records ({cagoLots?.length || 0})</strong>
            </Col>
            <Col xs="auto">
              <Form.Check
                type="checkbox"
                label="Select All"
                checked={selectedItems.length === cagoLots?.length}
                onChange={(e) => handleSelectAll(e.target.checked)}
              />
            </Col>
          </Row>
        </Card.Header>
        <Card.Body>
          <Table striped bordered hover responsive>
            <thead>
              <tr>
                <th width="50">Select</th>
                <th>Key</th>
                <th>ID</th>
                <th>Document</th>
                <th>Data</th>
              </tr>
            </thead>
            <tbody>
              {cagoLots?.map(lot => (
                <tr key={lot.key}>
                  <td>
                    <Form.Check
                      type="checkbox"
                      checked={selectedItems.includes(lot.key)}
                      onChange={(e) => handleCheckboxChange(lot.key, e.target.checked)}
                    />
                  </td>
                  <td>{lot.key}</td>
                  <td><Badge bg="primary">{lot.id}</Badge></td>
                  <td>
                    <pre className="mb-0" style={{ fontSize: '0.8rem', maxHeight: '100px', overflow: 'auto' }}>
                      {JSON.stringify(lot.doc, null, 2)}
                    </pre>
                  </td>
                  <td>
                    <pre className="mb-0" style={{ fontSize: '0.8rem', maxHeight: '100px', overflow: 'auto' }}>
                      {JSON.stringify(lot.data, null, 2)}
                    </pre>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Card.Body>
      </Card>

      {/* Add/Update Modal */}
      <Modal show={showAddModal || showUpdateModal} onHide={() => {
        setShowAddModal(false);
        setShowUpdateModal(false);
        setCurrentItem(null);
        setFormData({ id: '', doc: '', data: '' });
      }} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{currentItem ? 'Update CAGO_LOT' : 'Add New CAGO_LOT'}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>ID</Form.Label>
                  <InputGroup>
                    <Form.Control
                      type="text"
                      value={formData.id}
                      onChange={(e) => setFormData(prev => ({ ...prev, id: e.target.value }))}
                      required
                      maxLength={5}
                    />
                    <Button 
                      variant="outline-secondary" 
                      onClick={() => generateIdMutation.mutate()}
                      disabled={generateIdMutation.isLoading}
                    >
                      {generateIdMutation.isLoading ? <Spinner size="sm" /> : 'Generate'}
                    </Button>
                  </InputGroup>
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>Document (JSON)</Form.Label>
              <Form.Control
                as="textarea"
                rows={6}
                value={formData.doc}
                onChange={(e) => setFormData(prev => ({ ...prev, doc: e.target.value }))}
                                 placeholder='{"docs":[{"doc_type":"bol","doc_nbr":"B1234","doc_key":4564787},{"doc_type":"SSR","doc_nbr":"SSR45412","doc_key":15548}]}'
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Data (JSON)</Form.Label>
              <Form.Control
                as="textarea"
                rows={6}
                value={formData.data}
                onChange={(e) => setFormData(prev => ({ ...prev, data: e.target.value }))}
                                 placeholder='{"vin":"V444546","color":"white","weight":5656,"weightUom":"KG","length":748,"lengthUom":"M","quantity":100,"packageType":"UNIT","description":"100 pack of phones: made in China"}'
                required
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => {
              setShowAddModal(false);
              setShowUpdateModal(false);
            }}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              variant={currentItem ? "warning" : "success"}
              disabled={addMutation.isLoading || updateMutation.isLoading}
            >
              {addMutation.isLoading || updateMutation.isLoading ? <Spinner size="sm" /> : 'Save'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Search Modal */}
      <Modal show={showSearchModal} onHide={() => setShowSearchModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Search CAGO_LOT</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col md={6}>
              <Card>
                <Card.Header>Document Search</Card.Header>
                <Card.Body>
                  <Form.Group className="mb-3">
                    <Form.Label>Field Name</Form.Label>
                    <Form.Control
                      type="text"
                      value={searchData.docField}
                      onChange={(e) => setSearchData(prev => ({ ...prev, docField: e.target.value }))}
                                             placeholder="e.g., docs.doc_nbr"
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Operator</Form.Label>
                    <Form.Select
                      value={searchData.docOperator}
                      onChange={(e) => setSearchData(prev => ({ ...prev, docOperator: e.target.value }))}
                    >
                      <option value="=">=</option>
                      <option value="like">LIKE</option>
                    </Form.Select>
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Value</Form.Label>
                    <Form.Control
                      type="text"
                      value={searchData.docValue}
                      onChange={(e) => setSearchData(prev => ({ ...prev, docValue: e.target.value }))}
                      placeholder="e.g., B1234"
                    />
                  </Form.Group>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6}>
              <Card>
                <Card.Header>Data Search</Card.Header>
                <Card.Body>
                  <Form.Group className="mb-3">
                    <Form.Label>Field Name</Form.Label>
                    <Form.Control
                      type="text"
                      value={searchData.dataField}
                      onChange={(e) => setSearchData(prev => ({ ...prev, dataField: e.target.value }))}
                      placeholder="e.g., vin"
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Operator</Form.Label>
                    <Form.Select
                      value={searchData.dataOperator}
                      onChange={(e) => setSearchData(prev => ({ ...prev, dataOperator: e.target.value }))}
                    >
                      <option value="=">=</option>
                      <option value="like">LIKE</option>
                    </Form.Select>
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Value</Form.Label>
                    <Form.Control
                      type="text"
                      value={searchData.dataValue}
                      onChange={(e) => setSearchData(prev => ({ ...prev, dataValue: e.target.value }))}
                      placeholder="e.g., V444546"
                    />
                  </Form.Group>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowSearchModal(false)}>
            Cancel
          </Button>
          <Button 
            variant="info" 
            onClick={handleSearch}
            disabled={searchMutation.isLoading}
          >
            {searchMutation.isLoading ? <Spinner size="sm" /> : 'Search'}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default PostgresTab;
