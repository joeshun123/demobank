import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Container, Nav, Navbar } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

import PostgresTab from './components/PostgresTab';
import OracleTab from './components/OracleTab';
import UniversalTab from './components/UniversalTab';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="App">
          <Navbar bg="dark" variant="dark" expand="lg">
            <Container>
              <Navbar.Brand href="/">JPA JSON Demo</Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                  <Nav.Link href="/postgres">PostgreSQL</Nav.Link>
                  <Nav.Link href="/oracle">Oracle</Nav.Link>
                  <Nav.Link href="/universal">Universal</Nav.Link>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>

          <Container className="mt-4">
            <Routes>
              <Route path="/" element={<Navigate to="/postgres" replace />} />
              <Route path="/postgres" element={<PostgresTab />} />
              <Route path="/oracle" element={<OracleTab />} />
              <Route path="/universal" element={<UniversalTab />} />
            </Routes>
          </Container>
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
