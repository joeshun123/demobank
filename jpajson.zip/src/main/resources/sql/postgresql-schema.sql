-- PostgreSQL Schema for CAGO_LOT table
-- Run this script in your PostgreSQL database

-- Create the CAGO_LOT table
CREATE TABLE IF NOT EXISTS CAGO_LOT (
    "key" BIGSERIAL PRIMARY KEY,
    "id" VARCHAR(5) NOT NULL,
    "doc" JSONB NOT NULL,
    "data" JSONB NOT NULL
);

-- Create GIN indexes for JSONB columns to improve search performance
CREATE INDEX IF NOT EXISTS idx_cago_lot_doc_gin ON CAGO_LOT USING GIN (doc);
CREATE INDEX IF NOT EXISTS idx_cago_lot_data_gin ON CAGO_LOT USING GIN (data);

-- Create a composite index for better performance on common queries
CREATE INDEX IF NOT EXISTS idx_cago_lot_id ON CAGO_LOT (id);

-- Sample data insertion
INSERT INTO CAGO_LOT ("id", "doc", "data") VALUES 
('12345', 
 '[{"doc_type":"bol","doc_nbr":"B1234","doc_key":4564787},{"doc_type":"SSR","doc_nbr":"SSR45412","doc_key":14548}]',
 '{"vin":"V444546","color":"white","weight":5656,"weightUom":"KG","length":748,"lengthUom":"M","quantity":100,"packageType":"UNIT","description":"100 pack of phones: made in China"}'
);
INSERT INTO CAGO_LOT ("id", "doc", "data") VALUES
    ('12346',
     '[{"doc_type":"bol","doc_nbr":"B001","doc_key":454548},{"doc_type":"SSR","doc_nbr":"SSR45413","doc_key":14549}]',
     '{"vin":"V1001","color":"white","weight":4516,"weightUom":"KG","length":898,"lengthUom":"M","quantity":20,"packageType":"UNIT","description":"20 pack of phones: made in India"}'
    );
INSERT INTO CAGO_LOT ("id", "doc", "data") VALUES
    ('AbxE',
     '[{"doc_type":"bol","doc_nbr":"B002","doc_key":4548},{"doc_type":"SSR","doc_nbr":"SSR115235","doc_key":4548}]',
     '{"vin":"V1002","color":"green","weight":154,"weightUom":"KG","length":928,"lengthUom":"M","quantity":10,"packageType":"UNIT","description":"10 pack of phones: made in USA"}'
    );