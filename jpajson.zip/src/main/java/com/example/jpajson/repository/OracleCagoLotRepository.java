package com.example.jpajson.repository;

import com.example.jpajson.entity.CagoLot;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@ConditionalOnProperty(name = "spring.datasource.oracle.enabled", havingValue = "true", matchIfMissing = false)
public interface OracleCagoLotRepository extends JpaRepository<CagoLot, Long> {

    // Native query to search in JSON doc column using JSON_VALUE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE JSON_VALUE(doc, '$.' || :field) = :value", nativeQuery = true)
    List<CagoLot> findByDocFieldEquals(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSON doc column using JSON_VALUE with LIKE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE JSON_VALUE(doc, '$.' || :field) LIKE '%' || :value || '%'", nativeQuery = true)
    List<CagoLot> findByDocFieldLike(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSON data column using JSON_VALUE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE JSON_VALUE(data, '$.' || :field) = :value", nativeQuery = true)
    List<CagoLot> findByDataFieldEquals(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSON data column using JSON_VALUE with LIKE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE JSON_VALUE(data, '$.' || :value) LIKE '%' || :value || '%'", nativeQuery = true)
    List<CagoLot> findByDataFieldLike(@Param("field") String field, @Param("value") String value);

    // Complex search combining both doc and data columns
    @Query(value = """
        SELECT * FROM CAGO_LOT 
        WHERE (JSON_VALUE(doc, '$.' || :docField) = :docValue OR :docField IS NULL)
        AND (JSON_VALUE(data, '$.' || :dataField) = :dataValue OR :dataField IS NULL)
        """, nativeQuery = true)
    List<CagoLot> findByComplexSearch(
        @Param("docField") String docField,
        @Param("docValue") String docValue,
        @Param("dataField") String dataField,
        @Param("dataValue") String dataValue
    );
}
