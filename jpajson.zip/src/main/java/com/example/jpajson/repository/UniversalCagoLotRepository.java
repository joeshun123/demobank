package com.example.jpajson.repository;

import com.example.jpajson.entity.CagoLot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UniversalCagoLotRepository extends JpaRepository<CagoLot, Long> {
    // Universal repository that works with both databases
    // Uses JPA criteria and Hypersistence Utils for JSON operations
}
