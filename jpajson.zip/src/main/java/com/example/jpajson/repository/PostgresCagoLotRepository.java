package com.example.jpajson.repository;

import com.example.jpajson.entity.CagoLot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostgresCagoLotRepository extends JpaRepository<CagoLot, Long> {

    // Native query to search in JSONB doc column
    @Query(value = "SELECT * FROM CAGO_LOT WHERE doc ->> :field = :value", nativeQuery = true)
    List<CagoLot> findByDocFieldEquals(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSONB doc column with LIKE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE doc ->> :field ILIKE %:value%", nativeQuery = true)
    List<CagoLot> findByDocFieldLike(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSONB data column
    @Query(value = "SELECT * FROM CAGO_LOT WHERE data ->> :field = :value", nativeQuery = true)
    List<CagoLot> findByDataFieldEquals(@Param("field") String field, @Param("value") String value);

    // Native query to search in JSONB data column with LIKE
    @Query(value = "SELECT * FROM CAGO_LOT WHERE data ->> :field ILIKE %:value%", nativeQuery = true)
    List<CagoLot> findByDataFieldLike(@Param("field") String field, @Param("value") String value);

    // Complex search combining both doc and data columns
    @Query(value = """
        SELECT * FROM CAGO_LOT 
        WHERE (doc ->> :docField = :docValue OR :docField IS NULL)
        AND (data ->> :dataField = :dataValue OR :dataField IS NULL)
        """, nativeQuery = true)
    List<CagoLot> findByComplexSearch(
        @Param("docField") String docField,
        @Param("docValue") String docValue,
        @Param("dataField") String dataField,
        @Param("dataValue") String dataValue
    );
}
