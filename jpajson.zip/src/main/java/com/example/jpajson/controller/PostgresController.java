package com.example.jpajson.controller;

import com.example.jpajson.dto.CagoLotDto;
import com.example.jpajson.dto.SearchRequestDto;
import com.example.jpajson.entity.CagoLot;
import com.example.jpajson.service.PostgresCagoLotService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postgres")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class PostgresController {

    private final PostgresCagoLotService service;

    @GetMapping("/cagolot")
    public ResponseEntity<List<CagoLot>> getAllCagoLots() {
        log.info("Fetching all CAGO_LOT records from PostgreSQL");
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/cagolot/{key}")
    public ResponseEntity<CagoLot> getCagoLotById(@PathVariable Long key) {
        log.info("Fetching CAGO_LOT with key: {}", key);
        return service.findById(key)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/cagolot")
    public ResponseEntity<CagoLot> createCagoLot(@RequestBody CagoLotDto dto) {
        log.info("Creating new CAGO_LOT: {}", dto);
        
        // No need to validate here since Jackson already validated the JSON during deserialization
        CagoLot cagoLot = new CagoLot();
        cagoLot.setId(dto.getId());
        cagoLot.setDoc(dto.getDoc());
        cagoLot.setData(dto.getData());

        CagoLot saved = service.save(cagoLot);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/cagolot/{key}")
    public ResponseEntity<CagoLot> updateCagoLot(@PathVariable Long key, @RequestBody CagoLotDto dto) {
        log.info("Updating CAGO_LOT with key: {}", key);
        
        // No need to validate here since Jackson already validated the JSON during deserialization
        return service.findById(key)
                .map(existing -> {
                    existing.setId(dto.getId());
                    existing.setDoc(dto.getDoc());
                    existing.setData(dto.getData());
                    return ResponseEntity.ok(service.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/cagolot/{key}")
    public ResponseEntity<Void> deleteCagoLot(@PathVariable Long key) {
        log.info("Deleting CAGO_LOT with key: {}", key);
        
        if (!service.findById(key).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        
        service.deleteById(key);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/cagolot/generate-id")
    public ResponseEntity<String> generateId() {
        String id = service.generateId();
        log.info("Generated new ID: {}", id);
        return ResponseEntity.ok(id);
    }

    @PostMapping("/cagolot/search")
    public ResponseEntity<List<CagoLot>> searchCagoLots(@RequestBody SearchRequestDto searchRequest) {
        log.info("Searching CAGO_LOT with criteria: {}", searchRequest);
        
        List<CagoLot> results = service.complexSearch(
            searchRequest.getDocField(),
            searchRequest.getDocValue(),
            searchRequest.getDocOperator(),
            searchRequest.getDataField(),
            searchRequest.getDataValue(),
            searchRequest.getDataOperator()
        );
        
        return ResponseEntity.ok(results);
    }

    @PostMapping("/cagolot/search/doc")
    public ResponseEntity<List<CagoLot>> searchByDoc(@RequestParam String field, 
                                                   @RequestParam String value, 
                                                   @RequestParam(defaultValue = "=") String operator) {
        log.info("Searching CAGO_LOT by doc field: {} {} {}", field, operator, value);
        
        boolean useLike = "like".equalsIgnoreCase(operator);
        List<CagoLot> results = service.searchByDocField(field, value, useLike);
        
        return ResponseEntity.ok(results);
    }

    @PostMapping("/cagolot/search/data")
    public ResponseEntity<List<CagoLot>> searchByData(@RequestParam String field, 
                                                    @RequestParam String value, 
                                                    @RequestParam(defaultValue = "=") String operator) {
        log.info("Searching CAGO_LOT by data field: {} {} {}", field, operator, value);
        
        boolean useLike = "like".equalsIgnoreCase(operator);
        List<CagoLot> results = service.searchByDataField(field, value, useLike);
        
        return ResponseEntity.ok(results);
    }
}
