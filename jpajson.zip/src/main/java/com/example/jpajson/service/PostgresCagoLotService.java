package com.example.jpajson.service;

import com.example.jpajson.entity.CagoLot;
import com.example.jpajson.repository.PostgresCagoLotRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PostgresCagoLotService {

    private final PostgresCagoLotRepository repository;
    private final ObjectMapper objectMapper;
    private final Random random = new Random();

    public List<CagoLot> findAll() {
        return repository.findAll();
    }

    public Optional<CagoLot> findById(Long key) {
        return repository.findById(key);
    }

    @Transactional
    public CagoLot save(CagoLot cagoLot) {
        return repository.save(cagoLot);
    }

    @Transactional
    public void deleteById(Long key) {
        repository.deleteById(key);
    }

    public String generateId() {
        // Generate a 5-digit string ID
        return String.format("%05d", random.nextInt(100000));
    }

    public List<CagoLot> searchByDocField(String field, String value, boolean useLike) {
        if (useLike) {
            return repository.findByDocFieldLike(field, value);
        } else {
            return repository.findByDocFieldEquals(field, value);
        }
    }

    public List<CagoLot> searchByDataField(String field, String value, boolean useLike) {
        if (useLike) {
            return repository.findByDataFieldLike(field, value);
        } else {
            return repository.findByDataFieldEquals(field, value);
        }
    }

    public List<CagoLot> complexSearch(String docField, String docValue, String docOperator, String dataField, String dataValue, String dataOperator) {
        List<CagoLot> results = new ArrayList<>();
        
        // Search by doc field if provided
        if (docField != null && docValue != null) {
            boolean useLike = "like".equalsIgnoreCase(docOperator);
            results.addAll(searchByDocField(docField, docValue, useLike));
        }
        
        // Search by data field if provided
        if (dataField != null && dataValue != null) {
            boolean useLike = "like".equalsIgnoreCase(dataOperator);
            results.addAll(searchByDataField(dataField, dataValue, useLike));
        }
        
        // If both fields are provided, find intersection
        if (docField != null && docValue != null && dataField != null && dataValue != null) {
            List<CagoLot> docResults = new ArrayList<>();
            List<CagoLot> dataResults = new ArrayList<>();
            
            boolean docUseLike = "like".equalsIgnoreCase(docOperator);
            boolean dataUseLike = "like".equalsIgnoreCase(dataOperator);
            
            docResults.addAll(searchByDocField(docField, docValue, docUseLike));
            dataResults.addAll(searchByDataField(dataField, dataValue, dataUseLike));
            
            // Find intersection
            results = docResults.stream()
                .filter(dataResults::contains)
                .collect(Collectors.toList());
        }
        
        return results;
    }

    public boolean validateJson(String jsonString) {
        try {
            objectMapper.readValue(jsonString, Object.class);
            return true;
        } catch (Exception e) {
            log.error("Invalid JSON: {}", jsonString, e);
            return false;
        }
    }

    public Object parseJson(String jsonString) throws Exception {
        return objectMapper.readValue(jsonString, Object.class);
    }
}
