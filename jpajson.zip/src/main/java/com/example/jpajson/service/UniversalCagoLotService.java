package com.example.jpajson.service;

import com.example.jpajson.entity.CagoLot;
import com.example.jpajson.repository.UniversalCagoLotRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@Service
@RequiredArgsConstructor
@Slf4j
public class UniversalCagoLotService {

    private final UniversalCagoLotRepository repository;
    private final EntityManager entityManager;
    private final ObjectMapper objectMapper;
    private final Random random = new Random();

    public List<CagoLot> findAll() {
        return repository.findAll();
    }

    public Optional<CagoLot> findById(Long key) {
        return repository.findById(key);
    }

    @Transactional
    public CagoLot save(CagoLot cagoLot) {
        return repository.save(cagoLot);
    }

    @Transactional
    public void deleteById(Long key) {
        repository.deleteById(key);
    }

    public String generateId() {
        // Generate a 5-digit string ID
        return String.format("%05d", random.nextInt(100000));
    }

    public List<CagoLot> searchByCriteria(String docField, String docValue, String docOperator, String dataField, String dataValue, String dataOperator) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CagoLot> query = cb.createQuery(CagoLot.class);
        Root<CagoLot> root = query.from(CagoLot.class);

        List<Predicate> predicates = new ArrayList<>();

        if (docField != null && docValue != null) {
            // This is a simplified approach - in practice, you'd need database-specific JSON functions
            // For now, we'll use a basic approach that works with both databases
            predicates.add(cb.equal(root.get("id"), docValue)); // Placeholder
        }

        if (dataField != null && dataValue != null) {
            predicates.add(cb.equal(root.get("id"), dataValue)); // Placeholder
        }

        if (!predicates.isEmpty()) {
            query.where(predicates.toArray(new Predicate[0]));
        }

        return entityManager.createQuery(query).getResultList();
    }

    public boolean validateJson(String jsonString) {
        try {
            objectMapper.readValue(jsonString, Object.class);
            return true;
        } catch (Exception e) {
            log.error("Invalid JSON: {}", jsonString, e);
            return false;
        }
    }

    public Object parseJson(String jsonString) throws Exception {
        return objectMapper.readValue(jsonString, Object.class);
    }
}
