package com.example.jpajson.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JpaConfig {
    // JPA properties are now configured in the profile-specific application-*.yml files
}
