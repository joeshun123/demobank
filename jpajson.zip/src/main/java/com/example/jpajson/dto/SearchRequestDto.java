package com.example.jpajson.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchRequestDto {
    private String docField;
    private String docValue;
    private String docOperator; // "=" or "like"
    private String dataField;
    private String dataValue;
    private String dataOperator; // "=" or "like"
}
