package com.example.jpajson.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CagoLotDto {
    private Long key;
    private String id;
    private Map<String, Object> doc;
    private Map<String, Object> data;
}
