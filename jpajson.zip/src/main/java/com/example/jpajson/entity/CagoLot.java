package com.example.jpajson.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.Map;

@Entity
@Table(name = "CAGO_LOT")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CagoLot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "key")
    private Long key;

    @Column(name = "id", nullable = false, length = 5)
    private String id;

    @Column(name = "doc", nullable = false)
    //@Type(JsonType.class)
    @JdbcTypeCode(SqlTypes.JSON)
    private Map<String, Object> doc;

    @Column(name = "data", nullable = false)
    //@Type(JsonType.class)
    @JdbcTypeCode(SqlTypes.JSON)
    private Map<String, Object> data;
}
